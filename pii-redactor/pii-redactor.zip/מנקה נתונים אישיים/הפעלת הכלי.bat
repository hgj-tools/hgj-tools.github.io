@echo off
rem ---------------------------------------------------------------------------
rem  HGJ - PII Redactor launcher. Double-click to start. Keep the black window
rem  open while working; close it to stop.
rem
rem  ASCII ONLY on purpose: Hebrew inside a .bat is unreliable, and "chcp 65001"
rem  shifts cmd's file pointer and corrupts the rest of the script.
rem  The system folder has a Hebrew name and may be hidden, so it is found by
rem  PowerShell (Get-ChildItem -Force) and not by name here. The tool folder is
rem  passed through an environment variable, so "&" or "," in the path is safe.
rem  The exit on success sits on the same line as the call: an update may
rem  replace this file while it runs, and cmd re-reads a running .bat by byte
rem  offset. Ctrl+C returns a negative code, which "if not errorlevel 1" treats
rem  as a normal exit.
rem ---------------------------------------------------------------------------
set "PIIROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = Get-ChildItem -LiteralPath $env:PIIROOT -Directory -Force | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'server.ps1') } | Select-Object -First 1; if (-not $d) { exit 3 }; & (Join-Path $d.FullName 'server.ps1'); exit $LASTEXITCODE" & if not errorlevel 1 exit /b 0
echo.
echo  Could not start the local server.
echo  Opening the tool directly - everything works except OCR.
echo.
pause
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = Get-ChildItem -LiteralPath $env:PIIROOT -Directory -Force | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'index.html') } | Select-Object -First 1; if ($d) { Start-Process (Join-Path $d.FullName 'index.html') }"
exit /b 1
