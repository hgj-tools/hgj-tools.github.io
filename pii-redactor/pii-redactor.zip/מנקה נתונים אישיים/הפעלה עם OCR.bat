@echo off
rem ---------------------------------------------------------------------------
rem  HGJ - PII Redactor launcher.
rem  Starts the local server (server.ps1) so the OCR engine can load,
rem  then opens the browser. Close this window to stop the server.
rem
rem  ASCII ONLY on purpose. Hebrew text inside a .bat is unreliable, and
rem  "chcp 65001" shifts cmd's file pointer and corrupts the rest of the
rem  script. All Hebrew messages live in server.ps1 instead.
rem ---------------------------------------------------------------------------

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
if errorlevel 1 goto fallback
exit /b 0

:fallback
echo.
echo  Could not start the local server.
echo  Opening index.html directly - everything works except OCR.
echo.
pause
start "" "%~dp0index.html"
exit /b 1
