@echo off
chcp 65001 >nul
title מנקה נתונים אישיים
rem ---------------------------------------------------------------------------
rem מפעיל את הכלי דרך שרת מקומי, כדי שמנוע ה-OCR יעבוד.
rem לפתיחה רגילה בלי OCR אפשר פשוט ללחוץ פעמיים על index.html.
rem השרת מאזין על 127.0.0.1 בלבד, מגיש קבצים מהתיקייה הזאת לקריאה,
rem ואינו יוצא לאינטרנט. הקוד לעיון בקובץ server.ps1.
rem ---------------------------------------------------------------------------

where powershell >nul 2>&1
if errorlevel 1 goto nops

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
if errorlevel 1 goto failed
exit /b 0

:nops
echo.
echo   לא נמצא PowerShell במחשב הזה.
echo   אפשר לעבוד בכל זאת: לפתוח את index.html בלחיצה כפולה.
echo   הכל יעבוד חוץ מזיהוי OCR של מסמכים סרוקים.
echo.
pause
start "" "%~dp0index.html"
exit /b 1

:failed
echo.
echo   הפעלת השרת נכשלה. ייתכן שהרצת סקריפטים חסומה במחשב זה.
echo   אפשר לעבוד בכל זאת: לפתוח את index.html בלחיצה כפולה.
echo   הכל יעבוד חוץ מזיהוי OCR של מסמכים סרוקים.
echo.
pause
start "" "%~dp0index.html"
exit /b 1
