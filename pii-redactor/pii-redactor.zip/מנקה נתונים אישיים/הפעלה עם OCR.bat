@echo off
rem ---------------------------------------------------------------------------
rem  HGJ - PII Redactor launcher.
rem  Starts the local server (server.ps1) so the OCR engine can load,
rem  then opens the browser. Close this window to stop the server.
rem
rem  ASCII ONLY on purpose. Hebrew text inside a .bat is unreliable, and
rem  "chcp 65001" shifts cmd's file pointer and corrupts the rest of the
rem  script. All Hebrew messages live in server.ps1 instead.
rem ---------------------------------------------------------------------------

rem The update step may replace this .bat while it runs. cmd re-reads a
rem running .bat by byte offset, so the exit on success must sit on the
rem same line as the call, which cmd has already parsed in full.
rem Ctrl+C returns a negative code, so "if not errorlevel 1" (code below 1) also exits
rem instead of falling back to opening index.html without OCR.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1" & if not errorlevel 1 exit /b 0
goto fallback

:fallback
echo.
echo  Could not start the local server.
echo  Opening index.html directly - everything works except OCR.
echo.
pause
start "" "%~dp0index.html"
exit /b 1
