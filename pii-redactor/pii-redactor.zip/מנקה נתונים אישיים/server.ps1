﻿# שרת קבצים מקומי זעיר עבור "מנקה נתונים אישיים".
#
# למה זה נדרש: מנוע ה-OCR (Tesseract) חייב ליצור Worker ולקרוא את חבילות
# השפה ואת קובץ ה-wasm. דפדפנים חוסמים את שתי הפעולות האלה כשעמוד נפתח
# ישירות מהדיסק בפרוטוקול file://. הגשה דרך http://127.0.0.1 פותרת זאת.
#
# מה השרת הזה עושה, ומה הוא לא עושה:
#   - מאזין על 127.0.0.1 בלבד. אינו נגיש מהרשת ואינו פותח פורט חוצה.
#   - מגיש קבצים מהתיקייה שבה הוא יושב, לקריאה בלבד.
#   - אינו כותב, אינו מוחק, אינו מריץ קוד ואינו יוצא לאינטרנט.
#   - אינו דורש הרשאות מנהל.
# הקוד פתוח לעיון, וכל שורה בו ניתנת לבדיקה על ידי גורם אבטחת מידע.

param([switch]$NoBrowser)   # -NoBrowser: להרמת השרת בלי לפתוח דפדפן (בדיקות)

$ErrorActionPreference = 'Stop'

# קיבוע פלט הקונסולה ל-UTF-8, אחרת ההודעות בעברית יוצאות מקושקשות
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$mime = @{
  '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
  '.js'='text/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'
  '.json'='application/json; charset=utf-8'; '.txt'='text/plain; charset=utf-8'
  '.wasm'='application/wasm'; '.gz'='application/gzip'
  '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'
  '.gif'='image/gif'; '.svg'='image/svg+xml'; '.ico'='image/x-icon'
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.pdf'='application/pdf'
}

# איתור פורט פנוי. TcpListener על פורט גבוה אינו מצריך הרשאות מנהל,
# בשונה מ-HttpListener שדורש רישום URL במערכת.
$listener = $null
foreach ($port in 8765..8790) {
  try {
    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
    $listener.Start()
    break
  } catch { $listener = $null }
}
if (-not $listener) {
  Write-Host "לא נמצא פורט פנוי בטווח 8765-8790. יש לסגור חלונות קודמים של הכלי ולנסות שוב." -ForegroundColor Red
  Read-Host "Enter ליציאה" | Out-Null
  exit 1
}

$url = "http://127.0.0.1:$port/index.html"
Write-Host ""
Write-Host "  מנקה נתונים אישיים" -ForegroundColor Cyan
Write-Host "  ------------------"
Write-Host "  הכלי פועל בכתובת: $url"
Write-Host "  העיבוד כולו מתבצע בדפדפן שלך. שום קובץ אינו נשלח לרשת."
Write-Host ""
Write-Host "  אין לסגור את החלון הזה בזמן העבודה." -ForegroundColor Yellow
Write-Host "  לסיום: לסגור את החלון, או Ctrl+C."
Write-Host ""

if (-not $NoBrowser) { Start-Process $url | Out-Null }

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $client.ReceiveTimeout = 5000
      $client.SendTimeout    = 30000
      $stream = $client.GetStream()

      # קריאת שורת הבקשה והכותרות
      $sb = New-Object System.Text.StringBuilder
      $buf = New-Object byte[] 1
      $limit = 8192
      while ($sb.Length -lt $limit) {
        if ($stream.Read($buf, 0, 1) -le 0) { break }
        [void]$sb.Append([char]$buf[0])
        $s = $sb.ToString()
        if ($s.EndsWith("`r`n`r`n") -or $s.EndsWith("`n`n")) { break }
      }
      $request = $sb.ToString()
      if (-not $request) { continue }

      $first = ($request -split "`r?`n")[0]
      $parts = $first -split ' '
      $method = $parts[0]
      $target = if ($parts.Count -gt 1) { $parts[1] } else { '/' }

      # ניקוי הנתיב: הסרת query, פענוח אחוזים, ומניעת יציאה מהתיקייה
      $path = ($target -split '\?')[0]
      $path = [System.Uri]::UnescapeDataString($path)
      if ($path -eq '/' -or $path -eq '') { $path = '/index.html' }
      $rel = $path.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
      $full = [System.IO.Path]::GetFullPath((Join-Path $root $rel))
      $rootFull = [System.IO.Path]::GetFullPath($root)

      $status = '200 OK'; $body = $null; $ctype = 'application/octet-stream'

      if (-not $full.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        $status = '403 Forbidden'; $body = [System.Text.Encoding]::UTF8.GetBytes('403'); $ctype = 'text/plain'
      } elseif ($method -ne 'GET' -and $method -ne 'HEAD') {
        $status = '405 Method Not Allowed'; $body = [System.Text.Encoding]::UTF8.GetBytes('405'); $ctype = 'text/plain'
      } elseif (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $status = '404 Not Found'; $body = [System.Text.Encoding]::UTF8.GetBytes('404'); $ctype = 'text/plain'
      } else {
        $ext = [System.IO.Path]::GetExtension($full).ToLower()
        if ($mime.ContainsKey($ext)) { $ctype = $mime[$ext] }
        $body = [System.IO.File]::ReadAllBytes($full)
      }

      # שים לב: לקובצי .gz לא נשלח Content-Encoding בכוונה. מנוע ה-OCR מוריד
      # את חבילת השפה הדחוסה ומפרק אותה בעצמו, ופריקה כפולה בדפדפן שוברת אותה.
      $head = "HTTP/1.1 $status`r`n" +
              "Content-Type: $ctype`r`n" +
              "Content-Length: $($body.Length)`r`n" +
              "Cache-Control: no-store`r`n" +
              "X-Content-Type-Options: nosniff`r`n" +
              "Connection: close`r`n`r`n"
      $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
      $stream.Write($hb, 0, $hb.Length)
      if ($method -eq 'GET' -and $body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
      $stream.Flush()
    } catch {
      # חיבור שנקטע באמצע אינו שגיאה שמצדיקה עצירה של השרת
    } finally {
      if ($client) { $client.Close() }
    }
  }
} finally {
  $listener.Stop()
}
