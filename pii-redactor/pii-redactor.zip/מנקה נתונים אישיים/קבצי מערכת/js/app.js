pdfjsLib.GlobalWorkerOptions.workerSrc = "vendor/pdf.worker.min.js";
/* CVE-2024-4367: pdf.js 3.11.174 מהדר גליפים של גופן ל new Function, וקובץ PDF זדוני
   יכול להזריק דרכו קוד. isEvalSupported:false בכל getDocument מבטל את ההידור
   (התיקון הרשמי של Mozilla לגרסאות עד 4.1.392). אין לפתוח PDF בלי ההגדרה הזו. */

/* ============ מצב גלובלי ============ */
const state = {
  files: [],          // {id,name,ext,file, text, workbook, rows, images:[]}
  findings: [],       // {id,type,value,label,fileId,checked}
  mode: 'token',
  pdfMode: 'image',
  ctxNames: 'off',
  detectors: {},      // key -> bool
  pdfScale: 2,        // רזולוציית רינדור עמודי PDF
  anonName: false,    // שם קובץ אנונימי לחלוטין
  stripMedia: true,   // הסרת תמונות ואובייקטים מוטמעים מ-Office
  allPages: false,    // מלבן ידני מוחל על כל עמודי המסמך
  pseudo: {map:{}, counters:{}, byVal:{}},
  keyLoaded: [],      // שורות ממפתח קודם שנטען: {tok,type,value}
  keyTerms: [],       // שמות ומונחים מהמפתח הקודם, שמחפשים בכל הקבצים
  findQ: '', findType: '', findLimit: 200, findOpen: new Set(),
  verify: null,
  templateBoxes: [],  // מלבני תבנית ביחס לגודל העמוד, חלים על כל עמוד בכל קובץ
  previewLimit: 5,    // מעל מספר הקבצים הזה: מצב אצווה, תצוגה מקדימה לקובץ אחד בכל פעם
  previewId: null,    // הקובץ שמוצג כרגע במצב אצווה   // ערך מנורמל -> תווית ממוספרת יציבה
};

/* worker אחד משותף לכל מסמכי pdf.js. כברירת מחדל כל getDocument יוצר worker
   משלו, ואם המסמך לא נסגר ה-worker נשאר חי. ב-350 קבלות הצטברו מאות workers
   והדפדפן נתקע באמצע ההפקה. ב-file:// pdf.js נופל ל-worker מדומה בתוך הדף. */
let _pdfWorker=null;
function pdfWorker(){ if(!_pdfWorker) _pdfWorker=new pdfjsLib.PDFWorker(); return _pdfWorker; }
/* סוגר מסמך pdf.js ומשחרר את הזיכרון שלו. ה-worker המשותף נשאר חי. */
function closePdf(doc){ try{ if(doc) doc.destroy(); }catch(e){} }

/* ============ מזהים (regex ישראלי) ============ */
const DETECTORS = {
  firstname:{label:'זיהוי שמות (פרטי + משפחה)', tag:'[שם]', on:true},
  company: {label:'שם הישות (חברה / עמותה / ע"ר)', tag:'[ישות]', on:true},
  id:      {label:'ת.ז', tag:'[ת"ז]', on:true},
  hp:      {label:'ח.פ / ע.מ', tag:'[ח.פ]', on:true},
  phone:   {label:'טלפון', tag:'[טלפון]', on:true},
  email:   {label:'אימייל', tag:'[אימייל]', on:true},
  cc:      {label:'כרטיס אשראי', tag:'[כרטיס]', on:true},
  bank:    {label:'חשבון בנק', tag:'[חשבון]', on:true},
  iban:    {label:'IBAN', tag:'[IBAN]', on:true},
  taxfile: {label:'תיק ניכויים / תיק מס', tag:'[תיק]', on:true},
  passport:{label:'דרכון', tag:'[דרכון]', on:true},
  vehicle: {label:'מספר רכב', tag:'[רכב]', on:true},
  birth:   {label:'תאריך לידה', tag:'[ת.לידה]', on:true},
  addr:    {label:'כתובת', tag:'[כתובת]', on:true},
  date:    {label:'כל תאריך', tag:'[תאריך]', on:false},
  zip:     {label:'מיקוד', tag:'[מיקוד]', on:false},
};

/* מילון שמות פרטיים ישראליים נפוצים (זכר + נקבה) - זיהוי אוטומטי אופליין */
const FIRST_NAMES = new Set((`
אבי אבנר אביב אביתר אבישי אברהם אדם אהרון אודי אור אורי אורן אייל איל איתי איתמר איתן אלון אלי
אליהו אליאב אליעזר אלכס אמיר אסף ארז אריאל אריה אשר בן בני בניה ברוך ברק גד גדי גיא גיל גלעד גל
דב דביר דוד דור דורון דן דני דניאל הראל הלל זאב זוהר חגי חובב חיים חן טל טוביה יאיר יגאל יהודה
יהונתן יהושע יואב יואל יובל יוסי יוסף יורם יותם יחיאל ינון יניב יעקב יפתח יצחק ירון ישי ישראל
כפיר לביא לוי ליאור ליאם מאיר מוטי מיכאל מנחם מרדכי משה מתן נדב נהוראי נועם נחום נחמן ניב ניר
נמרוד נתן נתנאל סהר סטב עברי עדי עוז עומר עידו עידן עמוס עמית ערן פנחס צבי צח קובי רועי רז רן רני
רפאל רפי שאול שגיא שחר שי שלום שלמה שמואל שמעון שקד תום תומר תמיר עוזי אלעד רותם רן שמאי בועז
אביגיל אביה אבישג אדוה אודליה אורית אורלי אושרת איילת איילה אילנה אירית אלה אלונה אליה אלינור
אמונה אמילי אנאל אסתר אפרת אתי בר בת-שבע גאיה גולן גלי גלית דיאנה דנה דפנה הדס הדר הודיה הילה
ורד זהבה זיו חגית חנה טליה טובה יעל יערה יסמין יפית יפעת ירדן כרמל ליאל ליבי ליהי לימור לינוי
מאיה מור מורן מיה מיכל מירב מרים נגה נוה נועה נוי נורית נטע נילי נעה נעמה נעמי סיון סיגל סמדר
ספיר עדן עינב עינת ענבל ענבר עפרה פנינה צליל קורל קרן רבקה רונה רוני רונית רות רחל ריטה ריקי
רננה שגית שולמית שיר שירה שירן שלומית שני שרה תהילה תמר גילה זיוה חדוה יהודית לאה מלכה נחמה
אבשלום אהוד אופיר אוריאל אחיה אילן אלחנן אלישע אלנתן אלקנה אמנון אפרים בנימין בצלאל גבריאל גדעון
גרשון דורי דותן הדר זבולון זכריה חזי חנוך חנן יאן יגל יוחאי יוחנן יונתן יחזקאל ירמיהו ישעיהו לירן
מיכה מישאל מלאכי מנשה נחשון נפתלי נריה עזרא עמיחי עמנואל עמרי עקיבא צבי צדוק צפריר ראובן רחמים
שלומי שמחה שמשון שרון תמיר
אולג איגור אלכסנדר אנדריי ארתור בוריס ולדימיר ויקטור יבגני מקסים סרגיי פבל רומן אנה אלנה אולגה
אירינה ויקטוריה טטיאנה יוליה לודמילה מרינה נטליה סבטלנה קטרינה
אחמד מוחמד מחמוד מוסטפא יוסוף איברהים חאלד עלי עומאר סאמי ראמי וליד נאדר פאטמה מרים עאישה
רנא רים לילא סמירה
אביטל אורנה אילנית אלינור אנט בתיה גאולה דבורה דורית דליה הגר זהר חוה חיה טלי יוכבד ליאת לילך
מזל מירי מיטל נאוה נירית סיגלית עדנה עליזה פזית ציפי ציפורה צביה רויטל רינה רעות שושנה שפרה תקוה
`).split(/\s+/).filter(Boolean));

/* שמות שהם גם מילים נפוצות בעברית - לא לזהות אוטומטית לבד */
const AMBIGUOUS_NAMES = new Set((`
אלה אשר שי מתן אביב אור גל בר חן טל נגה עדי רן דור נוי ורד זיו עוז רז שקד תום קרן סיון ניב ניר
מור מיה יעל תמר בת הדס הדר לביא רות שיר עדן צח סהר עמית גילה נוה חדוה זהבה
צבי שרון שמחה מזל חיה חוה זהר רינה תקוה גאולה אנה עלי רים רחמים הגר דורי חנן חזי אנט
אילן דבורה שושנה עדנה מרינה רומן מקסים לילך נאוה עליזה רעות מיכה ראובן מנשה שלומי יאן
שני בן דן שלום ישראל לוי
חיים נתן גיל אדם בני אסף עמוס מיכל עידן אמונה נחמה מלכה גולן
`).split(/\s+/).filter(Boolean));

/* אימות ת.ז ישראלית */
function validIsraeliID(s){
  const d = s.replace(/\D/g,'');
  // רק 8-9 ספרות. סף של 5 ספרות הציף דוחות כספיים בסכומים שעברו את ספרת הביקורת במקרה.
  if(d.length<8 || d.length>9) return false;
  const p = d.padStart(9,'0');
  let sum=0;
  for(let i=0;i<9;i++){
    let n = +p[i] * ((i%2)+1);
    if(n>9) n-=9;
    sum+=n;
  }
  return sum%10===0;
}
/* אימות Luhn לכרטיס אשראי */
function validLuhn(s){
  const d=s.replace(/\D/g,'');
  if(d.length<13||d.length>19) return false;
  let sum=0, alt=false;
  for(let i=d.length-1;i>=0;i--){
    let n=+d[i];
    if(alt){n*=2; if(n>9)n-=9;}
    sum+=n; alt=!alt;
  }
  return sum%10===0;
}

/* אימות IBAN ישראלי לפי mod-97 */
function validIban(str){
  const v=(str||'').replace(/[\s-]/g,'').toUpperCase();
  if(!/^IL[0-9]{21}$/.test(v)) return false;
  const re=v.slice(4)+v.slice(0,4);
  let rem=0;
  for(const ch of re){
    const d = /[0-9]/.test(ch) ? ch : String(ch.charCodeAt(0)-55);
    for(const x of d) rem=(rem*10 + (+x))%97;
  }
  return rem===1;
}

/* ספירה בעברית: "קובץ אחד" ולא "1 קבצים" */
function heN(n, one, many){ return n===1 ? one : n+' '+many; }
/* מפתח השוואה לערך. מספר (טלפון, ת"ז, חשבון) מושווה לפי הספרות בלבד, כדי שאותו טלפון
   שנכתב פעם עם מקף ופעם בלי מקף יהיה שורה אחת בטבלה ויקבל תווית אחת. */
function valueKey(value){
  const d=String(value||'').replace(/[\s\-\/.()]/g,'');
  return /^\+?\d{5,}$/.test(d) ? d : normSpaceless(value);
}

/* ============ פסאודונימיזציה עקבית ============
   אותו ערך מקבל את אותה תווית ממוספרת בכל הקבצים ובכל העמודים, כך שהמודל
   יכול לעקוב אחרי אותו אדם או אותה חברה לאורך הניתוח. */
function pseudoInner(type){ return typeTag(type).replace(/^\[/,'').replace(/\]$/,''); }
function pseudoToken(value, type){
  const nv = valueKey(value), key = type+'|'+nv;
  const reg = state.pseudo;
  if(reg.map[key]) return reg.map[key];
  // אותו ערך מקבל אותה תווית גם כששני גלאים זיהו אותו בסוגים שונים, וגם כשהוא
  // הגיע ממפתח של הפעלה קודמת
  if(reg.byVal[nv]){ reg.map[key]=reg.byVal[nv]; return reg.byVal[nv]; }
  const inner = pseudoInner(type);
  reg.counters[inner] = (reg.counters[inner]||0)+1;
  const tok = '['+inner+'-'+reg.counters[inner]+']';
  reg.map[key] = tok; reg.byVal[nv] = tok;
  return tok;
}
/* כל סוגי הממצאים האפשריים, לתרגום חזרה מהכיתוב שבקובץ המפתח לסוג */
function allFindingTypes(){
  return ['name','field','company','birth','addr','date'].concat(Object.keys(DETECTORS).filter(k=>k!=='firstname'));
}
/* בונה את קובץ המפתח מהממצאים המאושרים בפועל, ומצרף את שורות המפתח הקודם אם נטען.
   המפתח מצטבר: בלי זה, ערך שהופיע רק ברבעון הראשון היה נעלם מהמפתח של השני,
   והמספר שלו היה ניתן לאדם אחר ברבעון השלישי. */
function buildKeyFile(){
  const rows=[];
  const seen=new Set();
  const add=(tok,type,value)=>{ const k=tok+'|'+valueKey(value); if(seen.has(k)) return; seen.add(k); rows.push({tok, type: typeLabel(type), value}); };
  state.files.forEach(f=>{
    activeFor(f).forEach(a=>add(pseudoToken(a.value,a.type), a.type, a.value));
  });
  (state.keyLoaded||[]).forEach(r=>add(r.tok, r.type, r.value));
  if(!rows.length) return null;
  const num=t=>{ const m=/-(\d+)\]$/.exec(t); return m?+m[1]:0; };
  rows.sort((x,y)=>x.tok.replace(/-\d+\]$/,'').localeCompare(y.tok.replace(/-\d+\]$/,''),'he') || num(x.tok)-num(y.tok));
  const lines=[
    'מפתח פענוח - קובץ פרטי',
    'אין להעלות את הקובץ הזה למודל שפה או לשלוח אותו יחד עם הקבצים הנקיים.',
    'נוצר על ידי מנקה נתונים אישיים, עיבוד מקומי בדפדפן.',
    'בעבודה הבאה על אותו לקוח אפשר לטעון את הקובץ הזה בכלי, וכל ערך יקבל שוב את אותה תווית.',
    '',
    'תווית\tסוג\tהערך המקורי',
    '-'.repeat(60)
  ];
  rows.forEach(r=>lines.push(r.tok+'\t'+r.type+'\t'+r.value));
  return new Blob(['﻿'+lines.join('\r\n')+'\r\n'], {type:'text/plain;charset=utf-8'});
}
/* קורא קובץ מפתח מהפעלה קודמת (גם בפורמט הישן, עם רווחים במקום טאבים), ומכין את
   המספור כך שכל ערך מוכר יקבל את התווית שכבר ניתנה לו וערך חדש ימשיך מהמספר הבא. */
function loadKeyText(text){
  const types=allFindingTypes().map(t=>({t, label:typeLabel(t)})).sort((a,b)=>b.label.length-a.label.length);
  const out=[];
  String(text||'').replace(/^﻿/,'').split(/\r?\n/).forEach(line=>{
    const m=/^\s*(\[[^\[\]]+-\d+\])[ \t]+(.*)$/.exec(line);
    if(!m) return;
    let type=null, value=null;
    const cols=m[2].split('\t');
    if(cols.length>=2){
      const hit=types.find(x=>x.label===cols[0].trim());
      type=hit?hit.t:null; value=cols.slice(1).join(' ').trim();
    } else {
      const hit=types.find(x=>m[2].startsWith(x.label));
      if(hit){ type=hit.t; value=m[2].slice(hit.label.length).trim(); }
    }
    if(!type || !value) return;
    out.push({tok:m[1], type, value});
  });
  const reg=state.pseudo;
  out.forEach(r=>{
    const nv=valueKey(r.value); if(nv.length<2) return;
    reg.map[r.type+'|'+nv]=r.tok;
    if(!reg.byVal[nv]) reg.byVal[nv]=r.tok;
    const mm=/^\[(.+)-(\d+)\]$/.exec(r.tok);
    if(mm) reg.counters[mm[1]]=Math.max(reg.counters[mm[1]]||0, +mm[2]);
  });
  state.keyLoaded=out;
  // שמות, ישויות, שדות וכתובות מהמפתח מחופשים בכל הקבצים. מספרים (ת"ז, טלפון) מזוהים
  // ממילא לפי המבנה שלהם ויקבלו את התווית הישנה דרך המיפוי.
  state.keyTerms=out.filter(r=>['name','company','field','addr'].includes(r.type) && normSpaceless(r.value).length>=3)
                    .map(r=>({type:r.type, value:r.value}));
  return out.length;
}

/* מאתר ממצאים בטקסט. מחזיר [{type,value}] */
function scanText(text){
  const out=[];
  const push=(type,value)=>{ const v=(value||'').trim(); if(v.length>=2 && !STOP_WORDS.has(v)) out.push({type,value:v}); };

  // אימייל
  if(state.detectors.email)
    (text.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g)||[]).forEach(m=>push('email',m));

  // טלפון ישראלי (נייד/נייח, עם או בלי מקף/רווח).
  // חובה לחסום התאמה בתוך רצף ספרות ארוך: בלי זה IBAN או מספר חשבון
  // מייצרים "טלפון" מדומה מתוך הספרות שבתוכם.
  if(state.detectors.phone){
    const rePh=/(?:^|[^\d+])((?:\+972[-\s]?|0)(?:5\d|7\d|[2-489])[-\s]?\d{3}[-\s]?\d{4})(?!\d)/g;
    let mp; while((mp=rePh.exec(text))!==null) push('phone', mp[1]);
  }

  // כרטיס אשראי (16 ספרות בקבוצות) - עם אימות Luhn
  // התבנית הקודמת התירה רווח בין כל שתי ספרות, ולכן גרפה שני מספרים נפרדים
  // (למשל ת.ז ואחריה טלפון) למחרוזת אחת שעברה Luhn במקרה. כאן קבוצות אמיתיות.
  if(state.detectors.cc){
    const reCc=/\b\d{4}[ -]?\d{6}[ -]?\d{5}\b|\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{1,3}\b|\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{1,4}\b/g;
    (text.match(reCc)||[]).forEach(m=>{ if(validLuhn(m)) push('cc',m); });
  }

  // ת.ז / ח.פ: רק 8-9 ספרות ורק עם ספרת ביקורת תקינה. ח.פ ישראלי מתחיל ב-5.
  const nine = text.match(/\b\d{8,9}\b/g)||[];
  nine.forEach(m=>{
    const clean=m.replace(/\D/g,'');
    if(clean.length===9 && clean[0]==='5'){
      if(state.detectors.hp && validIsraeliID(clean)) push('hp',m);
      return;
    }
    if(state.detectors.id && validIsraeliID(clean)) push('id',m);
  });
  // ת"ז שנכתבה עם מקף לפני ספרת הביקורת (12345678-9, 1-2345678-9). רווח אינו נחשב מפריד,
  // כי בטבלה כספית שני מספרים סמוכים היו מתחברים למזהה מדומה. התבנית שלמעלה
  // תפסה רק את שמונה הספרות הראשונות, וספרת הביקורת נשארה גלויה גם כשהמספר זוהה.
  if(state.detectors.id){
    const reDash=/(?:^|[^\d\-])(\d-?\d{7}-\d|\d-\d{8})(?![\d\-])/g;
    let mD; while((mD=reDash.exec(text))!==null){
      const clean=mD[1].replace(/\D/g,'');
      if(clean.length===9 && validIsraeliID(clean)) push(clean[0]==='5' && state.detectors.hp ? 'hp' : 'id', mD[1]);
    }
  }
  // דרכון ומספר רכב: רק אחרי תווית מפורשת, אחרת כל מספר בדוח היה מועמד
  if(state.detectors.passport){
    const reP=/(?:מס['׳]?\s*דרכון|מספר\s*דרכון|דרכון(?:\s*מס['׳]?)?|passport(?:\s*(?:no|number|#))?\.?)[:\s#]{0,5}([A-Z]{0,2}\d{6,9})(?![\dA-Za-z])/gi;
    let mP; while((mP=reP.exec(text))!==null) push('passport', mP[1]);
  }
  if(state.detectors.vehicle){
    const reV=/(?:מס['׳]?\s*רכב|מספר\s*(?:ה)?רכב|מס['׳]?\s*רישוי|מספר\s*רישוי|לוחית\s*רישוי)[:\s]{0,5}(\d{2,3}[-\s]?\d{2,3}[-\s]?\d{2,3})(?![\d\-])/g;
    let mV; while((mV=reV.exec(text))!==null){ const dg=mV[1].replace(/\D/g,''); if(dg.length===7||dg.length===8) push('vehicle', mV[1]); }
  }
  // מזהה שמופיע אחרי תווית מפורשת: נתפס גם באורך חריג או בלי ספרת ביקורת תקינה
  if(state.detectors.id || state.detectors.hp){
    const reLbl=/(?:ת\.?\s*ז\.?|ת["׳]ז|מס['׳]?\s*זהות|מספר\s*זהות|ח\.?\s*פ\.?|ח["׳]פ|ע\.?\s*מ\.?|עוסק\s*מורשה)[:\s]{0,4}(\d[\d\-/]{4,12}\d)/g;
    let mL; while((mL=reLbl.exec(text))!==null) push('id', mL[1]);
  }

  // חשבון בנק: סניף-חשבון תבנית כללית
  if(state.detectors.bank)
    (text.match(/\b\d{2,3}[-]\d{3,6}[-]\d{4,9}\b/g)||[]).forEach(m=>push('bank',m));

  // IBAN ישראלי, עם אימות mod-97
  if(state.detectors.iban)
    (text.match(/\bIL\s?\d{2}(?:\s?\d{4}){4}\s?\d{3}\b/gi)||[]).forEach(m=>{ if(validIban(m)) push('iban',m); });

  // תיק ניכויים / תיק מס: רק לפי תווית מפורשת, אחרת זה רעש בדוח כספי
  if(state.detectors.taxfile){
    const reTax=/(?:תיק\s*ניכויים|תיק\s*מס|מס['׳]?\s*תיק|מספר\s*תיק)[:\s]{0,4}(\d[\d\-/]{3,12}\d)/g;
    let mT; while((mT=reTax.exec(text))!==null) push('taxfile', mT[1]);
  }

  // מיקוד 7 ספרות
  if(state.detectors.zip)
    (text.match(/\b\d{7}\b/g)||[]).forEach(m=>{ if(!validIsraeliID(m)) push('zip',m); });

  // תאריך לידה: תאריך הסמוך למילות הקשר
  if(state.detectors.birth){
    const re=/(?:תארי?ך\s*לידה|ת\.?\s*לידה|נולדה?|יליד(?:ת)?|ילידי?)\D{0,8}(\d{1,2}[.\/-]\d{1,2}[.\/-]\d{2,4})/g;
    let m; while((m=re.exec(text))!==null) push('birth', m[1]);
    const re2=/(?:תארי?ך\s*לידה|ת\.?\s*לידה|נולדה?|יליד(?:ת)?)\D{0,8}(\d{1,2}\s+ב?(?:ינואר|פברואר|מרץ|אפריל|מאי|יוני|יולי|אוגוסט|ספטמבר|אוקטובר|נובמבר|דצמבר)\s+\d{4})/g;
    while((m=re2.exec(text))!==null) push('birth', m[1]);
  }

  // כתובת: רחוב/שדרות/דרך + מילים + מספר, וגם ת.ד
  if(state.detectors.addr){
    const re=/((?:רחוב|רח['׳]?|שדרות|שד['׳]?|דרך|שכונת|סמטת|מבוא)\s+[א-ת"'\-]+(?:\s+[א-ת"'\-]+){0,3}\s+\d{1,4})/g;
    let m; while((m=re.exec(text))!==null) push('addr', m[1].trim());
    (text.match(/ת\.?\s*ד\.?\s*\d{1,6}/g)||[]).forEach(m2=>push('addr', m2));
  }

  // כל תאריך (כבוי כברירת מחדל - עלול לתפוס תאריכי דוח)
  if(state.detectors.date){
    (text.match(/\b\d{1,2}[.\/-]\d{1,2}[.\/-]\d{2,4}\b/g)||[]).forEach(m=>push('date',m));
    (text.match(/\b\d{1,2}\s+ב?(?:ינואר|פברואר|מרץ|אפריל|מאי|יוני|יולי|אוגוסט|ספטמבר|אוקטובר|נובמבר|דצמבר)\s+\d{4}\b/g)||[]).forEach(m=>push('date',m));
  }

  // שמות מרשימה ידנית, התאמה מנורמלת (ניקוד/רווחים/גרשיים), כולל סדר תווים הפוך (RTL ב-PDF)
  const bigNorm = normSpaceless(text);
  const bigLoose = normLoose(text);
  namesList().forEach(name=>{
    const n=normSpaceless(name);
    const nr=n.split('').reverse().join('');
    if(n.length>=2 && (wildIncludes(bigNorm,n) || wildIncludes(bigNorm,nr))){ push('name', name); return; }
    // מעבר רופף: הטקסט שחולץ מהקובץ מאבד אותיות, והמשתמש מקליד את השם נכון
    const nl=normLoose(name);
    const nlr=nl.split('').reverse().join('');
    if(nl.length>=4 && (wildIncludes(bigLoose,nl) || wildIncludes(bigLoose,nlr))) push('name', name);
  });

  // שמות ומונחים ממפתח של הפעלה קודמת: נשמרים בסוג המקורי, כדי שיקבלו את אותה תווית
  (state.keyTerms||[]).forEach(k=>{
    const n=normSpaceless(k.value), nr=n.split('').reverse().join('');
    if(wildIncludes(bigNorm,n) || wildIncludes(bigNorm,nr)){ push(k.type, k.value); return; }
    const nl=normLoose(k.value);
    if(nl.length>=4 && (wildIncludes(bigLoose,nl) || wildIncludes(bigLoose,nl.split('').reverse().join('')))) push(k.type, k.value);
  });

  // זיהוי שמות (אופציונלי): צמד "פרטי + משפחה" גם כשהפרטי לא במילון
  if(state.detectors.firstname){
    const parts = text.split(/([^א-ת"']+)/);   // אינדקסים זוגיים = טוקנים עבריים
    // שתי מילים נחשבות שם אחד רק כשביניהן רווח בלבד. בלי זה "דנה לוי, טלפון" הניב גם
    // את "לוי טלפון", ו"רבעון שני" בסוף שורה התחבר למילה הראשונה של השורה הבאה.
    const near=sep=>/^[ \u00a0]{1,3}$/.test(sep||'');
    for(let i=0;i<parts.length;i+=2){
      const w    = (parts[i]||'').replace(/["']/g,'');
      const next = near(parts[i+1]) ? (parts[i+2]||'').replace(/["']/g,'') : '';
      const prev = near(parts[i-1]) ? (parts[i-2]||'').replace(/["']/g,'') : '';
      if(FIRST_NAMES.has(w) && !AMBIGUOUS_NAMES.has(w)){
        // גם מילה שהיא בעצמה שם פרטי מצטרפת כשם משפחה (יוסי אברהם, דנה לוי): שני שמות
        // פרטיים צמודים הם כמעט תמיד אדם אחד, ושני ממצאים נפרדים רק מעמיסים על הטבלה
        if(next && next.length>=2 && !STOP_WORDS.has(next)){
          push('name', w+' '+next);
          i+=2;                                  // המילה הבאה כבר נלקחה כשם המשפחה
        }
        else
          push('name', w);
      } else if(SURNAMES.has(w)){
        // שם משפחה מוכר: צרף את המילה שלפניו כשם פרטי אם היא סבירה
        if(prev && prev.length>=2 && !STOP_WORDS.has(prev) && !SURNAMES.has(prev) && (!SURNAME_WORDS.has(w) || FIRST_NAMES.has(prev)))
          push('name', prev+' '+w);
        else if(FIRST_NAMES.has(prev))
          push('name', prev+' '+w);
      }
    }
  }

  // שם הישות. הגרסה הקודמת הכירה רק "X בע\"מ" ו-"חברת X", ולכן עמותות
  // וע\"ר, שהם רוב המבוקרים כאן, היו בלתי נראים לה לחלוטין.
  if(state.detectors.company){
    scanEntities(text).forEach(v=>push('company', v));
  }

  // שם באנגלית אחרי תואר או תווית מפורשים (Mr., Ms., Dr., Attn:, Dear, Name:). בלי הקשר כזה
  // כל צמד מילים באות גדולה ("Annual Report") היה נתפס כשם, ולכן רק עם הקשר.
  if(state.detectors.firstname){
    const reEn=/(?:\b(?:Mr|Mrs|Ms|Miss|Dr|Prof|Adv)\.?|\b(?:Attn|Attention|Dear|Contact(?:\s+person)?|Full\s+name|Name)\s*[:.]?)[ \t]+([A-Z][a-z]+(?:[ \t]+[A-Z][a-z'\-]+){1,2})/g;
    let mE; while((mE=reEn.exec(text))!==null) push('name', mE[1].trim());
  }

  // זיהוי שמות לפי הקשר עברי (אופציונלי, כבוי כברירת מחדל)
  if(state.ctxNames==='on'){
    const ctx = /(?:מר|מרת|גב'|גברת|גבירת|ד"ר|דר'|עו"ד|רו"ח|ה"ה|בעל השליטה|בעלת השליטה|המנכ"ל|מנכ"ל|יו"ר|סמנכ"ל|החתום מטה|שם:|לכבוד)[:\s]+([א-ת]{2,}(?:\s+[א-ת]{2,}){0,2})/g;
    let mm;
    while((mm=ctx.exec(text))!==null){ push('name', mm[1].trim()); }
  }

  // הסרת כפילויות
  const seen=new Set(), uniq=[];
  out.forEach(o=>{ const k=o.type+'|'+o.value; if(!seen.has(k)){seen.add(k);uniq.push(o);} });
  return uniq;
}

/* ============ זיהוי שם הישות ============
   בדוח כספי ישראלי שם הישות הוא הפריט החשוב ביותר להשחרה, והוא כמעט תמיד
   נושא סיומת מוכרת או יושב בכותרת החוזרת של כל עמוד. */

/* ביטויים שהם חלק מהדוח ולא שם ישות, ואין להציע אותם */
const REPORT_PHRASES = /דוח|דוחות|כספיים|מאזן|ביאור|ביאורים|נספח|מבקר|רואה\s*חשבון|תזרים|הכנס|הוצא|נכסים|התחייבו|הון|עמוד|שנה|שנת|ליום|בדצמבר|בינואר|סקירה|הנהלה|תוכן\s*עניינים|סעיף|בהתאם|שיועד|יועדו|זכות|שימוש|שאר|שירותים|מקצועי|ציבורי|מוסדות/;

/* סיומות וקידומות של ישויות ישראליות */
const ENT_SUFFIX = /([\u0590-\u05FF][\u0590-\u05FF"'׳״\-]*(?:\s+[\u0590-\u05FF][\u0590-\u05FF"'׳״\-]*){0,4})\s*(?:\(\s*(?:ע["'׳״]?ר|חל["'׳״]?צ)\s*\)|בע["'׳״]?\s?מ\b|ע["'׳״]ר\b|חל["'׳״]צ\b|אגודה\s+שיתופית|שותפות\s+מוגבלת)/g;
const ENT_PREFIX = /(?:חברת|עמותת|קרן|פורום|ארגון|אגודת|מוסד|איגוד|מרכז|תאגיד)\s+([\u0590-\u05FF][\u0590-\u05FF"'׳״\-]*(?:\s+[\u0590-\u05FF][\u0590-\u05FF"'׳״\-]*){0,3})/g;

function scanEntities(text){
  const out=[], seen=new Set();
  const take=v=>{
    v=(v||'').replace(/\s+/g,' ').trim().replace(/^[\-,.]+|[\-,.]+$/g,'');
    if(v.length<3 || v.length>70) return;
    if(STOP_WORDS.has(v)) return;
    const words=v.split(/\s+/);
    // די במילת דוח או מילת קישור אחת כדי לדעת שזה ביטוי מגוף הדוח ולא שם ישות
    if(words.some(w=>REPORT_PHRASES.test(w) || STOP_WORDS.has(w))) return;
    const k=normSpaceless(v);
    if(!k || k.length<3 || seen.has(k)) return;
    seen.add(k); out.push(v);
  };
  // כל שורה בנפרד: בלי זה "מוסד להכשרת מדריכים" נמשך גם אל המילה הראשונה של השורה הבאה
  String(text||'').split(/[\n\t]+/).forEach(line=>{
    let m;
    ENT_SUFFIX.lastIndex=0;
    while((m=ENT_SUFFIX.exec(line))!==null) take(m[0]);
    ENT_PREFIX.lastIndex=0;
    while((m=ENT_PREFIX.exec(line))!==null) take(m[0]);
  });
  return out;
}

/* מועמדים לשם הישות: סיומות, וגם הכותרת שחוזרת בראש רוב העמודים.
   הכותרת החוזרת היא הסימן החזק ביותר, והיא עובדת גם כשחילוץ הטקסט העברי
   יוצא בסדר הפוך, כי אותו רצף בדיוק חוזר בכל העמודים. */
function entityCandidates(f){
  const res=[], seen=new Set();
  const add=(value, why)=>{
    const k=normSpaceless(value);
    if(!k || k.length<3 || seen.has(k)) return;
    seen.add(k); res.push({value, why});
  };
  scanEntities(f.text||'').forEach(v=>add(v, 'סיומת ישות'));

  // הכותרת אינה זהה בין עמודים, כי אחרי שם הישות מגיע שם הדוח. לכן מחפשים
  // את התחילית המשותפת הארוכה ביותר לרוב העמודים, וזה בדיוק שם הישות.
  const tops=(f.pageTops||[]).filter(t=>t && t.trim().length>=8).map(t=>t.trim());
  if(tops.length>=3){
    const need=Math.max(3, Math.ceil(tops.length*0.6));
    let best='';
    for(let i=0;i<tops.length;i++){
      for(let L=Math.min(tops[i].length,80); L>=8; L--){
        const pref=tops[i].slice(0,L);
        if(tops.filter(t=>t.startsWith(pref)).length>=need){
          if(pref.length>best.length) best=pref;
          break;
        }
      }
    }
    best=best.replace(/^[\s,.\-)(]+|[\s,.\-)(]+$/g,'').trim();
    if(best.length>=6 && best.length<=70){
      const n=tops.filter(t=>t.startsWith(best)).length;
      add(best, `כותרת חוזרת ב-${n} עמודים`);
    }
  }
  // הכותרת החוזרת היא הסימן החזק ביותר, ולכן ראשונה. אחריה הסיומות, הארוכה
  // קודם. יותר משישה מועמדים זה כבר רעש שהמשתמש לא יעבור עליו.
  res.sort((a,b)=>{
    const ha=/חוזר/.test(a.why)?0:1, hb=/חוזר/.test(b.why)?0:1;
    return ha!==hb ? ha-hb : b.value.length-a.value.length;
  });
  return res.slice(0,6);
}

/* מילות קישור שלא נצרף כשם משפחה */
const STOP_WORDS = new Set('של את על עם אל כי גם או אם כן לא זה זו הוא היא הם הן אני אתה כמו אחרי לפני בין תחת מעל ליד עבור בגין בעל בעלת מר גברת אשר היה הייתה יהיה בעמ בעלים חברה קרן סניף חשבון מספר תאריך שם כתובת רחוב עיר ואת וכן וכי אבל אזי לכן כדי מנת בלבד יותר פחות הכל חלק סך סכום דוח דוחות כספיים ליום נכסים התחייבות הון עודף גירעון הכנסות הוצאות ביאור ביאורים סעיף שנה שנת ינואר בדצמבר בינואר מזומנים שווי רכוש קבוע'.split(/\s+/).filter(Boolean));

/* מילון שמות משפחה ישראליים נפוצים ומובחנים (לא מילים שגורות) */
const SURNAMES = new Set((`
אבוקסיס אביטן אברהמי אברמוביץ אדלר אדרי אוחיון אוחנה אוחנונה אזולאי אלבז אלוני אלמוג אלקיים
אמסלם אסולין אפללו אשכנזי בוזגלו בורנשטיין ביטון בן-דוד בן-חמו בנימיני ברזילי ברוש ברקוביץ
גבאי גולדברג גולדשטיין גרוס גרין גרינברג דהן דיין הורוביץ הלוי הרשקוביץ ובר וייס ועקנין זילברמן
זקן חדד חזן חסון טולדנו טל יעקובי ישראלי כהן כץ לביב לוי לרנר מזרחי מימון מלכה מרגלית משולם
נחמיאס סבן סגל סויסה סולומון עטיה פורת פישר פלד פרידמן פרלמן צור קליין קפלן רבינוביץ רוזן
רוזנברג רוזנטל שוורץ שטרן שמואלי שפירא שרעבי ששון
אבוטבול אבוחצירא אביטבול אברגיל אדלשטיין אהרוני אוזן איפרגן אלימלך אלפסי אנגל אסרף בוקובזה
בירנבאום בלום בן-שושן בן-עמי בנאי ברגר גורדון גלעדי גנץ גרוסמן דאהר דוידוב דוידוביץ
 וולך וקנין זריהן חורי טייב יונס יפרח כחלון לנדאו מוסאי מועלם
מלול מנסור מרקוביץ סויד סלאמה סעדה עמר פולק פינטו פינקלשטיין פרץ פרנקל 
צוקרמן קעדאן קרמר רביבו רוזנפלד שאער שושן שטיין שניידר תורגמן
`).split(/\s+/).filter(Boolean));

/* שמות משפחה שהם גם מילים שגורות ("אנשי סגל", "תושב ישראלי"). הם נחשבים שם משפחה רק
   אחרי שם פרטי מהמילון, ולא אחרי כל מילה. */
const SURNAME_WORDS = new Set('סגל זקן טל צור דיין חזן מלכה ישראלי ששון מרגלית פלד פורת גרין גרוס פרץ לוי כהן שושן חורי עמר'.split(' '));

/* נירמול עברי: הסרת ניקוד, איחוד גרשיים, הסרת סימוני כיוון */
/* תיקון אותיות סופיות משובשות ב-PDF ישראליים: הפונט ממפה ך/ם/ן/ף/ץ דרך windows-1255
   ו-pdf.js מפענח אותן כ-Latin-1 (ê/í/ï/ó/õ). ההחלפה רק כשהתו צמוד לאות עברית, בטוח לטקסט לועזי. */
function fixHebFinals(s){
  if(!s) return s;
  const map={'ê':'ך','í':'ם','ï':'ן','ó':'ף','õ':'ץ'};
  return s
    .replace(/([\u0590-\u05FF])([êíïóõ])/g, (m,h,l)=>h+map[l])
    .replace(/([êíïóõ])([\u0590-\u05FF])/g, (m,l,h)=>map[l]+h);
}

/* גליפים שהפונט לא מיפה ל-Unicode מגיעים מ-pdf.js באזור השימוש הפרטי
   (U+E000..U+F8FF). בדוח כספי אמיתי כל האותיות נ הגיעו כך, כלומר "פרינדס"
   הגיע כ-פ,ר,י,U+F8FF,ד,ס. האות לא נעלמה, היא פשוט לא ניתנת לזיהוי, ולכן
   כל השוואה לטקסט שהמשתמש מקליד נכשלה. כאן כל תו כזה הופך לתו כללי
   שמתאים לכל אות בהשוואה. */
const WILD = '\u0001';
function normHeb(s){
  return (s||'')
    .replace(/[\uE000-\uF8FF]/g, WILD)
    .replace(/[\u0591-\u05C7]/g,'')
    .replace(/[״”“]/g,'"').replace(/[׳’‘]/g,"'")
    .replace(/[\u200e\u200f\u202a-\u202e]/g,'')
    .replace(/ך/g,'כ').replace(/ם/g,'מ').replace(/ן/g,'נ').replace(/ף/g,'פ').replace(/ץ/g,'צ')
    .trim();
}
function normSpaceless(s){ return normHeb(s).replace(/\s+/g,''); }

/* חילוץ טקסט מ-PDF עברי מפיל אותיות בשקט, בגלל מיפוי הגליפים בפונט. בדוח
   כספי אמיתי שנבדק היו אפס מופעים של נ מתוך 4,084 אותיות עבריות, כלומר
   "פרינדס" יצא "פרידס". לכן כל התאמה מקבלת גם מעבר רופף שמתעלם מהאותיות
   האלה בשני הצדדים. הוא רץ רק כשההתאמה המדויקת נכשלה, ורק ממחרוזת באורך
   סביר, כדי לא לייצר התאמות שווא. */
/* מה שהמעבר הרופף מתעלם ממנו: פיסוק בלבד. בדוח אמיתי הטקסט הוא
   "פרידס , רשת ..." עם פסיק, והמשתמש מקליד את השם בלי פסיק.
   באותיות עצמן אין לגעת: אות שהפונט לא מיפה כבר הפכה לתו כללי ב-normHeb,
   והסרת אותיות בנוסף לכך יוצרת פער אורך ושוברת דווקא את ההתאמה. */
const DROPPABLE = /[,.\-"'׳״()\[\]:;־]/;
function isDroppable(ch){ return DROPPABLE.test(ch); }
function normLoose(s){
  const t=normSpaceless(s); let out='';
  for(const ch of t) if(!isDroppable(ch)) out+=ch;
  return out;
}
/* indexOf שמתחשב בתו הכללי: תו לא מזוהה בטקסט מתאים לכל אות ביעד */
function wildIndexOf(hay, needle, from){
  if(!needle || !needle.length) return -1;
  // ברוב המסמכים אין תווים לא מזוהים. במקרה הזה חיפוש רגיל מהיר בהרבה,
  // וההשוואה תו-תו נשמרת רק למסמכים שבאמת צריכים אותה.
  if(hay.indexOf(WILD)===-1) return hay.indexOf(needle, Math.max(0, from||0));
  const n=needle.length, last=hay.length-n;
  for(let i=Math.max(0,from||0); i<=last; i++){
    let ok=true;
    for(let j=0;j<n;j++){
      const h=hay.charCodeAt(i+j);
      if(h!==1 && h!==needle.charCodeAt(j)){ ok=false; break; }
    }
    if(ok) return i;
  }
  return -1;
}
function wildIncludes(hay, needle){ return wildIndexOf(hay, needle, 0)!==-1; }

function looseIndexMap(str){
  const idx=[]; let out='';
  for(let i=0;i<str.length;i++){ if(!isDroppable(str[i])){ idx.push(i); out+=str[i]; } }
  return {str:out, idx};
}

function typeLabel(t){
  if(t==='name') return 'שם / מונח';
  if(t==='field') return 'שדה לפי תווית';
  if(t==='company') return 'שם חברה';
  if(t==='birth') return 'תאריך לידה';
  if(t==='addr') return 'כתובת';
  if(t==='date') return 'תאריך';
  return (DETECTORS[t]||{}).label || t;
}
function typeTag(t){
  if(t==='name') return '[שם]';
  if(t==='field') return '[שדה]';
  if(t==='company') return '[חברה]';
  if(t==='birth') return '[ת.לידה]';
  if(t==='addr') return '[כתובת]';
  if(t==='date') return '[תאריך]';
  return (DETECTORS[t]||{}).tag || '[מוסתר]';
}

/* מחליף ערך בטקסט לפי המצב הנבחר */
function applyMode(value, type){
  if(state.mode==='delete') return '';
  if(state.mode==='token')  return pseudoToken(value, type);
  if(state.mode==='label')  return typeTag(type);
  // mask
  const d=value.replace(/\D/g,'');
  if(d.length>=4){
    const keepStart = value.slice(0, Math.min(2, value.length));
    const last4 = d.slice(-4);
    return keepStart + 'X'.repeat(Math.max(1,value.length-6)) + last4;
  }
  return 'X'.repeat(value.length);
}

/* מבצע החלפה של כל הממצאים המסומנים בטקסט */
function redactText(text, fileId){
  let t=text;
  const active = state.findings.filter(f=>f.fileId===fileId && f.checked);
  // מיון לפי אורך יורד כדי להחליף קודם ערכים ארוכים
  active.sort((a,b)=>b.value.length-a.value.length);
  active.forEach(f=>{
    const rep = applyMode(f.value, f.type);
    t = t.split(f.value).join(rep);
  });
  return t;
}

/* ============ ניהול קבצים ============ */
let fid=0;
function addFiles(fileList){
  let addedImg=false;
  [...fileList].forEach(f=>{
    // תיקייה שלמה מביאה איתה גם קבצים שאינם רלוונטיים
    if(!SUPPORTED_EXT.test(f.name)) return;
    const ext=f.name.split('.').pop().toLowerCase();
    const isImage=['png','jpg','jpeg','webp'].includes(ext);
    if(isImage) addedImg=true;
    state.files.push({id:++fid, name:f.name, ext, file:f, text:'', images:[], isImage});
  });
  renderFiles();
  if(addedImg) renderVisual();
  document.getElementById('scan').disabled = state.files.length===0;
  document.getElementById('download').disabled = state.files.length===0;
}
const SUPPORTED_EXT=/\.(xlsx|xls|csv|docx|pdf|png|jpe?g|webp)$/i;
function renderFiles(){
  const el=document.getElementById('files');
  const sh=document.getElementById('scanhint');
  if(sh) sh.textContent = !state.files.length ? 'קודם בוחרים קבצים' : (state.files.length===1 ? 'קובץ אחד נבחר' : state.files.length+' קבצים נבחרו');
  if(!state.files.length){el.innerHTML='';return;}
  // מאות קבצים: לא מציגים מאות תגיות, רק ספירה וכפתור ניקוי
  if(state.files.length>15){
    el.innerHTML='<span class="filepill">'+state.files.length+' קבצים נטענו</span> '+
      '<button class="mini" id="clearfiles" type="button">הסר את כל הקבצים</button>';
    document.getElementById('clearfiles').onclick=()=>{
      state.files=[]; state.findings=[]; state.previewId=null;
      renderFiles(); renderFindings(); renderVisual();
      document.getElementById('scan').disabled=true;
      document.getElementById('download').disabled=true;
    };
    return;
  }
  el.innerHTML = state.files.map(f=>
    `<span class="filepill">${escapeHtml(f.name)}<span class="x" data-id="${f.id}">✕</span></span>`).join('');
  el.querySelectorAll('.x').forEach(x=>x.onclick=()=>{
    state.files=state.files.filter(f=>f.id!=x.dataset.id);
    state.findings=state.findings.filter(f=>f.fileId!=x.dataset.id);
    renderFiles(); renderFindings(); renderVisual();
    const empty=state.files.length===0;
    document.getElementById('scan').disabled = empty;
    document.getElementById('download').disabled = empty;
  });
}

function namesList(){
  return document.getElementById('names').value.split('\n').map(s=>s.trim()).filter(Boolean);
}

/* ============ קריאת תוכן קבצים ============ */
async function readFileContent(f){
  const buf = await f.file.arrayBuffer();
  if(f.ext==='xlsx'||f.ext==='xls'||f.ext==='csv'){
    let wb;
    if(f.ext==='csv'){
      // CSV: פענוח מפורש כ-UTF-8 (עם נפילה ל-windows-1255 לקבצים ישנים), מונע ג'יבריש בעברית
      let txt8 = new TextDecoder('utf-8',{fatal:false}).decode(buf);
      if(txt8.includes('\uFFFD')){ try{ txt8 = new TextDecoder('windows-1255').decode(buf); }catch(e){} }
      wb = XLSX.read(txt8,{type:'string'});
    } else {
      wb = XLSX.read(buf,{type:'array'});
    }
    f.workbook = wb;
    let txt='';
    wb.SheetNames.forEach(sn=>{
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn],{header:1,defval:''});
      rows.forEach(r=> txt += r.join(' | ')+'\n');
    });
    f.text=txt;
  } else if(f.ext==='docx'){
    const res = await mammoth.extractRawText({arrayBuffer:buf});
    f.text=res.value;
  } else if(f.ext==='pdf'){
    const pdf = await pdfjsLib.getDocument({data:buf, isEvalSupported:false, worker:pdfWorker()}).promise;
    let txt='', lineTxt=''; const perPage=[]; const tops=[];
    for(let p=1;p<=pdf.numPages;p++){
      const page=await pdf.getPage(p);
      const tc=await page.getTextContent();
      const ptxt=tc.items.map(i=>fixHebFinals(i.str)).join(' ');
      perPage.push(normSpaceless(ptxt).length);
      // הרצועה העליונה של העמוד. שם הישות בדוח כספי יושב שם וחוזר בכל עמוד.
      const vp=page.getViewport({scale:1});
      tops.push(tc.items
        .filter(it=>it.transform && it.transform[5] > vp.height*0.86)
        .map(i=>fixHebFinals(i.str)).join(' ').replace(/\s+/g,' ').trim());
      txt += ptxt+'\n';
      // טקסט לפי שורות נדרש רק כשהעמוד מפורק לאותיות בודדות
      const strs=tc.items.map(i=>(i.str||'').trim()).filter(Boolean);
      if(strs.length>20 && strs.filter(x=>[...x].length===1).length > strs.length*0.6)
        lineTxt += pageLinesText(itemsFromTc(tc, vp, 1))+'\n';
    }
    f.pageTops = tops;
    f.text=txt;
    f.lineText=lineTxt;
    f.numPages=pdf.numPages;
    f.isPdf=true;
    // סף לכל עמוד בנפרד: בספר דוחות חלק מהעמודים סרוקים וחלק טקסטואליים,
    // וסף גלובלי אחד סיווג את כולם לא נכון.
    f.pageScanned = perPage.map(n=>n<15);
    f.scannedCount = f.pageScanned.filter(Boolean).length;
    f.scanned = f.scannedCount > 0;
    // רינדור מחדש מוחק מלבנים ידניים ותוצאות OCR. לכן מרנדרים רק כשאין
    // עמודים, או כשהרזולוציה שונתה בכוונה.
    if(!(f.pages && f.pages.length && f.renderedScale===(state.pdfScale||2))){
      // במצב אצווה רק הקובץ המוצג מקבל קנבס. לכל השאר נשמרים רק מיקומי הטקסט,
      // והם מרונדרים בזמן ההפקה עמוד-עמוד. עמוד מרונדר תופס כ-16MB, ו-350
      // קבצים עם תצוגה מקדימה מלאה מפילים את הכרטיסייה.
      if(wantsPreview(f)) await renderPdfPreview(f);
      else await buildLightPages(f, pdf);
    }
    closePdf(pdf);
  } else if(['png','jpg','jpeg','webp'].includes(f.ext)){
    f.text=''; f.isImage=true;
  }
}

/* טקסט העמוד כפי שהוא נקרא בעין: שורה אחר שורה, עם רווח היכן שיש פער בין מקטעים וטאב
   בין טורים. ב-PDF רבים pdf.js מחזיר מקטע לכל אות, ואז בטקסט הרגיל (מקטעים מופרדים
   ברווח) אין מילים שלמות, וכל זיהוי שנשען על מילים (שמות מהמילון, כתובת, תאריך לידה,
   מספר אחרי תווית) אינו מוצא דבר. הטקסט הזה נסרק בנוסף לטקסט הרגיל, לא במקומו. */
function pageLinesText(items){
  const HEB=/[\u0590-\u05FF\uFB1D-\uFB4F]/;
  return groupLines(items).map(ln=>{
    const byX=ln.parts.slice().sort((p,q)=>p.it.rect.x-q.it.rect.x);
    const segs=[[]];
    byX.forEach((p,i)=>{
      if(i){ const a=byX[i-1].it.rect, b=p.it.rect; if(b.x-(a.x+a.w)+4 > Math.max(a.h,b.h)*1.2) segs.push([]); }
      segs[segs.length-1].push(p);
    });
    const lineRtl=ln.parts.some(p=>HEB.test(p.it.str||''));
    if(lineRtl) segs.reverse();
    return segs.map(seg=>{
      const rtl=seg.some(p=>HEB.test(p.it.str||''));
      return partsText(seg.slice().sort((p,q)=> rtl ? (q.it.rect.x+q.it.rect.w)-(p.it.rect.x+p.it.rect.w) : p.it.rect.x-q.it.rect.x), rtl);
    }).filter(Boolean).join('\t');
  }).filter(Boolean).join('\n');
}
/* מרנדר עמודי PDF לקנבסים + שומר מיקום כל מקטע טקסט (לסימון אוטומטי) */
function itemsFromTc(tc, vp, scale){
  return tc.items.map(it=>{
    const m=pdfjsLib.Util.transform(vp.transform, it.transform);
    const fh=Math.hypot(m[2],m[3])||12*scale;
    const w=(it.width||(it.str||'').length*fh*0.5)*scale;
    return {str:fixHebFinals(it.str||''), rect:{x:m[4]-2, y:m[5]-fh-1, w:w+4, h:fh+4}};
  });
}
/* שמירת המלבנים הידניים ביחס לגודל העמוד, כדי שישרדו רינדור מחדש ושינוי רזולוציה */
function keepManual(f){
  const rel=(e,b)=>({x:b.x/e.canvas.width, y:b.y/e.canvas.height, w:b.w/e.canvas.width, h:b.h/e.canvas.height});
  return (f.pages||[]).map(e=>({
    boxes:(e.manualBoxes||[]).map(b=>rel(e,b)),
    ocrDone: !!e.ocrDone,
    // מילות ה-OCR ומיקומן נשמרות גם הן, אחרת רינדור מחדש מוחק את מה שזוהה בעמוד סרוק
    ocrText: e.ocrText||'',
    ocrItems:(e.ocrItems||[]).map(it=>({str:it.str, rect:rel(e,it.rect)}))
  }));
}
function restoreManual(f, keep){
  f.pages.forEach((e,i)=>{
    e.__file=f;
    const prev=keep[i];
    if(prev){
      const abs=r=>({x:r.x*e.canvas.width, y:r.y*e.canvas.height, w:r.w*e.canvas.width, h:r.h*e.canvas.height});
      e.ocrDone=prev.ocrDone;
      e.ocrText=prev.ocrText||'';
      if(prev.ocrItems && prev.ocrItems.length) e.ocrItems=prev.ocrItems.map(it=>({str:it.str, rect:abs(it.rect)}));
      prev.boxes.forEach(r=>e.manualBoxes.push(abs(r)));
    }
  });
}
/* כל מקטעי הטקסט של עמוד: שכבת הטקסט של ה-PDF, ובעמוד סרוק גם המילים שזיהה ה-OCR.
   כך אותו מנגנון מיקום משרת את שניהם, וערך שאושר אחרי ה-OCR ממוקם בדיוק כמו ערך
   שאושר לפניו. */
function entryItems(entry){
  const a=entry.items||[], b=entry.ocrItems||[];
  return b.length ? a.concat(b) : a;
}

/* מרנדר עמודי PDF לקנבסים + שומר מיקום כל מקטע טקסט (לסימון אוטומטי) */
async function renderPdfPreview(f){
  const src=await pdfjsLib.getDocument({data:await f.file.arrayBuffer(), isEvalSupported:false, worker:pdfWorker()}).promise;
  const keep=keepManual(f);
  f.pages=[]; const scale=state.pdfScale||2;
  for(let p=1;p<=src.numPages;p++){
    const page=await src.getPage(p);
    const vp=page.getViewport({scale});
    const canvas=document.createElement('canvas');
    canvas.width=vp.width; canvas.height=vp.height;
    const ctx=canvas.getContext('2d');
    await page.render({canvasContext:ctx, viewport:vp}).promise;
    const items=itemsFromTc(await page.getTextContent(), vp, scale);
    // עותק בסיס כקנבס ולא כ-ImageData: ImageData מחזיק 4 בתים לפיקסל ב-JS heap,
    // וספר של עשרות עמודים בסקייל 2 היה מפיל את הכרטיסייה.
    const baseCv=document.createElement('canvas');
    baseCv.width=canvas.width; baseCv.height=canvas.height;
    baseCv.getContext('2d').drawImage(canvas,0,0);
    f.pages.push({canvas, baseCv, items, autoBoxes:[], manualBoxes:[],
      pageNum:p, label:f.name+', עמוד '+(p)+'/'+src.numPages});
  }
  closePdf(src);
  restoreManual(f, keep);
  f.renderedScale=scale;
  computeAutoBoxes(f);
  computeAnchorBoxes(f);
}

/* עמודים "קלים" בלי קנבס: רק מידות ומיקומי טקסט. מספיק לזיהוי, למלבנים
   האוטומטיים ולהשחרה לפי תווית. הרינדור עצמו קורה בהפקה. */
async function buildLightPages(f, pdf){
  const keep=keepManual(f);
  f.pages=[]; const scale=state.pdfScale||2;
  for(let p=1;p<=pdf.numPages;p++){
    const page=await pdf.getPage(p);
    const vp=page.getViewport({scale});
    f.pages.push({canvas:{width:vp.width, height:vp.height}, light:true,
      items:itemsFromTc(await page.getTextContent(), vp, scale),
      autoBoxes:[], manualBoxes:[], pageNum:p, label:f.name+', עמוד '+p+'/'+pdf.numPages});
  }
  restoreManual(f, keep);
  f.renderedScale=scale;
  computeAutoBoxes(f);
  computeAnchorBoxes(f);
}

/* משחרר את הקנבסים של קובץ שהפסיק להיות מוצג, ומשאיר אותו כעמודים קלים */
function demotePreview(f){
  (f.pages||[]).forEach(e=>{
    if(e.light || !e.canvas || !e.canvas.getContext) return;
    const w=e.canvas.width, h=e.canvas.height;
    e.canvas.width=0; e.canvas.height=0;
    if(e.baseCv){ e.baseCv.width=0; e.baseCv.height=0; }
    e.canvas={width:w, height:h}; e.baseCv=null; e.light=true; e.redraw=null; e.effective=null;
  });
}

function visualFiles(){
  return state.files.filter(x=>x.isPdf||x.isImage||x.ext==='pdf'||['png','jpg','jpeg','webp'].includes(x.ext));
}
function batchMode(){ return visualFiles().length > state.previewLimit; }
function previewFileId(){
  const vf=visualFiles();
  if(state.previewId!==null && vf.some(x=>x.id===state.previewId)) return state.previewId;
  return vf.length ? vf[0].id : null;
}
function wantsPreview(f){ return !batchMode() || f.id===previewFileId(); }

/* ============ השחרה לפי תווית ============
   בקבלות ובחשבוניות באותו מבנה, שם הלקוח יושב אחרי תווית קבועה ("לכבוד:"),
   אבל המיקום שלו זז בין מסמכים כשמספר השורות משתנה. לכן לא מלבן לפי מיקום,
   אלא הערך שבא אחרי התווית: באותה שורה, ואם אין, בשורה שמתחתיה. */
function anchorLabels(){
  const el=document.getElementById('anchors');
  return (el ? el.value : '').split(/[\n,]/).map(x=>x.trim()).filter(Boolean);
}
function groupLines(items){
  const its=items.map((it,idx)=>({it,idx})).filter(o=>o.it && o.it.rect && (o.it.str||'').trim());
  its.sort((a,b)=>(a.it.rect.y+a.it.rect.h/2)-(b.it.rect.y+b.it.rect.h/2));
  const lines=[];
  its.forEach(o=>{
    const yc=o.it.rect.y+o.it.rect.h/2;
    const ln=lines[lines.length-1];
    if(ln && Math.abs(yc-ln.yc) < Math.max(3, Math.min(o.it.rect.h, ln.h)*0.45)) ln.parts.push(o);
    else lines.push({yc, h:o.it.rect.h, parts:[o]});
  });
  return lines;
}
function unionRect(rs){
  const x0=Math.min(...rs.map(r=>r.x)), y0=Math.min(...rs.map(r=>r.y));
  const x1=Math.max(...rs.map(r=>r.x+r.w)), y1=Math.max(...rs.map(r=>r.y+r.h));
  return {x:x0, y:y0, w:x1-x0, h:y1-y0};
}
/* טקסט קריא מחלקי שורה בסדר קריאה: רווח היכן שיש פער בין האותיות */
function partsText(parts, rtl){
  let out='', prev=null;
  parts.forEach(p=>{
    const r=p.it.rect;
    if(prev){
      // המלבנים מרופדים ב-2 פיקסלים מכל צד, ולכן הרווח האמיתי בין שני מקטעים גדול ב-4.
      // בלי התיקון הזה, ב-PDF שבו כל אות היא מקטע נפרד, "דנה לוי" נאסף כ"דנהלוי".
      const gap=(rtl ? prev.x-(r.x+r.w) : r.x-(prev.x+prev.w))+4;
      if(gap > (Math.min(r.h, prev.h)-4)*0.15) out+=' ';
    }
    out+=p.it.str; prev=r;
  });
  return out.replace(/\s+/g,' ').trim();
}
function computeAnchorBoxes(f){
  const labels=anchorLabels().map(l=>{ const n=normLoose(l); return {raw:l, n, nr:[...n].reverse().join(''), rtl:/[\u0590-\u05FF]/.test(l)}; })
                             .filter(l=>l.n.length>=2);
  const values=new Set();
  (f.pages||[]).forEach(entry=>{
    entry.anchorBoxes=[];
    const pageItems=entryItems(entry);
    if(!labels.length || !pageItems.length) return;
    const W=entry.canvas.width;
    const lines=groupLines(pageItems);
    lines.forEach((ln,li)=>{
      labels.forEach(lab=>{
        // pdf.js מחזיר לעיתים פריט נפרד לכל אות, ולכן מחפשים את התווית ברצף
        // התווים של השורה כולה, בסדר הקריאה, וכל תו יודע מאיזה פריט הגיע.
        const ord=ln.parts.slice().sort((p,q)=>lab.rtl ? q.it.rect.x-p.it.rect.x : p.it.rect.x-q.it.rect.x);
        let str=''; const owner=[];
        ord.forEach((p,pi)=>{ for(const ch of normLoose(p.it.str)){ str+=ch; owner.push(pi); } });
        let pos=wildIndexOf(str, lab.n, 0), len=lab.n.length;
        if(pos===-1){ pos=wildIndexOf(str, lab.nr, 0); }   // פריט שהטקסט בו נשמר בסדר הפוך
        if(pos===-1) return;
        const ia=owner[pos], ib=owner[pos+len-1];
        const L=unionRect(ord.slice(Math.min(ia,ib), Math.max(ia,ib)+1).map(p=>p.it.rect));
        const last=Math.max(ia,ib);
        let picked=[];
        if(pos+len<owner.length && owner[pos+len]===last) picked.push(ord[last]);   // הערך באותו פריט כמו התווית
        // אותה שורה: הפריטים שאחרי התווית בסדר הקריאה, עד פער גדול
        let edge=lab.rtl ? L.x : L.x+L.w;
        for(let k=last+1;k<ord.length;k++){
          const r=ord[k].it.rect;
          const gap=lab.rtl ? edge-(r.x+r.w) : r.x-edge;
          if(gap>W*0.08) break;
          edge=lab.rtl ? r.x : r.x+r.w;
          if(!picked.length && !normLoose(ord[k].it.str)) continue;   // נקודתיים אחרי התווית
          picked.push(ord[k]);
        }
        // אין ערך באותה שורה: השורה הבאה, באותה עמודה
        const nx=lines[li+1];
        if(!picked.length && nx && nx.yc-ln.yc < Math.max(L.h, ln.h)*3.2){
          // נקודת עוגן: מה שבשורה הבאה חופף לתווית אופקית (או הקרוב אליה). משם
          // מתרחבים לשני הכיוונים דרך פערים של בין מילים, ועוצרים בפער של עמודה.
          // רוחב התווית לבדו לא מספיק: שם ארוך חורג ממנו, והאות הראשונה נשארה גלויה.
          const row=nx.parts.slice().sort((p,q)=>p.it.rect.x-q.it.rect.x);
          let seeds=row.map((p,i)=>i).filter(i=>{ const r=row[i].it.rect; return r.x < L.x+L.w+2 && r.x+r.w > L.x-2; });
          if(!seeds.length){
            const cx=L.x+L.w/2; let best=-1, bd=W*0.15;
            row.forEach((p,i)=>{ const r=p.it.rect, d=Math.abs(r.x+r.w/2-cx); if(d<bd){ bd=d; best=i; } });
            if(best>=0) seeds=[best];
          }
          if(seeds.length){
            let i0=Math.min(...seeds), i1=Math.max(...seeds);
            const wordGap=W*0.05;
            while(i0>0 && row[i0].it.rect.x-(row[i0-1].it.rect.x+row[i0-1].it.rect.w) < wordGap) i0--;
            while(i1<row.length-1 && row[i1+1].it.rect.x-(row[i1].it.rect.x+row[i1].it.rect.w) < wordGap) i1++;
            picked=row.slice(i0,i1+1).sort((p,q)=>lab.rtl ? q.it.rect.x-p.it.rect.x : p.it.rect.x-q.it.rect.x);
          }
        }
        if(!picked.length) return;
        let value=partsText(picked, lab.rtl);
        if(picked.length===1 && picked[0]===ord[last])
          value=value.replace(lab.raw,'').replace(/^[\s:,\-]+|[\s:,\-]+$/g,'');
        if(normLoose(value).length<2) return;
        values.add(value);
        picked.forEach(p=>entry.anchorBoxes.push({x:p.it.rect.x, y:p.it.rect.y, w:p.it.rect.w, h:p.it.rect.h, value}));
      });
    });
  });
  return [...values];
}

/* ============ הצמדת מלבן לדיו ============
   מיקום מלבן אוטומטי נגזר ממיקום המקטע ומרוחב תו ממוצע, וזו הערכה: בגופן רגיל האותיות
   אינן ברוחב אחיד, זנב של אות (g, p, ק, ן) יורד מתחת לשורה, ולפעמים רוחב המקטע שהתקבל
   קצר מהטקסט שצויר. התוצאה הייתה קצה של אות או ספרה שמציץ מהמלבן. לכן לפני הציור
   בודקים את תמונת העמוד עצמה: כל עוד הטור או השורה שצמודים למלבן מבחוץ מכילים דיו,
   המלבן מתרחב, עד רווח לבן או עד גבול קבוע. מלבן שצויר ביד אינו משתנה. */
function snapToInk(ctx, cvW, cvH, b){
  const lim=Math.round(Math.min(44, Math.max(8, b.h*0.6))), vlim=Math.round(Math.min(22, Math.max(5, b.h*0.4)));
  const X0=Math.max(0,Math.floor(b.x)-lim), X1=Math.min(cvW,Math.ceil(b.x+b.w)+lim);
  const Y0=Math.max(0,Math.floor(b.y)-vlim), Y1=Math.min(cvH,Math.ceil(b.y+b.h)+vlim);
  const w=X1-X0, h=Y1-Y0;
  if(w<3 || h<3) return b;
  let img;
  try{ img=ctx.getImageData(X0,Y0,w,h).data; }catch(e){ return b; }
  const dark=(x,y)=>{ const i=(y*w+x)*4; return img[i]+img[i+1]+img[i+2]<420; };
  let l=Math.max(0,Math.floor(b.x)-X0), r=Math.min(w,Math.ceil(b.x+b.w)-X0);
  let t=Math.max(0,Math.floor(b.y)-Y0), bt=Math.min(h,Math.ceil(b.y+b.h)-Y0);
  const colInk=x=>{ for(let y=t;y<bt;y++) if(dark(x,y)) return true; return false; };
  const rowInk=y=>{ for(let x=l;x<r;x++) if(dark(x,y)) return true; return false; };
  while(l>0 && colInk(l-1)) l--;
  while(r<w && colInk(r)) r++;
  while(t>0 && rowInk(t-1)) t--;
  while(bt<h && rowInk(bt)) bt++;
  return {x:X0+l-1, y:Y0+t-1, w:r-l+2, h:bt-t+2};
}
/* המלבן כפי שיצויר על קנבס התצוגה: מלבן אוטומטי או מלבן של שדה לפי תווית מוצמד לדיו,
   והתוצאה נשמרת עליו. מלבן ידני ומלבן תבנית מצוירים בדיוק כפי שסומנו. */
function drawnRect(entry, b){
  if(b.tpl || (entry.manualBoxes||[]).includes(b)) return b;
  if(b._snap) return b._snap;
  const base=entry.baseCv;
  if(!base || !base.getContext || !base.width) return b;
  if(!entry._baseCtx || entry._baseCtx.canvas!==base) entry._baseCtx=base.getContext('2d',{willReadFrequently:true});
  b._snap=snapToInk(entry._baseCtx, base.width, base.height, b);
  return b._snap;
}

/* ============ המלבנים האפקטיביים של עמוד ============ */
const boxKey=b=>Math.round(b.x)+','+Math.round(b.y)+','+Math.round(b.w)+','+Math.round(b.h);
function templateBoxesFor(entry){
  const W=entry.canvas.width, H=entry.canvas.height;
  return (state.templateBoxes||[]).map(r=>({x:r.x*W, y:r.y*H, w:r.w*W, h:r.h*H, tpl:r}));
}
function anchorBoxesFor(entry){
  const f=entry.__file; if(!f || !entry.anchorBoxes || !entry.anchorBoxes.length) return [];
  const ok=new Set(activeFor(f).map(a=>normSpaceless(a.value)));
  return entry.anchorBoxes.filter(b=>ok.has(normSpaceless(b.value)));
}
function effectiveBoxes(entry){
  const sup=entry.suppressed||new Set();
  return [...(entry.autoBoxes||[]), ...(entry.manualBoxes||[]), ...anchorBoxesFor(entry), ...templateBoxesFor(entry)]
    .filter(b=>!sup.has(boxKey(b)));
}
function redrawAll(){ state.files.forEach(f=>(f.pages||[]).forEach(e=>e.redraw&&e.redraw())); }
function renderTemplateBar(){
  const el=document.getElementById('tplinfo'); if(!el) return;
  const n=(state.templateBoxes||[]).length;
  el.innerHTML = n ? 'מלבני תבנית: <b>'+n+'</b>, חלים על כל הקבצים <button class="mini" id="tplclear" type="button">נקה תבנית</button>' : '';
  const b=document.getElementById('tplclear');
  if(b) b.onclick=()=>{ state.templateBoxes=[]; redrawAll(); renderTemplateBar(); };
}

/* מלבן משנה צמוד: חותך את rect הפריט רק לטווח התווים pos..pos+len מתוך count תווים.
   מכבד כיוון RTL (הטקסט העברי זורם מימין לשמאל בתוך הפריט). */
function subRect(rect, count, pos, len, rtl){
  if(!rect || count<=0){ return rect; }
  const cw = rect.w / count;
  let x;
  if(rtl){ x = rect.x + rect.w - (pos+len)*cw; }  // RTL: תו 0 בקצה הימני
  else   { x = rect.x + pos*cw; }
  // cx ו-cw שומרים את התחום בלי הריפוד, לשימוש שכבת הטקסט. המיקום הוא הערכה לפי רוחב
  // אחיד, ולכן בזמן הציור המלבן מוצמד לדיו שעל העמוד (snapToInk).
  const pad = 2;
  return { x: x-pad, y: rect.y-1, w: len*cw+2*pad, h: rect.h+2, cx: x, cw: len*cw };
}

/* מחשב מלבנים אוטומטיים לפי הממצאים המאושרים (לכל עמודי ה-PDF).
   בונה זרם תווים מנורמל *על פני כל הפריטים* בעמוד, כך שערך מפוצל בין פריטים עדיין נתפס,
   ומצייר מלבן צמוד לכל *מופע* בנפרד, בכל העמודים ולכל אורך המסמך. */
function computeAutoBoxes(f){
  const active=activeFor(f);
  const base=active.map(a=>normSpaceless(a.value)).filter(t=>t.length>=2);
  const targets=[];
  base.forEach(t=>{ targets.push(t); targets.push(t.split('').reverse().join('')); }); // גם סדר הפוך (ארטיפקט RTL של pdf.js)
  const placed=new Set();      // יעדים שנמצא להם לפחות מיקום אחד על עמוד כלשהו
  (f.pages||[]).forEach(entry=>{
    entry.autoBoxes=[];
    const items=entryItems(entry);
    // זרם תווים מנורמל ללא רווחים, כל תו יודע לאיזה פריט הוא שייך ומה מיקומו היחסי בתוכו
    const stream=[]; // {itemIdx, cpos, ccount}
    items.forEach((it,idx)=>{
      const chars = normHeb(it.str).replace(/\s+/g,'');
      const n = chars.length;
      for(let j=0;j<n;j++){ stream.push({itemIdx:idx, cpos:j, ccount:n}); }
    });
    const bigStr = items.map(it=>normHeb(it.str).replace(/\s+/g,'')).join('');
    const loose = looseIndexMap(bigStr);
    // חיפוש כל מופע של כל יעד. אם היעד לא נמצא כלשונו, מחפשים ברצף הרופף
    // ומתרגמים את המיקום חזרה לרצף המלא.
    targets.forEach((T,ti)=>{
      let positions=[];
      let from=0,p0;
      while((p0=wildIndexOf(bigStr,T,from))!==-1){ positions.push([p0, T.length]); from=p0+T.length; }
      if(!positions.length){
        const TL=normLoose(T);
        if(TL.length>=4){
          let f2=0,q;
          while((q=wildIndexOf(loose.str,TL,f2))!==-1){
            const start=loose.idx[q], end=loose.idx[q+TL.length-1];
            positions.push([start, end-start+1]);
            f2=q+TL.length;
          }
        }
      }
      if(positions.length) placed.add(base[ti>>1]);
      positions.forEach(([pos, len])=>{
        // אוסף את התווים pos..pos+T.length ומקבץ אותם לפי פריט
        const byItem={};
        for(let k=pos;k<pos+len;k++){
          const s=stream[k]; if(!s) continue;
          (byItem[s.itemIdx]=byItem[s.itemIdx]||[]).push(s);
        }
        Object.keys(byItem).forEach(iidx=>{
          const arr=byItem[iidx];
          const it=items[iidx];
          if(!it||!it.rect) return;
          const first=arr[0].cpos, last=arr[arr.length-1].cpos;
          const rtl=/[\u0590-\u05FF]/.test(it.str||''); // פריט עברי => RTL
          entry.autoBoxes.push(subRect(it.rect, arr[0].ccount, first, (last-first+1), rtl));
        });
      });
    });
  });
  // ערך שאושר להסתרה ולא נמצא לו מקום באף עמוד אינו מושחר בפועל. בלי הרישום הזה
  // הוא נשאר גלוי בתמונת הפלט, והאימות לא יכול היה לדעת על כך.
  const anchored=new Set();
  (f.pages||[]).forEach(e=>(e.anchorBoxes||[]).forEach(b=>anchored.add(normSpaceless(b.value))));
  f.unplaced = (f.pages && f.pages.length)
    ? active.filter(a=>{ const t=normSpaceless(a.value); return t.length>=2 && !placed.has(t) && !anchored.has(t); })
    : [];
}

/* ============ סריקה ============ */
/* סריקה אחת בכל פעם. הקלדת שם ואז לחיצה על "סריקת הקבצים" מפעילה שתי סריקות ברצף (שינוי
   בשדה, ואז הלחיצה), ושתי סריקות במקביל היו כותבות לאותה רשימת ממצאים. סריקה שהתבקשה
   בזמן שאחרת רצה מתבצעת פעם אחת, מיד אחריה. */
let _scanRun=null, _scanAgain=false;
function scan(){
  if(_scanRun){ _scanAgain=true; return _scanRun; }
  _scanRun=(async ()=>{
    try{ do{ _scanAgain=false; await scanOnce(); } while(_scanAgain); }
    finally{ _scanRun=null; }
  })();
  return _scanRun;
}
async function scanOnce(){
  const status=document.getElementById('status');
  status.textContent='קורא וסורק...';
  state.findings=[]; state.findLimit=200;
  resetDownloads();        // הפקה קודמת כבר אינה משקפת את מה שנבחר
  syncDetectors();
  let visual=false, i=0;
  for(const f of state.files){
    i++;
    if(state.files.length>5){
      status.textContent='קורא וסורק '+i+' מתוך '+state.files.length+'...';
      await new Promise(r=>setTimeout(r,0));   // מאפשר לדפדפן לעדכן את המסך
    }
    try{
      await readFileContent(f);
      if(f.text) scanText(f.text).forEach(h=>addFinding(f,h));
      if(f.lineText) scanText(f.lineText).forEach(h=>addFinding(f,h));
      if(f.isPdf || f.isImage) computeAnchorBoxes(f).forEach(v=>addFinding(f,{type:'field', value:v}));
      // ממצאים שמקורם ב-OCR נשמרים ומוזנים מחדש, אחרת סריקה חוזרת מוחקת אותם
      if(f.ocrText) scanText(f.ocrText).forEach(h=>addFinding(f,h));
      if(f.isImage || f.isPdf){ visual=true; }
    }catch(e){ console.error(e); status.textContent='שגיאה בקריאת '+f.name+': '+e.message; }
  }
  // אחרי שכל הממצאים נאספו, מחשבים מלבנים אוטומטיים לכל PDF ולכל תמונה שעברה OCR
  state.files.forEach(f=>{ if(f.isPdf || f.isImage) computeAutoBoxes(f); });
  state.scanned=true;
  renderFindings();
  renderEntityCandidates();
  renderVisual();
  renderOcrPrompt();
  const scannedPages=state.files.reduce((n,f)=>n+(f.scannedCount||0),0);
  status.textContent = 'נמצאו להסתרה: '+heN(findingGroups().length,'ערך אחד','ערכים')+' '+(state.files.length===1 ? 'בקובץ אחד' : 'ב-'+state.files.length+' קבצים')+'.';
  document.getElementById('download').disabled = false;
}
function addFinding(f,h){
  const nv=normSpaceless(h.value);
  if(state.findings.some(x=>x.fileId===f.id && (x.value===h.value || normSpaceless(x.value)===nv))) return;
  state.findings.push({id:'fnd'+(state.findings.length)+'_'+Math.floor(Math.random()*1e5),
    type:h.type, value:h.value, fileId:f.id, checked:true});
}

/* מציג מועמדים לשם הישות. זו הנקודה שבה הכלי נכשל בפועל: הוא הסתמך על כך
   שהמשתמש ידביק את השם, ובלי זה פשוט לא מצא אותו. */
function renderEntityCandidates(){
  const el=document.getElementById('entcands'); if(!el) return;
  const ta=document.getElementById('names');
  const already=normSpaceless(ta.value||'');
  const listed=[], seen=new Set();
  state.files.forEach(f=>{
    (entityCandidates(f)||[]).forEach(c=>{
      const k=normSpaceless(c.value);
      if(!k || seen.has(k)) return;
      if(already && already.indexOf(k)!==-1) return;   // כבר ברשימת ההשחרה
      seen.add(k); listed.push(c);
    });
  });
  if(!listed.length){ el.style.display='none'; el.innerHTML=''; return; }
  el.style.display='block';
  el.innerHTML='נראה שאלה שמות הארגון במסמך. לחיצה מוסיפה אותם להסתרה:'+
    '<div class="modes">'+
    listed.map((c,i)=>'<button class="mini entcand" data-i="'+i+'">'+escapeHtml(c.value)+
      ' <span style="opacity:.6">('+escapeHtml(c.why)+')</span></button>').join('')+
    '<button class="mini entcand-all">הוסף את כולם</button></div>';
  const addAll=vals=>{
    ta.value=(ta.value ? ta.value.replace(/\s*$/,'')+'\n' : '')+vals.join('\n');
    scan();
  };
  el.querySelectorAll('.entcand').forEach(b=>b.onclick=()=>addAll([listed[+b.dataset.i].value]));
  const all=el.querySelector('.entcand-all');
  if(all) all.onclick=()=>addAll(listed.map(c=>c.value));
}

/* מציע להריץ OCR פעם אחת, במקום להריץ אותו מאחורי הגב בכל סריקה.
   סריקה חוזרת קורית גם בלחיצה על מועמד לשם הישות, ו-OCR אוטומטי היה מוסיף
   דקות לכל לחיצה כזאת. */
function ocrTargets(){
  const t=[];
  state.files.forEach(f=>{
    (f.pages||[]).forEach(e=>{
      const isScanned = f.isImage || (f.pageScanned ? !!f.pageScanned[(e.pageNum||1)-1] : !!f.scanned);
      if(isScanned && !e.ocrDone) t.push({f, e});
    });
  });
  return t;
}
function renderOcrPrompt(){
  const el=document.getElementById('ocrprompt'); if(!el) return;
  const t=ocrTargets();
  if(!t.length){ el.innerHTML=''; el.style.display='none'; return; }
  el.style.display='block';
  const blocked = (location.protocol==='file:');
  el.className='note warn';
  el.innerHTML =
    '<b>'+heN(t.length,'עמוד סרוק אחד','עמודים סרוקים')+'.</b> בלי זיהוי טקסט הכלי לא יודע מה כתוב שם, ולכן לא יסתיר שם דבר.'+
    (blocked
      ? '<div><b>זיהוי הטקסט (OCR) אינו זמין כי הכלי נפתח ישירות מהקובץ.</b> יש להפעיל דרך "הפעלת הכלי.bat", או לסמן ידנית בתצוגה המקדימה.</div>'
      : '<div><button class="btn" id="runocr" type="button">'+(t.length===1 ? 'זיהוי הטקסט בעמוד' : 'זיהוי הטקסט ב-'+t.length+' העמודים')+'</button> <span class="hint">כדקה לכל עשרה עמודים. רץ פעם אחת ונשמר.</span></div>');
  const btn=document.getElementById('runocr');
  if(btn) btn.onclick=async ()=>{
    const byFile=new Map();
    t.forEach(x=>{ if(!byFile.has(x.f)) byFile.set(x.f, []); byFile.get(x.f).push(x.e); });
    for(const [f, entries] of byFile) await runOcr(f, entries, btn);
    state.files.forEach(f=>{ if(f.isPdf || f.isImage) computeAutoBoxes(f); });
    state.files.forEach(f=>(f.pages||[]).forEach(e=>e.redraw&&e.redraw()));
    renderFindings(); renderEntityCandidates(); renderOcrPrompt();
  };
}

/* ============ תצוגת ממצאים ============ */
function findingGroups(){
  const map=new Map();
  state.findings.forEach(f=>{
    const k=valueKey(f.value);
    let g=map.get(k); if(!g){ g={key:k, type:f.type, value:f.value, items:[]}; map.set(k,g); }
    g.items.push(f);
  });
  return [...map.values()];
}
/* אחרי שינוי סימון: מחשב מחדש את המלבנים רק בקבצים שהושפעו */
function refreshBoxesFor(fileIds){
  resetDownloads();        // שינוי בסימון מבטל הפקה קודמת, כדי שלא יורד קובץ שאינו תואם לטבלה
  state.files.forEach(ff=>{
    if(!fileIds.has(ff.id) || !(ff.isPdf||ff.isImage)) return;
    computeAutoBoxes(ff); (ff.pages||[]).forEach(e=>e.redraw&&e.redraw());
  });
}
/* שורה לכל ערך, עם מספר הקבצים שבהם הוא מופיע. ב-350 קבלות הטבלה הקודמת הציגה שורה
   לכל ערך בכל קובץ, כלומר אלפי שורות שאי אפשר לעבור עליהן. */
function renderFindings(){
  const el=document.getElementById('findings');
  const cnt=document.getElementById('findcount');
  const tools=document.getElementById('findtools');
  const groups=findingGroups();
  if(cnt) cnt.textContent=groups.filter(g=>g.items.some(i=>i.checked)).length;
  renderNotFound();
  if(!state.findings.length){
    if(tools) tools.style.display='none';
    el.innerHTML='<div class="empty">לא נמצא בקבצים דבר להסתיר. אפשר להוסיף שמות ומונחים בשלב הקודם, או לסמן ידנית בתצוגה המקדימה.</div>';
    return;
  }
  // סרגל חיפוש וסינון: מוצג רק כשיש מספיק שורות כדי להצדיק אותו
  if(tools) tools.style.display = groups.length>8 ? 'flex' : 'none';
  const sel=document.getElementById('findtype');
  if(sel){
    const present=[...new Set(groups.map(g=>g.type))];
    if(state.findType && !present.includes(state.findType)) state.findType='';
    sel.innerHTML='<option value="">כל הסוגים</option>'+present.map(t=>'<option value="'+t+'"'+(t===state.findType?' selected':'')+'>'+escapeHtml(typeLabel(t))+'</option>').join('');
  }
  const q=normSpaceless(state.findQ||'');
  let list=groups.filter(g=>(!state.findType || g.type===state.findType) && (!q || normSpaceless(g.value).includes(q)));
  list.sort((a,b)=>typeLabel(a.type).localeCompare(typeLabel(b.type),'he') || b.items.length-a.items.length || a.value.localeCompare(b.value,'he'));
  const shown=list.slice(0, state.findLimit);
  const fname=id=>{ const f=state.files.find(x=>x.id==id); return f?f.name:''; };
  const multi=state.files.length>1;
  let html='<table class="findtable"><thead><tr><th style="width:44px"></th><th style="width:150px">סוג</th><th>הערך שיוסתר</th>'+
    (multi?'<th style="width:190px">היכן נמצא</th>':'')+'</tr></thead><tbody>';
  shown.forEach((g,gi)=>{
    const on=g.items.filter(i=>i.checked).length;
    const where = g.items.length===1 ? '<span class="file-tag">'+escapeHtml(fname(g.items[0].fileId))+'</span>'
      : '<button type="button" class="mini grp-open" data-g="'+gi+'">'+g.items.length+' קבצים'+(on && on<g.items.length ? ', '+on+' מסומנים' : '')+'</button>';
    html+='<tr><td><input type="checkbox" class="chk grp-chk" data-g="'+gi+'"'+(on===g.items.length?' checked':'')+'></td>'+
      '<td><span class="type-tag">'+escapeHtml(typeLabel(g.type))+'</span></td><td class="val">'+escapeHtml(g.value)+'</td>'+
      (multi?'<td>'+where+'</td>':'')+'</tr>';
    if(g.items.length>1 && state.findOpen.has(g.key)){
      html+='<tr class="grp-files"><td></td><td colspan="'+(multi?3:2)+'">'+g.items.slice(0,60).map(i=>
        '<label class="grp-file"><input type="checkbox" class="chk one-chk" data-id="'+i.id+'"'+(i.checked?' checked':'')+'> '+escapeHtml(fname(i.fileId))+'</label>').join('')+
        (g.items.length>60?'<span class="file-tag"> ועוד '+(g.items.length-60)+' קבצים</span>':'')+'</td></tr>';
    }
  });
  html+='</tbody></table>';
  if(list.length>shown.length) html+='<div class="actions"><button type="button" class="mini" id="findmore">הצג עוד '+Math.min(200,list.length-shown.length)+' מתוך '+(list.length-shown.length)+' שנותרו</button></div>';
  if(!list.length) html='<div class="empty">אין ממצאים שמתאימים לחיפוש.</div>';
  el.innerHTML=html;
  el.querySelectorAll('.grp-chk').forEach(c=>{
    const g=shown[+c.dataset.g], on=g.items.filter(i=>i.checked).length;
    c.indeterminate = on>0 && on<g.items.length;
    c.onchange=()=>{ g.items.forEach(i=>i.checked=c.checked); refreshBoxesFor(new Set(g.items.map(i=>i.fileId))); renderFindings(); };
  });
  el.querySelectorAll('.one-chk').forEach(c=>c.onchange=()=>{
    const f=state.findings.find(x=>x.id==c.dataset.id); if(!f) return;
    f.checked=c.checked; refreshBoxesFor(new Set([f.fileId])); renderFindings();
  });
  el.querySelectorAll('.grp-open').forEach(b=>b.onclick=()=>{
    const k=shown[+b.dataset.g].key;
    if(state.findOpen.has(k)) state.findOpen.delete(k); else state.findOpen.add(k);
    renderFindings();
  });
  const more=document.getElementById('findmore');
  if(more) more.onclick=()=>{ state.findLimit+=200; renderFindings(); };
}
/* מונחים שהמשתמש ביקש להסתיר ולא נמצאו באף קובץ. במסמך סרוק זה בדרך כלל אומר
   שה-OCR קרא את המילה אחרת, והיא תישאר גלויה אם לא יסמנו אותה ידנית. */
function renderNotFound(){
  const el=document.getElementById('notfound'); if(!el) return;
  if(!state.scanned){ el.style.display='none'; el.innerHTML=''; return; }
  const found=new Set(state.findings.map(f=>normSpaceless(f.value)));
  const missing=namesList().filter(n=>normSpaceless(n).length>=2 && !found.has(normSpaceless(n)));
  if(!missing.length){ el.style.display='none'; el.innerHTML=''; return; }
  el.style.display='block';
  el.innerHTML='<b>'+(missing.length===1 ? 'מונח אחד שביקשת להסתיר לא נמצא באף קובץ:' : missing.length+' מונחים שביקשת להסתיר לא נמצאו באף קובץ:')+'</b> '+
    missing.slice(0,12).map(escapeHtml).join(', ')+(missing.length>12?' ועוד '+(missing.length-12):'')+
    '. במסמך סרוק יש להריץ זיהוי טקסט או לסמן ידנית בתצוגה המקדימה.';
}
function escapeHtml(s){return s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

/* ============ תצוגה מקדימה: סימון אוטומטי + ידני + OCR ============ */
function setupCanvas(entry){
  const canvas=entry.canvas, ctx=canvas.getContext('2d');
  entry.autoBoxes=entry.autoBoxes||[]; entry.manualBoxes=entry.manualBoxes||[];
  entry.suppressed=entry.suppressed||new Set();
  const key=boxKey;
  entry.effective=()=>effectiveBoxes(entry);
  const redraw=()=>{
    if(entry.baseCv){ ctx.drawImage(entry.baseCv,0,0); }
    else if(entry.img){ ctx.drawImage(entry.img,0,0); }
    ctx.fillStyle='#000';
    entry.effective().forEach(b=>{ const d=drawnRect(entry,b); ctx.fillRect(d.x,d.y,d.w,d.h); });
  };
  if(!entry.baseCv){
    try{
      const bc=document.createElement('canvas');
      bc.width=canvas.width; bc.height=canvas.height;
      bc.getContext('2d').drawImage(entry.img || canvas,0,0);   // תמונת הבסיס, בלי מלבנים
      entry.baseCv=bc;
    }catch(e){}
  }
  const hitBox=(px,py)=>{ // מחזיר את המלבן העליון שמכיל את הנקודה
    const eff=entry.effective();
    for(let i=eff.length-1;i>=0;i--){ const b=eff[i]; if(px>=b.x&&px<=b.x+b.w&&py>=b.y&&py<=b.y+b.h) return b; }
    return null;
  };
  let drawing=false,sx=0,sy=0;
  const scale=()=>canvas.width/canvas.getBoundingClientRect().width;
  canvas.onmousedown=e=>{const s=scale();drawing=true;sx=e.offsetX*s;sy=e.offsetY*s;};
  canvas.onmousemove=e=>{ if(!drawing)return;const s=scale();redraw();
    ctx.fillStyle='rgba(0,0,0,.45)'; ctx.fillRect(sx,sy,e.offsetX*s-sx,e.offsetY*s-sy); };
  canvas.onmouseup=e=>{ if(!drawing)return;drawing=false;const s=scale();
    const w=e.offsetX*s-sx,h=e.offsetY*s-sy;
    if(Math.abs(w)>5&&Math.abs(h)>5){
      const box={x:Math.min(sx,sx+w),y:Math.min(sy,sy+h),w:Math.abs(w),h:Math.abs(h)};
      if(state.allPages){
        // תבנית: המלבן נשמר ביחס לגודל העמוד וחל על כל עמוד בכל קובץ, כולל
        // קבצים שלא מוצגים ושיתווספו אחר כך. בגרסה הקודמת ההעתקה הייתה רק בתוך
        // אותו קובץ, ולכן בקבלות של עמוד אחד לקובץ היא לא עשתה דבר.
        state.templateBoxes.push({x:box.x/canvas.width, y:box.y/canvas.height,
                                  w:box.w/canvas.width, h:box.h/canvas.height});
        redrawAll(); renderTemplateBar();
      } else {
        entry.manualBoxes.push(box);
      }
    } else {
      // לחיצה (בלי גרירה) על מלבן = ביטול המלבן הספציפי
      const b=hitBox(sx,sy);
      if(b && b.tpl){
        // מלבן תבנית: ביטול שלו חל על כל הקבצים, כמו שהוספתו חלה על כולם
        state.templateBoxes=state.templateBoxes.filter(r=>r!==b.tpl);
        redrawAll(); renderTemplateBar();
      } else if(b){
        const mi=entry.manualBoxes.indexOf(b);
        if(mi>=0) entry.manualBoxes.splice(mi,1);   // מלבן ידני -> הסרה
        else entry.suppressed.add(key(b));          // מלבן אוטומטי -> דיכוי
      }
    }
    redraw(); };
  entry.redraw=redraw; redraw();
}

/* קנבס ייעודי ל-OCR ברזולוציה גבוהה.
   קנבס התצוגה מרונדר בסקייל 2, כלומר כ-144 DPI, ומתחת לרזולוציה של סריקה
   ממכשיר משרדי. Tesseract בעברית זקוק לכ-300 DPI, ולכן העמוד מרונדר מחדש
   בסקייל 4 לצורך הזיהוי בלבד, והקואורדינטות מוחזרות לקנבס התצוגה לפי היחס. */
const OCR_SCALE = 4;
async function ocrSource(f, entry){
  if(!f.isPdf || !entry.pageNum || (state.pdfScale||2) >= OCR_SCALE)
    return {canvas: entry.canvas, ratio: 1, temp: false};
  const src=await pdfjsLib.getDocument({data: await f.file.arrayBuffer(), isEvalSupported:false, worker:pdfWorker()}).promise;
  const page=await src.getPage(entry.pageNum);
  const vp=page.getViewport({scale: OCR_SCALE});
  const c=document.createElement('canvas');
  c.width=vp.width; c.height=vp.height;
  await page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
  closePdf(src);
  return {canvas:c, ratio: entry.canvas.width/c.width, temp: true};
}

/* מריץ OCR על עמוד אחד או על כל עמודי המסמך, עם worker יחיד לכל הריצה.
   טעינת המנוע וחבילת השפה היא הפעולה היקרה, ואין טעם לשלם אותה לכל עמוד. */
async function runOcr(f, entries, btn){
  if(typeof Tesseract==='undefined'){ btn.textContent='מנוע ה-OCR לא נטען'; return; }
  const many = entries.length>1;
  const label0 = btn.textContent;
  btn.disabled=true;
  let worker=null;
  try{
    btn.textContent='טוען מנוע OCR...';
    // חובה נתיבים אבסולוטיים. Tesseract יוצר worker מ-blob ומריץ בתוכו
    // importScripts, ובהקשר של blob נתיב יחסי אינו חוקי ונכשל בשקט.
    const VENDOR = new URL('vendor/', document.baseURI).href;
    worker=await Tesseract.createWorker({
      workerPath: VENDOR + 'tesseract-worker.min.js',
      corePath:   VENDOR,
      langPath:   VENDOR + 'lang/',
      gzip: true
    });
    await worker.loadLanguage('heb+eng');
    await worker.initialize('heb+eng');
    let boxed=0, i=0; const done=[];
    for(const entry of entries){
      i++;
      btn.textContent = many ? `מריץ OCR, עמוד ${i} מתוך ${entries.length}...` : 'מריץ OCR...';
      const srcCv = await ocrSource(f, entry);
      const {data} = await worker.recognize(srcCv.canvas);
      const words = (data.words||[]).filter(w=>w && (w.text||'').trim() && w.bbox && w.bbox.x1>w.bbox.x0);
      entry.ocrText = fixHebFinals(words.map(w=>w.text).join(' '));
      // המילים ומיקומן נשמרות על העמוד. בגרסה הקודמת סומנו רק מילים שהתאימו למונח שהיה
      // פעיל ברגע ה-OCR, ולכן מונח שנוסף אחר כך אושר בטבלת הממצאים אבל לא הושחר בתמונה.
      const rt=srcCv.ratio;
      entry.ocrItems = words.map(w=>({str:fixHebFinals(w.text),
        rect:{x:w.bbox.x0*rt-2, y:w.bbox.y0*rt-2, w:(w.bbox.x1-w.bbox.x0)*rt+4, h:(w.bbox.y1-w.bbox.y0)*rt+4}}));
      entry.ocrDone = true;
      f.ocrText = (f.pages||[]).map(e=>e.ocrText||'').filter(Boolean).join('\n');   // נשמר לסריקות הבאות
      syncDetectors();
      scanText(entry.ocrText).forEach(h=>addFinding(f,h));
      done.push(entry);
      if(srcCv.temp){ srcCv.canvas.width=0; srcCv.canvas.height=0; }   // שחרור זיכרון מיד
    }
    // המיקום נעשה באותו מנגנון של PDF טקסטואלי, על מילות ה-OCR, אחרי שכל העמודים זוהו
    computeAnchorBoxes(f).forEach(v=>addFinding(f,{type:'field', value:v}));
    computeAutoBoxes(f);
    done.forEach(e=>{ boxed+=(e.autoBoxes||[]).length+(e.anchorBoxes||[]).length; e.redraw&&e.redraw(); });
    renderFindings();
    btn.textContent = boxed
      ? `OCR הושלם, ${boxed} אזורים סומנו. אפשר להוסיף ידנית.`
      : 'OCR הושלם. לא נמצאה התאמה למונחים שהוזנו, אפשר להוסיף מונחים או לסמן ידנית.';
  }catch(e){
    console.error(e);
    btn.textContent='שגיאת OCR: '+((e && e.message) ? e.message : e);
    const st=document.getElementById('status');
    if(st) st.textContent = location.protocol==='file:'
      ? 'ה-OCR נכשל כי הכלי נפתח בלחיצה כפולה. יש לסגור ולהריץ את "הפעלת הכלי.bat" מאותה תיקייה.'
      : 'ה-OCR נכשל בטעינת מנוע הזיהוי. יש לוודא שתיקיית vendor שלמה לצד index.html, ולנסות שוב.';
  }
  finally{
    if(worker){ try{ await worker.terminate(); }catch(e){} }
    btn.disabled=false;
    if(btn.textContent==='טוען מנוע OCR...') btn.textContent=label0;
  }
}
function ocrEntry(f, entry, btn){ return runOcr(f, [entry], btn); }

async function forceTextMode(f){
  const status=document.getElementById('status');
  try{
    // קריאה מחדש של הטקסט מהקובץ (למקרה של שכבת OCR מ-ABBYY)
    const buf=await f.file.arrayBuffer();
    const pdf=await pdfjsLib.getDocument({data:buf, isEvalSupported:false, worker:pdfWorker()}).promise;
    let txt='';
    for(let p=1;p<=pdf.numPages;p++){
      const page=await pdf.getPage(p);
      const tc=await page.getTextContent();
      txt+=tc.items.map(i=>fixHebFinals(i.str)).join(' ')+'\n';
    }
    closePdf(pdf);
    f.text=txt;
    if(normSpaceless(txt).length<5){
      status.textContent='לא נמצאה שכבת טקסט בקובץ '+f.name+', כנראה עדיין סרוק. יש להמיר ב-ABBYY ל-searchable PDF.';
      return;
    }
    f.scanned=false; f.pages=null;
    syncDetectors();
    state.findings=state.findings.filter(x=>x.fileId!==f.id);
    scanText(f.text).forEach(h=>addFinding(f,h));
    renderFindings(); renderVisual();
    status.textContent='הקובץ '+f.name+' טופל כטקסט, הזיהוי רץ אוטומטית.';
  }catch(e){ console.error(e); status.textContent='שגיאה: '+e.message; }
}

function renderVisual(){
  const card=document.getElementById('imgcard'), area=document.getElementById('imgarea');
  const allVisual=state.files.filter(f=>f.isImage||f.isPdf);
  if(!allVisual.length){ card.style.display='none'; return; }
  const batch=batchMode();
  const files = batch ? allVisual.filter(f=>f.id===previewFileId()) : allVisual;
  card.style.display='block'; area.innerHTML='';
  // כפתור לביטול כל ההשחרות (אוטומטיות + ידניות)
  const clearBar=document.createElement('div');
  clearBar.className='pvbar';
  const allLbl=document.createElement('label');
  const allCb=document.createElement('input');
  allCb.type='checkbox'; allCb.className='chk'; allCb.checked=state.allPages;
  allCb.onchange=()=>{ state.allPages=allCb.checked; };
  allLbl.appendChild(allCb);
  allLbl.appendChild(document.createTextNode('מלבן חדש יחול על כל העמודים בכל הקבצים'));
  const clearBtn=document.createElement('button'); clearBtn.className='mini';
  clearBtn.textContent='ביטול כל ההשחרות';
  clearBtn.onclick=clearAllRedactions;
  clearBar.appendChild(allLbl); clearBar.appendChild(clearBtn); area.appendChild(clearBar);
  const tpl=document.createElement('div'); tpl.id='tplinfo'; tpl.className='hint'; area.appendChild(tpl);
  if(batch){
    // מאות קבצים: קובץ אחד מוצג בכל פעם, השאר מרונדרים רק בהפקה
    const bar=document.createElement('div'); bar.className='hint';
    bar.className='pvbar';
    const lab=document.createElement('span');
    lab.innerHTML='<b>'+allVisual.length+' קבצים.</b> מוצג אחד בכל פעם:';
    const sel=document.createElement('select');
    allVisual.forEach(f=>{ const o=document.createElement('option'); o.value=f.id; o.textContent=f.name;
      if(f.id===previewFileId()) o.selected=true; sel.appendChild(o); });
    sel.onchange=async ()=>{
      const old=state.files.find(x=>x.id===previewFileId());
      const nf=state.files.find(x=>x.id==sel.value);
      state.previewId=nf.id;
      if(old && old!==nf && old.isPdf) demotePreview(old);
      if(nf.isPdf && (!nf.pages || nf.pages.some(e=>e.light))){
        const st=document.getElementById('status'); if(st) st.textContent='מרנדר תצוגה מקדימה...';
        await renderPdfPreview(nf);
        if(st) st.textContent='';
      }
      renderVisual();
    };
    bar.appendChild(lab); bar.appendChild(sel); area.appendChild(bar);
  }
  files.forEach(f=>{
    // בונים קנבס מתמונה (אם עדיין לא)
    if(f.isImage && !f.pages){
      const canvas=document.createElement('canvas');
      const img=new Image();
      const entry={canvas, autoBoxes:[], manualBoxes:[], label:f.name, img, __file:f};
      f.pages=[entry];
      img.onload=()=>{ canvas.width=img.width; canvas.height=img.height; setupCanvas(entry); };
      img.src=URL.createObjectURL(f.file);
    }
    // כותרת הקובץ + בקרות ברמת המסמך
    const head=document.createElement('div'); head.className='hint';
    head.className='pvhead';
    const title=document.createElement('span'); title.textContent=f.name; head.appendChild(title);
    if(f.scanned){
      const abbyy=document.createElement('button'); abbyy.className='mini';
      abbyy.textContent='כבר עבר OCR? טפל כטקסט'; abbyy.onclick=()=>forceTextMode(f);
      head.appendChild(abbyy);
      if((f.pages||[]).length>1){
        const allOcr=document.createElement('button'); allOcr.className='mini';
        allOcr.textContent=`OCR על כל ${f.pages.length} העמודים`;
        allOcr.onclick=()=>runOcr(f, f.pages, allOcr);
        head.appendChild(allOcr);
      }
    }
    // שדה: השחר טקסט נוסף בכל המסמך
    const term=document.createElement('input'); term.type='text'; term.placeholder='מילה או שם להסתרה בכל המסמך, ואז Enter';
    term.onkeydown=e=>{ if(e.key==='Enter'){ e.preventDefault(); addRedactionTerm(f, term.value.trim()); term.value=''; } };
    head.appendChild(term);
    area.appendChild(head);

    (f.pages||[]).forEach(entry=>{
      const wrap=document.createElement('div'); wrap.className='imgcanvaswrap';
      const bar=document.createElement('div'); bar.className='imgtitle';
      const name=document.createElement('span'); name.textContent=entry.label||f.name;
      const btns=document.createElement('span'); btns.style.display='flex'; btns.style.gap='8px';
      const pageIsScanned = f.isImage ||
        (f.pageScanned ? !!f.pageScanned[(entry.pageNum||1)-1] : !!f.scanned);
      if(pageIsScanned){
        const ocr=document.createElement('button'); ocr.className='mini';
        ocr.textContent = window.__noOcr ? 'OCR דורש הפעלת הכלי.bat' : 'OCR, זהה וסמן';
        if(window.__noOcr) ocr.title='דפדפנים חוסמים את מנוע ה-OCR בפרוטוקול file://';
        ocr.onclick=()=>ocrEntry(f, entry, ocr); btns.appendChild(ocr);
      }
      const undo=document.createElement('button'); undo.className='mini'; undo.textContent='בטל מלבן ידני אחרון';
      undo.onclick=()=>{ entry.manualBoxes.pop(); entry.redraw&&entry.redraw(); };
      btns.appendChild(undo);
      bar.appendChild(name); bar.appendChild(btns);
      wrap.appendChild(bar); wrap.appendChild(entry.canvas); area.appendChild(wrap);
      if(entry.canvas.width && !entry.img) setupCanvas(entry);   // עמוד PDF כבר מרונדר
    });
  });
}

/* מבטל את כל ההשחרות: מבטל סימון כל הממצאים ומנקה מלבנים אוטומטיים+ידניים */
function clearAllRedactions(){
  state.findings.forEach(fd=>fd.checked=false);
  state.templateBoxes=[];
  state.files.forEach(f=>{ (f.pages||[]).forEach(e=>{ e.autoBoxes=[]; e.manualBoxes=[]; e.anchorBoxes=[]; e.redraw&&e.redraw(); }); });
  renderFindings(); renderTemplateBar();
  const st=document.getElementById('status'); if(st) st.textContent='כל ההשחרות בוטלו. אפשר לסמן מחדש בטבלת הממצאים או לצייר ידנית.';
}

/* מוסיף מונח להשחרה בכל המסמך: מוסיף לרשימה, מעדכן ממצאים ומלבנים */
function addRedactionTerm(f, term){
  if(!term) return;
  // מוסיפים לרשימת השמות (כדי שיחול גם על Word/Excel) ולממצאים
  const ta=document.getElementById('names');
  if(normSpaceless(ta.value).indexOf(normSpaceless(term))===-1) ta.value=(ta.value?ta.value+'\n':'')+term;
  addFinding(f,{type:'name', value:term});
  computeAutoBoxes(f);
  (f.pages||[]).forEach(e=>e.redraw&&e.redraw());
  renderFindings();
}

/* ============ הפקת קבצים נקיים ============ */
/* שלב 4: יצוא Markdown נקי ל-LLM, טקסט אחרי החלפת נתונים אישיים בתוויות ([שם], [ת"ז]...) */
function buildRedactedMarkdown(){
  const parts=[];
  const skipped=[];
  for(const f of state.files){
    if(!f.text || !f.text.trim()){ skipped.push(f.name); continue; }
    const clean=redactPlain(f.text, buildTargets(f));
    parts.push('# '+f.name+'\n\n'+clean.trim()+'\n');
  }
  if(!parts.length) return null;
  let md=parts.join('\n---\n\n');
  if(skipped.length){
    md+='\n---\n\n> הערה: הקבצים הבאים הם תמונות/סריקות ללא שכבת טקסט ולכן אינם כלולים כאן: '+skipped.join(', ')+'. עבורם יש להשתמש בקובץ המושחר (PDF תמונה / תמונה).\n';
  }
  return new Blob([md], {type:'text/markdown;charset=utf-8'});
}

async function downloadClean(){
  const dl=document.getElementById('dlstatus'); dl.textContent='מפיק...';
  resetDownloads();
  const outputs=[];
  let k=0;
  for(const f of state.files){
    k++;
    if(state.files.length>5){ dl.textContent='מפיק '+k+' מתוך '+state.files.length+'...'; await new Promise(r=>setTimeout(r,0)); }
    try{
      let r=null;
      if(f.ext==='xlsx'||f.ext==='xls'){ r=await exportExcel(f,'xlsx'); }
      else if(f.ext==='csv'){ r=await exportExcel(f,'csv'); }
      else if(f.ext==='docx'){ dl.textContent='מפיק Word...'; r=await exportDocx(f); }
      else if(f.ext==='pdf'){ if(state.files.length<=5) dl.textContent='מפיק PDF...'; r=await exportPdf(f); }
      else if(f.isImage){ r=await exportImage(f); }
      if(r) outputs.push(r);
    }catch(e){console.error(e); dl.textContent='שגיאה ב-'+f.name+': '+e.message;}
  }
  if(document.getElementById('mdout')?.checked){
    const mdBlob=buildRedactedMarkdown();
    if(mdBlob) outputs.push({blob:mdBlob, name:'redacted.md'});
  }
  if(!outputs.length){ dl.textContent='לא הופקו קבצים.'; return; }
  if(outputs.length===1){
    dl.textContent='מוכן:';
    offerDownload(outputs[0].blob, outputs[0].name);
  } else {
    dl.textContent='אורז ל-ZIP...';
    const zip=new JSZip();
    outputs.forEach(o=>zip.file(o.name, o.blob));
    const zb=await zip.generateAsync({type:'blob'});
    dl.textContent=`${outputs.length} קבצים מוכנים בקובץ ZIP אחד:`;
    offerDownload(zb, 'קבצים_נקיים.zip');
  }
  // קובץ המפתח מוצע בנפרד ובכוונה, ולא נכנס ל-ZIP, כדי שלא יועלה למודל בטעות
  if(state.mode==='token'){
    const kb=buildKeyFile();
    if(kb) offerDownload(kb, 'מפתח פענוח - לא להעלות למודל.txt', true);
  }
  const stripped=state.files.reduce((n,f)=>n+(f.strippedMedia||0),0);
  if(stripped) dl.textContent+=` הוסרו ${stripped} תמונות/אובייקטים מוטמעים.`;
  await verifyOutputs(outputs);
  setExportButton(true);
}
/* מציג כפתור הורדה שהמשתמש לוחץ עליו. לחיצה יזומה לא נחסמת ע"י הדפדפן */
let _urls=[];
/* אחרי הפקה מוצלחת הפעולה הראשית היא ההורדה, ולכן כפתור ההפקה מפנה לה את המקום */
function setExportButton(done){
  const b=document.getElementById('download'); if(!b) return;
  if(!b.dataset.label) b.dataset.label=b.innerHTML;
  b.classList.toggle('big', !done); b.classList.toggle('ghost', !!done);
  b.innerHTML = done ? 'הפקה מחדש' : b.dataset.label;
}
function resetDownloads(){
  setExportButton(false);
  _urls.forEach(u=>{ try{URL.revokeObjectURL(u);}catch(e){} });
  _urls=[];
  const links=document.getElementById('dllinks'); if(links) links.innerHTML='';
  const v=document.getElementById('verify'); if(v) v.innerHTML='';
}
function offerDownload(blob, name, ghost){
  const links=document.getElementById('dllinks');
  const url=URL.createObjectURL(blob); _urls.push(url);
  const a=document.createElement('a');
  a.href=url; a.download=name;
  a.className='btn'+(ghost?' ghost':' big');
  a.textContent='הורדה: '+name;
  links.appendChild(a);
}

/* ============ אימות הפלט ============
   ערכו של כלי השחרה נמדד ביכולת להוכיח שההשחרה עבדה. לכן אחרי ההפקה מחלצים
   טקסט מהקובץ שנוצר ובודקים שאף ערך מאושר לא שרד בו, וגם לא בשם הקובץ. */
async function extractOutputText(name, blob){
  const ext=(name.split('.').pop()||'').toLowerCase();
  try{
    if(ext==='xlsx'||ext==='xls'||ext==='csv'){
      const wb=XLSX.read(new Uint8Array(await blob.arrayBuffer()),{type:'array'});
      let t='';
      wb.SheetNames.forEach(sn=>{
        t+=sn+'\n';
        const ws=wb.Sheets[sn];
        XLSX.utils.sheet_to_json(ws,{header:1,defval:''}).forEach(r=>t+=r.join(' ')+'\n');
        Object.keys(ws).forEach(k=>{ const c=ws[k]; if(c&&c.f) t+=' '+c.f; if(c&&c.l&&c.l.Target) t+=' '+c.l.Target; });
      });
      return t;
    }
    if(ext==='docx'){
      const zip=await JSZip.loadAsync(await blob.arrayBuffer());
      let t='';
      for(const n of Object.keys(zip.files)){
        const ent=zip.files[n];
        if(!ent || ent.dir) continue;           // רשומת תיקייה: zip.file() מחזיר null
        if(/^word\/.*\.xml$/.test(n) || /^docProps\/.*\.xml$/.test(n))
          t+=' '+(await ent.async('string')).replace(/<[^>]+>/g,' ');
      }
      return unescapeXml(t);
    }
    if(ext==='pdf'){
      const pdf=await pdfjsLib.getDocument({data:new Uint8Array(await blob.arrayBuffer()), isEvalSupported:false, worker:pdfWorker()}).promise;
      let t='';
      for(let p=1;p<=pdf.numPages;p++){
        const tc=await (await pdf.getPage(p)).getTextContent();
        t+=tc.items.map(i=>fixHebFinals(i.str)).join(' ')+'\n';
      }
      closePdf(pdf);
      return t;
    }
    if(ext==='md'||ext==='txt') return await blob.text();
  }catch(e){ console.error(e); return null; }
  return '';   // תמונה: אין שכבת טקסט לחלץ
}

/* בודק בתמונה שנכתבה לפלט (אחרי הקידוד ל-JPEG או ל-PNG) שכל מלבן באמת שחור.
   מחזיר את מספר המלבנים שאינם שחורים, או 1- כשלא ניתן היה לפענח את התמונה. */
async function boxesNotDark(bytes, mime, boxes, cw, ch){
  if(!boxes.length) return 0;
  let bmp;
  try{ bmp=await createImageBitmap(new Blob([bytes],{type:mime})); }catch(e){ return -1; }
  const c=document.createElement('canvas'); c.width=bmp.width; c.height=bmp.height;
  const ctx=c.getContext('2d',{willReadFrequently:true}); ctx.drawImage(bmp,0,0);
  const sx=bmp.width/cw, sy=bmp.height/ch; let bad=0;
  for(const bx of boxes){
    let x0=Math.max(0,Math.ceil(bx.x*sx)), y0=Math.max(0,Math.ceil(bx.y*sy));
    let x1=Math.min(c.width,Math.floor((bx.x+bx.w)*sx)), y1=Math.min(c.height,Math.floor((bx.y+bx.h)*sy));
    if(x1-x0>8){ x0+=2; x1-=2; }      // שולי המלבן מתרככים בקידוד JPEG
    if(y1-y0>8){ y0+=2; y1-=2; }
    if(x1<=x0 || y1<=y0) continue;    // מלבן שכולו מחוץ לעמוד
    const d=ctx.getImageData(x0,y0,x1-x0,y1-y0).data;
    const step=4*Math.max(1,Math.floor((d.length/4)/5000));
    let dark=0, tot=0;
    for(let i=0;i<d.length;i+=step){ tot++; if(d[i]+d[i+1]+d[i+2]<150) dark++; }
    if(tot && dark/tot<0.97) bad++;
  }
  c.width=0; c.height=0; if(bmp.close) bmp.close();
  return bad;
}

/* מה ידוע על קובץ מקור חזותי לפני שמסתכלים על הפלט: כמה השחרות יש בו, אילו עמודים
   סרוקים נשארו בלי OCR ובלי אף השחרה, ואילו ערכים אושרו ולא אותרו על העמוד. */
function fileDiagnostics(f){
  const d={visual:!!(f.isPdf||f.isImage), boxes:0, scannedOpen:0, scannedUnread:0, unplaced:[], active:activeFor(f).length};
  if(!d.visual) return d;
  const pages=f.pages||[];
  pages.forEach(e=>{
    const n=effectiveBoxes(e).length; d.boxes+=n;
    const scanned = f.isImage || (f.pageScanned ? !!f.pageScanned[(e.pageNum||1)-1] : !!f.scanned);
    if(scanned && !e.ocrDone){ if(n===0) d.scannedOpen++; else d.scannedUnread++; }
  });
  if(f.isImage && !pages.length){ if((state.templateBoxes||[]).length) d.scannedUnread=1; else d.scannedOpen=1; }
  d.unplaced=(f.unplaced||[]).filter(a=>a.checked).map(a=>a.value);
  return d;
}

async function verifyOutputs(outputs){
  const box=document.getElementById('verify'); if(!box) return;
  box.innerHTML='<div class="hint">מאמת את הקבצים שהופקו...</div>';
  const rows=[];
  const few=(arr,n)=>arr.slice(0,n).map(escapeHtml).join(', ')+(arr.length>n?' ועוד '+(arr.length-n):'');
  for(const o of outputs){
    const src = o.srcId ? state.files.find(x=>x.id===o.srcId) : null;
    const act = src ? activeFor(src) : state.files.reduce((acc,x)=>acc.concat(activeFor(x)),[]);
    const vals = [...new Set(act.map(a=>normSpaceless(a.value)).filter(v=>v.length>=2))];
    const txt = await extractOutputText(o.name, o.blob);
    const st = o.stats||{};
    const bad=[], warn=[];
    if(vals.some(v=>normSpaceless(o.name).includes(v))) bad.push('ערך שאושר להסתרה נשאר בשם הקובץ');
    let hits=[];
    if(txt===null) warn.push('לא ניתן היה לחלץ טקסט מהפלט כדי לבדוק אותו');
    else{
      const big=normSpaceless(txt);
      hits=vals.filter(v=>big.includes(v));
      if(hits.length) bad.push((hits.length===1 ? 'ערך אחד שאושר נשאר' : hits.length+' ערכים שאושרו נשארו')+' בטקסט של הפלט: '+few(hits,5));
    }
    if(st.badBoxes>0) bad.push(st.badBoxes===1 ? 'מלבן אחד לא יצא שחור בתמונת הפלט' : st.badBoxes+' מלבנים לא יצאו שחורים בתמונת הפלט');
    if(st.unchecked>0) warn.push('לא ניתן היה לבדוק את תמונת הפלט ב-'+st.unchecked+' עמודים');
    if(st.layerDropped) warn.push('שכבת הטקסט לא נוספה כי הבדיקה שלה לא עברה. הקובץ הופק כתמונה בלבד');
    const diag = src ? fileDiagnostics(src) : null;
    let good='';
    if(diag && diag.visual){
      if(diag.unplaced.length) bad.push('ערך שאושר לא אותר על העמוד ולכן לא הושחר: '+few(diag.unplaced,4));
      if(diag.scannedOpen) warn.push((diag.scannedOpen===1 ? 'עמוד סרוק אחד לא עבר זיהוי טקסט ואין בו אף השחרה' : diag.scannedOpen+' עמודים סרוקים לא עברו זיהוי טקסט ואין בהם אף השחרה')+'. הכלי לא יודע מה כתוב שם');
      // עמוד שהכלי לא קרא אינו "תקין" גם כשצויר בו מלבן: נבדק רק שהמלבן שחור, לא מה נשאר גלוי
      if(diag.scannedUnread) warn.push((diag.scannedUnread===1 ? 'עמוד סרוק אחד לא עבר זיהוי טקסט. מושחר בו רק מה שסומן ביד' : diag.scannedUnread+' עמודים סרוקים לא עברו זיהוי טקסט. מושחר בהם רק מה שסומן ביד')+', והכלי לא יודע מה עוד כתוב שם');
      const nb = st.boxes!==undefined ? st.boxes : diag.boxes;
      if(!bad.length && !warn.length && nb===0) warn.push('לא הושחר דבר בקובץ הזה');
      good = st.textual ? heN(nb,'מלבן אחד צויר','מלבנים צוירו')+' מעל הטקסט'
           : (nb===1 ? 'השחרה אחת, נבדקה בתמונת הפלט' : nb+' השחרות, כולן נבדקו בתמונת הפלט')+(st.textLayer ? ', ושכבת הטקסט נקייה' : (state.pdfMode==='layer' ? '. לא נכתב טקסט, כי העמודים הם תמונה' : ''));
    } else {
      if(src && !bad.length && !warn.length && act.length===0) warn.push('לא נמצא בקובץ הזה דבר להסתיר');
      good = vals.length===1 ? 'ערך אחד הוחלף ואינו בפלט' : vals.length+' ערכים הוחלפו ואינם בפלט';
    }
    rows.push({name:o.name, level: bad.length?'bad':(warn.length?'warn':'ok'), bad, warn, good,
               hitCount:hits.length, checked:vals.length});
  }
  const nBad=rows.filter(r=>r.level==='bad').length, nWarn=rows.filter(r=>r.level==='warn').length;
  state.verify={rows, bad:nBad, warn:nWarn};
  const word={ok:'תקין', warn:'לבדיקה', bad:'בעיה'};
  const head = nBad
    ? '<b class="vr-bad">אימות: '+(nBad===1 ? 'נמצאה בעיה בקובץ אחד. אין להעביר אותו' : 'נמצאו בעיות ב-'+nBad+' קבצים. אין להעביר אותם')+' לפני תיקון.</b>'
    : nWarn
      ? '<b class="vr-warn">אימות: '+(nWarn===1 ? 'קובץ אחד דורש' : nWarn+' קבצים דורשים')+' בדיקה ידנית לפני העברה.</b>'
      : '<b class="vr-ok">אימות עבר: '+(rows.length===1 ? 'הקובץ נבדק ולא נמצא בו' : 'כל '+rows.length+' הקבצים נבדקו ולא נמצא בהם')+' ערך מאושר.</b>';
  const tr=r=>'<tr><td class="fname">'+escapeHtml(r.name)+'</td><td><span class="vr-tag vr-'+r.level+'">'+word[r.level]+'</span></td><td>'+
    (r.level==='ok' ? r.good : r.bad.concat(r.warn).join('<br>'))+'</td></tr>';
  const table=list=>'<table style="margin-top:10px"><thead><tr><th>קובץ</th><th style="width:84px">מצב</th><th>פירוט</th></tr></thead><tbody>'+
    list.map(tr).join('')+'</tbody></table>';
  // בעשרות ומאות קבצים מוצגים קודם רק הקבצים שדורשים תשומת לב, והתקינים מקופלים
  const flagged=rows.filter(r=>r.level!=='ok'), fine=rows.filter(r=>r.level==='ok');
  let body;
  if(rows.length<=25) body=table(rows);
  else body=(flagged.length ? table(flagged) : '')+
    (fine.length ? '<details class="fold" style="margin-top:12px"><summary>'+heN(fine.length,'קובץ תקין אחד','קבצים תקינים')+'</summary>'+table(fine)+'</details>' : '');
  box.innerHTML =
    '<div class="verifybox">'+head+body+
    (nBad && state.pdfMode==='text'
      ? '<div style="margin-top:10px">שרידים ב-PDF הם התוצאה הצפויה של מצב "טקסטואלי", שמצייר מלבן מעל טקסט שנשאר קיים. להעלאה למודל יש להפיק שוב במצב "תמונה".</div>'
      : '')+
    '</div>';
}

/* עזר: אילו ממצאים פעילים לקובץ, וכל הטוקנים שלהם */
function activeFor(f){ return state.findings.filter(x=>x.fileId===f.id && x.checked)
  .sort((a,b)=>b.value.length-a.value.length); }

/* יעדי החלפה מנורמלים (ללא רווחים/ניקוד) + מחרוזת חלופה */
function buildTargets(f){
  return activeFor(f).map(a=>({tz:normSpaceless(a.value), rep:applyMode(a.value,a.type)}))
    .filter(t=>t.tz.length>=2);
}

/* ליבת הסתרה על פני מקטעי טקסט (runs), תופס גם ערך מפוצל בין מקטעים */
function redactCells(runs, targets){
  // תא לכל תו בכל המקטעים
  const cells=[];               // {ri, ch}
  runs.forEach((t,ri)=>{ for(const ch of t) cells.push({ri, ch}); });
  // רצף מנורמל ללא רווחים -> מיפוי לאינדקס התא
  const nzIdx=[], nzChar=[];
  cells.forEach((c,idx)=>{ const n=normHeb(c.ch); if(n && !/\s/.test(n)){ nzChar.push(n); nzIdx.push(idx); } });
  const NZ=nzChar.join('');
  const del=new Array(cells.length).fill(false);
  const ins={};
  const looseNZ=looseIndexMap(NZ);
  targets.forEach(t=>{
    const spans=[];
    let from=0,pos;
    while((pos=wildIndexOf(NZ, t.tz, from))!==-1){ spans.push([pos, t.tz.length]); from=pos+t.tz.length; }
    if(!spans.length){
      const tl=normLoose(t.tz);
      if(tl.length>=4){
        let f2=0,q;
        while((q=wildIndexOf(looseNZ.str,tl,f2))!==-1){
          const a=looseNZ.idx[q], b=looseNZ.idx[q+tl.length-1];
          spans.push([a, b-a+1]);
          f2=q+tl.length;
        }
      }
    }
    spans.forEach(([p,len])=>{
      const start=nzIdx[p], end=nzIdx[p+len-1];
      if(start===undefined || end===undefined) return;
      if(del[start]) return;          // כבר הוחלף על ידי ערך ארוך יותר או זהה
      ins[start]=(ins[start]||'')+t.rep;
      for(let k=start;k<=end;k++) del[k]=true;
    });
  });
  return {cells, del, ins};
}
function redactCore(runs, targets){
  const {cells, del, ins}=redactCells(runs, targets);
  const buf=runs.map(()=>[]);
  cells.forEach((c,idx)=>{ if(ins[idx]) buf[c.ri].push(ins[idx]); if(!del[idx]) buf[c.ri].push(c.ch); });
  return buf.map(a=>a.join(''));
}
function redactPlain(text, targets){ return redactCore([text||''], targets)[0]; }
function unescapeXml(s){ return (s||'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&'); }
function escapeXml(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

/* Excel: מחליף תא-תא, שומר RTL */
async function exportExcel(f, kind){
  const wb=f.workbook, targets=buildTargets(f);
  wb.SheetNames.forEach(sn=>{
    const ws=wb.Sheets[sn];
    ws['!sheetViews']=[{RTL:true}];
    Object.keys(ws).forEach(cell=>{
      if(cell[0]==='!')return;
      const c=ws[cell];
      if(!c) return;
      if(typeof c.v==='string'){
        const v=redactPlain(c.v, targets);
        c.v=v; if(c.w)c.w=v;
      } else if(typeof c.v==='number'){
        // תא מספרי: ת"ז, טלפון וחשבון עלולים להישמר כמספר, חובה לבדוק גם אותם
        const sv=String(c.v);
        const v=redactPlain(sv, targets);
        if(v!==sv){ c.t='s'; c.v=v; c.w=v; delete c.z; }
      }
      // נוסחה, הערת תא וקישור: שלושה מקומות שלא נגעו בהם קודם וערך יכול לשרוד בכל אחד
      if(c.f){ const nf=redactPlain(String(c.f), targets); if(nf!==c.f) c.f=nf; }
      if(Array.isArray(c.c)) c.c.forEach(cm=>{ if(!cm) return; if(cm.t) cm.t=redactPlain(String(cm.t),targets); cm.a=''; });
      if(c.l){
        if(c.l.Target)  c.l.Target =redactPlain(String(c.l.Target), targets);
        if(c.l.Tooltip) c.l.Tooltip=redactPlain(String(c.l.Tooltip), targets);
      }
    });
  });
  // שם גיליון כמו "כרטסת לקוח X" הוא דליפה בפני עצמה
  const usedNames=new Set();
  [...wb.SheetNames].forEach((sn,i)=>{
    let nn=redactPlain(sn, targets).replace(/[\[\]:*?\/\\]/g,'').trim().slice(0,31);
    if(!nn) nn='גיליון '+(i+1);
    const base=nn; let k=2;
    while(usedNames.has(nn) || (nn!==sn && wb.Sheets[nn])){ nn=(base+' '+k).slice(0,31); k++; }
    usedNames.add(nn);
    if(nn!==sn){ wb.Sheets[nn]=wb.Sheets[sn]; delete wb.Sheets[sn]; wb.SheetNames[i]=nn; }
  });
  wb.Workbook={...(wb.Workbook||{}), Views:[{RTL:true}]};
  wb.Props={...(wb.Props||{}), Author:'', LastAuthor:'', Company:'', Manager:'', Title:'', Subject:''};
  const out=XLSX.write(wb,{bookType:kind,type:'array'});
  return {name:cleanName(f, kind), blob:new Blob([out]), srcId:f.id};
}

/* Word: עריכה בתוך ה-docx עצמו, מקטע-מודע (כולל כותרות/תחתונות) */
async function exportDocx(f){
  const buf=await f.file.arrayBuffer();
  const zip=await JSZip.loadAsync(buf);
  const targets=buildTargets(f);
  // comments ו-commentsExtended לא נכללו קודם, ולכן הערות סוקר עם שמות שרדו
  const parts=Object.keys(zip.files).filter(n=>
    /word\/(document|header\d*|footer\d*|footnotes|endnotes|comments|commentsExtended)\.xml$/.test(n));
  for(const name of parts){
    let xml=await zip.file(name).async('string');
    // מעבד כל פסקה בנפרד: אוסף את מקטעי ה-<w:t>, מסתיר על פניהם, ומחזיר
    xml=xml.replace(/<w:p\b[\s\S]*?<\/w:p>/g, para=>{
      // גם delText: טקסט שנמחק במעקב שינויים אינו יושב ב-w:t, ולכן שרד קודם
      const re=/(<w:(?:t|delText)\b[^>]*>)([\s\S]*?)(<\/w:(?:t|delText)>)/g;
      const inners=[]; let m;
      while((m=re.exec(para))!==null) inners.push(unescapeXml(m[2]));
      if(!inners.length) return para;
      const out=redactCore(inners, targets);
      let i=0;
      return para.replace(re,(mm,open,txt,close)=> open+escapeXml(out[i++])+close);
    });
    // שמות מגיבים ועורכים בתוך התגיות עצמן
    xml=xml.replace(/w:author="[^"]*"/g,'w:author=""')
           .replace(/w:initials="[^"]*"/g,'w:initials=""');
    zip.file(name, xml);
  }
  if(zip.file('word/people.xml')){
    let pp=await zip.file('word/people.xml').async('string');
    pp=pp.replace(/w15:author="[^"]*"/g,'w15:author=""');
    zip.file('word/people.xml', pp);
  }
  // תמונות ואובייקטים מוטמעים אינם נסרקים על ידי הכלי. צילום מסך של דף בנק או
  // עמוד סרוק שהודבק למסמך היה שורד במלואו, ולכן מחליפים אותם בתמונה ריקה.
  f.strippedMedia=0;
  if(state.stripMedia){
    const px=Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg=='), ch=>ch.charCodeAt(0));
    const isFile=n=>zip.files[n] && !zip.files[n].dir;
    Object.keys(zip.files).filter(n=>/^word\/media\//i.test(n) && isFile(n))
      .forEach(n=>{ zip.file(n, px); f.strippedMedia++; });
    const emb=Object.keys(zip.files).filter(n=>/^word\/embeddings\//i.test(n) && isFile(n));
    emb.forEach(n=>{ zip.remove(n); f.strippedMedia++; });
    if(emb.length && zip.file('word/_rels/document.xml.rels')){
      let r=await zip.file('word/_rels/document.xml.rels').async('string');
      r=r.replace(/<Relationship\b[^>]*embeddings\/[^>]*\/>/g,'');
      zip.file('word/_rels/document.xml.rels', r);
    }
  }
  // ניקוי מטא-דאטה של המסמך (יוצר, כותרת וכו')
  if(zip.file('docProps/core.xml')){
    let c=await zip.file('docProps/core.xml').async('string');
    ['dc:creator','cp:lastModifiedBy','dc:title','dc:subject','cp:keywords','dc:description'].forEach(tag=>{
      c=c.replace(new RegExp('(<'+tag+'[^>]*>)[\\s\\S]*?(</'+tag+'>)'),'$1$2');
    });
    zip.file('docProps/core.xml', c);
  }
  if(zip.file('docProps/app.xml')){
    let a=await zip.file('docProps/app.xml').async('string');
    ['Company','Manager'].forEach(tag=>{ a=a.replace(new RegExp('(<'+tag+'[^>]*>)[\\s\\S]*?(</'+tag+'>)'),'$1$2'); });
    zip.file('docProps/app.xml', a);
  }
  const out=await zip.generateAsync({type:'blob',
    mimeType:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
  return {name:cleanName(f,'docx'), blob:out, srcId:f.id};
}

/* מנקה מטא-דאטה מ-PDF (מסיר Producer/Author/Title וכו') */
function scrubPdfMeta(doc){
  try{
    doc.setTitle(''); doc.setAuthor(''); doc.setSubject('');
    doc.setKeywords([]); doc.setProducer(''); doc.setCreator('');
    const z=new Date(0); doc.setCreationDate(z); doc.setModificationDate(z);
  }catch(e){}
}

/* PDF: מפיק מעמודי התצוגה המקדימה (עם כל המלבנים האוטומטיים והידניים) */
async function exportPdf(f){
  computeAutoBoxes(f);                 // רענון לפי הממצאים המאושרים העדכניים
  if(state.pdfMode==='text') return await exportPdfTextual(f);
  if(state.pdfMode==='layer'){
    // שכבת הטקסט נבדקת בנפרד אחרי הכתיבה. אם משהו בה אינו נקי, או שהיא נכשלה מכל
    // סיבה, הקובץ מופק כתמונה בלבד: ברירת המחדל הבטוחה, לא קובץ עם ספק.
    try{
      const withLayer=await exportPdfImage(f, true);
      if(withLayer.stats.textLayer){
        const why=await layerProblem(f, withLayer.blob);
        if(!why) return withLayer;
        console.warn('שכבת הטקסט נפסלה:', f.name, why);
      } else return withLayer;
    }catch(e){ console.error(e); }
    const plain=await exportPdfImage(f, false);
    plain.stats.layerDropped=true;
    return plain;
  }
  return await exportPdfImage(f, false);
}
async function exportPdfImage(f, withText){
  const outDoc=await PDFLib.PDFDocument.create();
  const layerFont = withText ? newLayerFont(outDoc) : null;
  const layerTargetsList = withText ? layerTargets(f) : null;
  let src=null;
  const stats={pages:0, boxes:0, badBoxes:0, unchecked:0, textLayer:false};
  for(const entry of (f.pages||[])){
    // עמוד שלא הוצג (מצב אצווה) מרונדר עכשיו, מקבל את המלבנים, ומשוחרר מיד
    let cv=entry.canvas, temp=false, visible=null;
    const wantText = !!layerFont && !!entry.pageNum && !(f.pageScanned && f.pageScanned[entry.pageNum-1]);
    if(wantText || entry.light || !entry.redraw){
      if(!src) src=await pdfjsLib.getDocument({data:await f.file.arrayBuffer(), isEvalSupported:false, worker:pdfWorker()}).promise;
    }
    const textOk = wantText && !(await pageImageDominated(src, entry.pageNum));
    if(entry.light || !entry.redraw){
      const vis = textOk ? {} : null;
      cv=await renderEntryCanvas(src, entry, vis); temp=true;
      if(vis) visible=vis.flags;
    } else {
      entry.redraw();                    // מצייר base + מלבנים לתוך הקנבס
      if(textOk && entry.baseCv && entry.baseCv.width)
        visible=itemsVisible(entry.baseCv.getContext('2d',{willReadFrequently:true}), entry.baseCv.width, entry.baseCv.height, entry.items||[], 1, 1);
    }
    // JPEG ברזולוציה נמוכה ובינונית, PNG רק במצב איכות גבוהה. ספר של 40 עמודים
    // ב-PNG יצא כבד מדי להעלאה למודל.
    const sc=state.pdfScale||2;
    const useJpg = sc<3;
    const durl = useJpg ? cv.toDataURL('image/jpeg', sc<=1.5?0.82:0.9)
                        : cv.toDataURL('image/png');
    const bytes=dataURLtoBytes(durl);
    // בדיקה על התמונה כפי שתיכתב לקובץ: כל מלבן חייב להיות שחור גם אחרי הקידוד
    const eff=effectiveBoxes(entry);
    stats.pages++; stats.boxes+=eff.length;
    if(eff.length){
      const nb=await boxesNotDark(bytes, useJpg?'image/jpeg':'image/png', eff, entry.canvas.width, entry.canvas.height);
      if(nb<0) stats.unchecked++; else stats.badBoxes+=nb;
    }
    const img = useJpg ? await outDoc.embedJpg(bytes) : await outDoc.embedPng(bytes);
    const pg=outDoc.addPage([cv.width, cv.height]);
    pg.drawImage(img,{x:0,y:0,width:cv.width,height:cv.height});
    if(layerFont && drawCleanText(pg, entry, f, layerFont, layerTargetsList, cv.width, cv.height, visible)) stats.textLayer=true;
    if(temp){ cv.width=0; cv.height=0; }
  }
  closePdf(src);
  if(layerFont) finishLayerFont(outDoc, layerFont);
  scrubPdfMeta(outDoc);
  // updateMetadata:false, אחרת pdf-lib כותב מחדש Producer ותאריכים ומבטל את הניקוי
  const out=await outDoc.save({updateMetadata:false});
  return {name:cleanName(f,'pdf'), blob:new Blob([out],{type:'application/pdf'}), srcId:f.id, stats};
}

/* ============ תמונה עם טקסט נקי ============
   העמוד נשאר תמונה, בדיוק כמו במצב "תמונה", ומעליו נכתב מחדש טקסט בלתי נראה שמודל
   שפה קורא במדויק, בלי לפענח תמונה. הטקסט נבנה מאפס ממקטעי המקור:
   - כל ערך שאושר להסתרה מוחלף בתווית שלו (אותו מנגנון כמו ב-Word וב-Excel).
   - כל תו שיושב מתחת למלבן אוטומטי אינו נכתב, גם אם ההחלפה הטקסטואלית פספסה אותו.
   - מקטע שנוגע במלבן ידני, במלבן תבנית או במלבן של שדה לפי תווית אינו נכתב כלל, כי
     מיקום התווים בתוך מקטע הוא הערכה, ומלבן שצויר ביד לא חייב להסכים איתה.
   - עמוד סרוק אינו מקבל טקסט: מה שה-OCR קרא אינו אמין מספיק כדי להיכתב כעובדה.
   אחרי הכתיבה הקובץ נקרא מחדש ונבדק (layerProblem). כישלון מפיק תמונה בלבד.

   הגופן: Type 3 שמוגדר כולו בתוך ה-PDF, עם גליפים ריקים וטבלת ToUnicode. אין קובץ
   גופן ואין ספרייה נוספת, והטקסט אינו נראה כי לגליפים אין ציור. כל התווים באותו
   רוחב, ומתיחה אופקית מתאימה את המקטע לרוחב שלו במקור. */
function newLayerFont(outDoc){
  const ctx=outDoc.context;
  const proc=ctx.register(ctx.stream('500 0 d0'));          // גליף ריק ברוחב 500
  const names=[], procs={};
  for(let i=0;i<256;i++){ names.push('g'+i); procs['g'+i]=proc; }
  const cmapRef=ctx.nextRef();
  const dict=ctx.obj({ Type:'Font', Subtype:'Type3', FontBBox:[0,0,1000,1000], FontMatrix:[0.001,0,0,0.001,0,0],
    CharProcs:procs, Encoding:{Type:'Encoding', Differences:[0].concat(names)},
    FirstChar:0, LastChar:255, Widths:new Array(256).fill(500), Resources:{}, ToUnicode:cmapRef });
  const font={ref:ctx.register(dict), cmapRef, codes:new Map(), list:[]};
  layerCode(font,'?'); layerCode(font,' ');
  return font;
}
/* קוד של בית אחד לכל תו. יותר מ-256 תווים שונים במסמך אחד: העודפים נכתבים כסימן שאלה. */
function layerCode(font, ch){
  let c=font.codes.get(ch);
  if(c===undefined){
    if(font.list.length>=256) return 0;
    c=font.list.length; font.list.push(ch); font.codes.set(ch,c);
  }
  return c;
}
function finishLayerFont(outDoc, font){
  const hex2=n=>n.toString(16).toUpperCase().padStart(2,'0');
  const u16=ch=>{ let h=''; for(let i=0;i<ch.length;i++) h+=ch.charCodeAt(i).toString(16).toUpperCase().padStart(4,'0'); return h; };
  const rows=font.list.map((ch,i)=>'<'+hex2(i)+'> <'+u16(ch)+'>');
  let body='';
  for(let i=0;i<rows.length;i+=100){ const part=rows.slice(i,i+100); body+=part.length+' beginbfchar\n'+part.join('\n')+'\nendbfchar\n'; }
  const cmap='/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n'+
    '/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n'+
    '1 begincodespacerange\n<00> <FF>\nendcodespacerange\n'+body+
    'endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n';
  outDoc.context.assign(font.cmapRef, outDoc.context.flateStream(cmap));
}
/* בשכבת הטקסט אין מסכה חלקית: בתמונה הערך מושחר כולו, והטקסט לא יחשוף ממנו ספרות */
function layerTargets(f){
  return activeFor(f).map(a=>({tz:normSpaceless(a.value),
      rep: state.mode==='delete' ? '' : (state.mode==='token' ? pseudoToken(a.value,a.type) : typeTag(a.type))}))
    .filter(t=>t.tz.length>=2);
}
const isHebCh=ch=>/[֐-׿יִ-ﭏ]/.test(ch);
const isLtrCh=ch=>/[A-Za-z0-9À-ɏ]/.test(ch);
/* מפרק תווים (בסדר לוגי) לרצפים לפי כיוון, בקירוב לכללי הדו-כיווניות: סימן ניטרלי בין
   שני רצפים באותו כיוון מצטרף אליהם, אחרת הוא הולך עם כיוון הבסיס; סימן אחוז או מטבע
   שצמוד למספר נשאר עם המספר. forced קובע מראש את הכיוון של תווי תווית. */
function dirRuns(chars, forced, baseRtl){
  const types=chars.map((ch,i)=>forced[i] || (isHebCh(ch)?'R':(isLtrCh(ch)?'L':'N')));
  for(let i=0;i<chars.length;i++){
    if(types[i]==='N' && /[%$#₪€£°]/.test(chars[i]) &&
       ((i>0 && /[0-9]/.test(chars[i-1])) || (i+1<chars.length && /[0-9]/.test(chars[i+1])))) types[i]='L';
  }
  for(let i=0;i<chars.length;i++){
    if(types[i]!=='N') continue;
    let a=i-1; while(a>=0 && types[a]==='N') a--;
    let b=i+1; while(b<chars.length && types[b]==='N') b++;
    const left=a>=0?types[a]:null, right=b<chars.length?types[b]:null;
    const res = (left && left===right) ? left : (baseRtl?'R':'L');
    for(let k=i;k<b;k++) types[k]=res;
    i=b-1;
  }
  const runs=[];
  chars.forEach((ch,i)=>{ const last=runs[runs.length-1]; if(last && last.t===types[i]) last.n++; else runs.push({t:types[i], n:1}); });
  return runs;
}
/* תא התצוגה של כל תו (0 הוא השמאלי ביותר), לפי הרצפים. הטקסט נכתב בסדר הקריאה, וכל
   תו מוצב בתא שלו: רצף עברי מתקדם שמאלה, ומספר או מילה באנגלית מתקדמים ימינה. כך
   בדיוק שמור הטקסט ב-PDF עברי שנוצר בכלים רגילים, ולכן קוראים חיצוניים מחזירים אותו
   באותו סדר שבו הם מחזירים את המקור. */
function visualCells(chars, forced, baseRtl){
  const n=chars.length, cells=new Array(n);
  let i=0, v = baseRtl ? n : 0;
  dirRuns(chars, forced, baseRtl).forEach(r=>{
    if(baseRtl) v-=r.n;
    for(let k=0;k<r.n;k++) cells[i+k] = r.t==='R' ? v+r.n-1-k : v+k;
    if(!baseRtl) v+=r.n;
    i+=r.n;
  });
  return cells;
}
function layerCleanChar(ch){
  const cp=ch.codePointAt(0);
  if(cp<32 || cp===0x7F || (cp>=0x200B && cp<=0x200F) || (cp>=0x202A && cp<=0x202E) || (cp>=0x2066 && cp<=0x2069) || cp===0xFEFF) return (cp===9||cp===10||cp===13) ? ' ' : '';
  if(cp>=0xE000 && cp<=0xF8FF) return '?';                 // גליף שהמקור לא מיפה לתו
  if(cp===0xA0 || /\s/.test(ch)) return ' ';
  return ch;
}
/* שכבת הטקסט כותבת רק מה שנראה בעין על העמוד. ב-PDF יש טקסט שאינו נראה, ובמצב "תמונה"
   הוא נעלם יחד עם שכבת הטקסט, אבל כתיבה מחדש הייתה מחזירה אותו:
   - מסמך שכבר הושחר בכלי אחר, שבו מלבן שחור מצויר מעל טקסט שנשאר בקובץ.
   - טקסט לבן על לבן, או טקסט שהוגדר כבלתי נראה.
   - סריקה שעברה OCR בתוכנה אחרת: העמוד הוא תמונה אחת, והטקסט הוא ניחוש של תוכנה.
   לכן: בעמוד שתמונה אחת מכסה את רובו אין טקסט כלל, ובכל עמוד אחר מקטע נכתב רק אם
   באזור שלו בתמונת העמוד יש גם דיו וגם רקע. */
async function pageImageDominated(pdf, pageNum){
  try{
    const page=await pdf.getPage(pageNum);
    const ops=await page.getOperatorList();
    const O=pdfjsLib.OPS, v=page.view, pageArea=Math.abs((v[2]-v[0])*(v[3]-v[1]))||1;
    const mul=(m,n)=>[m[0]*n[0]+m[2]*n[1], m[1]*n[0]+m[3]*n[1], m[0]*n[2]+m[2]*n[3], m[1]*n[2]+m[3]*n[3], m[0]*n[4]+m[2]*n[5]+m[4], m[1]*n[4]+m[3]*n[5]+m[5]];
    let ctm=[1,0,0,1,0,0]; const stack=[];
    const imgOps=new Set([O.paintImageXObject, O.paintInlineImageXObject, O.paintJpegXObject, O.paintImageXObjectRepeat].filter(x=>x!==undefined));
    for(let i=0;i<ops.fnArray.length;i++){
      const fn=ops.fnArray[i], a=ops.argsArray[i];
      if(fn===O.save) stack.push(ctm);
      else if(fn===O.restore){ if(stack.length) ctm=stack.pop(); }
      else if(fn===O.transform) ctm=mul(ctm, a);
      else if(fn===O.paintFormXObjectBegin){ stack.push(ctm); if(a && a[0]) ctm=mul(ctm, a[0]); }
      else if(fn===O.paintFormXObjectEnd){ if(stack.length) ctm=stack.pop(); }
      else if(imgOps.has(fn)){ if(Math.abs(ctm[0]*ctm[3]-ctm[1]*ctm[2]) >= pageArea*0.5) return true; }
    }
    return false;
  }catch(e){ console.error(e); return true; }        // בספק: בלי טקסט
}
/* לכל מקטע: האם רואים אותו בתמונת העמוד. ctx הוא העמוד בלי המלבנים של הכלי. */
function itemsVisible(ctx, cvW, cvH, items, kx, ky){
  return items.map(it=>{
    if(!it.rect || !(it.str||'').trim()) return false;
    const x0=Math.max(0,Math.floor((it.rect.x+2)*kx)), y0=Math.max(0,Math.floor((it.rect.y+2)*ky));
    const x1=Math.min(cvW,Math.ceil((it.rect.x+it.rect.w-2)*kx)), y1=Math.min(cvH,Math.ceil((it.rect.y+it.rect.h-2)*ky));
    if(x1-x0<2 || y1-y0<2) return false;
    let d;
    try{ d=ctx.getImageData(x0,y0,x1-x0,y1-y0).data; }catch(e){ return false; }
    const step=4*Math.max(1,Math.floor((d.length/4)/3000));
    let dark=0, light=0, tot=0;
    for(let i=0;i<d.length;i+=step){ const l=d[i]+d[i+1]+d[i+2]; tot++; if(l<330) dark++; else if(l>510) light++; }
    // דיו וגם רקע: אזור שכולו כהה הוא טקסט מתחת למלבן, ואזור שכולו בהיר הוא טקסט שלא צויר
    return tot>0 && dark/tot>=0.006 && dark/tot<=0.8 && light/tot>=0.15;
  });
}

/* כותב את הטקסט הנקי של עמוד אחד, שורה אחר שורה. מחזיר true אם נכתב משהו.
   העבודה בשני שלבים: קודם מחליטים לכל מקטע מה ממנו נכתב, ואז מרכיבים שורות. ההרכבה
   לשורות נדרשת כי ב-PDF רבים כל אות היא מקטע נפרד והרווח בין מילים הוא רק פער, ובלי
   הרכבה המילים היו נכתבות דבוקות. */
function drawCleanText(pg, entry, f, font, targets, outW, outH, visible){
  const scanned = f.pageScanned ? !!f.pageScanned[(entry.pageNum||1)-1] : !!f.scanned;
  const items=entry.items||[];
  if(scanned || (entry.ocrItems && entry.ocrItems.length) || !items.length || !visible) return false;
  const sup=entry.suppressed||new Set();
  const auto=(entry.autoBoxes||[]).filter(b=>!sup.has(boxKey(b)));
  const hard=[...(entry.manualBoxes||[]), ...anchorBoxesFor(entry), ...templateBoxesFor(entry)].filter(b=>!sup.has(boxKey(b)));
  const {cells:src, del, ins}=redactCells(items.map(it=>it.str||''), targets);
  const HEB=/[֐-׿יִ-ﭏ]/;

  // ---- שלב 1: מה נכתב מכל מקטע ----
  const outOf=new Array(items.length);       // לכל מקטע: {chars, forced, n0} או null כשאינו נכתב
  let ci=0;
  items.forEach((it,ri)=>{
    const start=ci; let len=0;
    while(ci<src.length && src[ci].ri===ri){ ci++; len++; }
    if(!it.rect || !len) return;
    const core={x:it.rect.x+2, y:it.rect.y+2, w:Math.max(1,it.rect.w-4), h:Math.max(1,it.rect.h-4)};
    const touches=b=>Math.min(core.x+core.w,b.x+b.w)-Math.max(core.x,b.x)>1 && Math.min(core.y+core.h,b.y+b.h)-Math.max(core.y,b.y)>1;
    const n0=[...(it.str||'')].map(layerCleanChar).join('').length;
    const isHard=hard.some(touches) || !visible[ri];          // מקטע שאינו נראה על העמוד אינו נכתב
    const rtl=HEB.test(it.str||'');
    // תווים שנספרים במיקום (אותה ספירה כמו ב-computeAutoBoxes), ומה שמתחת למלבן אוטומטי
    if(auto.some(touches)){
      const counted=[]; for(let k=0;k<len;k++){ if(normHeb(src[start+k].ch).replace(/\s+/g,'')) counted.push(k); }
      const cw=core.w/Math.max(1,counted.length);
      counted.forEach((k,j)=>{
        const x0 = rtl ? core.x+core.w-(j+1)*cw : core.x+j*cw;
        // ההשוואה מול תחום המלבן בלי הריפוד שלו, אחרת סימן פיסוק צמוד היה נמחק יחד עם הערך
        if(auto.some(b=>{ const bx=b.cx!==undefined?b.cx:b.x, bw=b.cw!==undefined?b.cw:b.w;
          return Math.min(x0+cw,bx+bw)-Math.max(x0,bx)>cw*0.35 && Math.min(core.y+core.h,b.y+b.h)-Math.max(core.y,b.y)>core.h*0.3; })) del[start+k]=true;
      });
    }
    // בתווית ממוספרת כמו [שם-1] החלק "-1]" מקבל כיוון משמאל לימין, כדי שהתווית תיקרא
    // רצופה ולא תישבר על הספרה.
    const chars=[], forced=[];
    const put=(ch,dir)=>{ const c=layerCleanChar(ch); if(!c) return; chars.push(c); forced.push(dir); };
    const putLabel=label=>{
      const m=/^\[(.*?)(-\d+)?\]$/.exec(label);
      if(!m){ [...label].forEach(ch=>put(ch,null)); return; }
      const d=HEB.test(m[1]) ? 'R' : 'L';
      put('[',d); [...m[1]].forEach(ch=>put(ch,d));
      if(m[2]){ [...m[2]].forEach(ch=>put(ch,'L')); put(']','L'); } else put(']',d);
    };
    // מקטע שנוגע במלבן ידני או במלבן של שדה לפי תווית: התווים שלו אינם נכתבים כלל, ונשארת רק
    // התווית של ערך שהוחלף בו, כדי שאותו לקוח יקבל אותו מזהה גם בטקסט.
    for(let k=0;k<len;k++){ const c=start+k; if(ins[c]) putLabel(ins[c]); if(!del[c] && !isHard) put(src[c].ch, null); }
    outOf[ri]={chars, forced, n0};
  });

  // ---- שלב 2: הרכבת שורות וכתיבה ----
  const rx=outW/entry.canvas.width, ry=outH/entry.canvas.height;
  const key=pg.node.newFontDictionary('CleanText', font.ref);
  const ctx=pg.doc.context, ops=[];
  const writeSegment=(segParts, ln)=>{
    const rtl=segParts.some(p=>HEB.test(p.it.str||''));
    // סדר הקריאה של המקטעים בשורה. בשורה עברית: מימין לשמאל, ורצף של מקטעים באנגלית
    // או במספרים (למשל מילים של משפט באנגלית) חוזר לסדר שלו משמאל לימין.
    let parts=segParts.slice().sort((p,q)=> rtl ? (q.it.rect.x+q.it.rect.w)-(p.it.rect.x+p.it.rect.w) : p.it.rect.x-q.it.rect.x);
    if(rtl){
      const isL=p=>!HEB.test(p.it.str||'') && /[A-Za-z0-9]/.test(p.it.str||'');
      const fixed=[]; let i=0;
      while(i<parts.length){
        if(!isL(parts[i])){ fixed.push(parts[i++]); continue; }
        let j=i; while(j+1<parts.length && !HEB.test(parts[j+1].it.str||'')) j++;
        while(j>i && !isL(parts[j])) j--;                       // פיסוק בסוף הרצף נשאר במקומו
        for(let k=j;k>=i;k--) fixed.push(parts[k]);
        i=j+1;
      }
      parts=fixed;
    }
    const chars=[], forced=[]; let n0=0, prev=null;
    const hs=[];
    parts.forEach(p=>{
      const o=outOf[p.idx], r=p.it.rect; hs.push(r.h-4);
      // רווח בין מקטעים לפי הפער ביניהם. המלבנים מרופדים, ולכן הפער האמיתי גדול ב-4.
      let gapSpace=false;
      if(prev){
        const gap=Math.max(r.x-(prev.x+prev.w), prev.x-(r.x+r.w))+4;
        gapSpace = gap > (Math.min(r.h, prev.h)-4)*0.15;
      }
      prev=r;
      if(!o) return;
      if(gapSpace){ n0++; if(chars.length && chars[chars.length-1]!==' '){ chars.push(' '); forced.push(null); } }
      n0+=o.n0;
      o.chars.forEach((ch,i)=>{ if(ch===' ' && chars[chars.length-1]===' ') return; chars.push(ch); forced.push(o.forced[i]); });
    });
    while(chars.length && chars[chars.length-1]===' '){ chars.pop(); forced.pop(); }
    while(chars.length && chars[0]===' '){ chars.shift(); forced.shift(); }
    if(!chars.length) return;
    const box=unionRect(segParts.map(p=>p.it.rect));
    const core={x:box.x+2, w:Math.max(1,box.w-4)};
    hs.sort((a,b)=>a-b);
    const fh=Math.max(2, hs[hs.length>>1]);
    const size=fh*ry;
    const tz=Math.min(600, Math.max(15, (core.w*rx)/(Math.max(1,n0)*0.5*size)*100));    // באחוזים: השורה תופסת את רוחב המקור
    const cw=0.5*size*tz/100;
    const cell=visualCells(chars, forced, rtl);
    const x0 = rtl ? (core.x+core.w)*rx-chars.length*cw : core.x*rx;                    // שורה עברית נשארת מעוגנת לימין
    const y = outH-(ln.yc+fh*0.3)*ry;                                                   // קו הבסיס, בערך שליש מתחת לאמצע השורה
    const arr=[]; let pen=cell[0], hex='';
    const flush=()=>{ if(hex){ arr.push(PDFLib.PDFHexString.of(hex)); hex=''; } };
    chars.forEach((ch,i)=>{
      const adj=(pen-cell[i])*500;                  // באלפיות יחידת טקסט: 500 הוא רוחב תו
      if(adj){ flush(); arr.push(adj); }
      hex+=layerCode(font,ch).toString(16).padStart(2,'0');
      pen=cell[i]+1;
    });
    flush();
    ops.push(PDFLib.beginText(), PDFLib.setFontAndSize(key, size), PDFLib.setCharacterSqueeze(tz),
      PDFLib.setTextRenderingMode(PDFLib.TextRenderingMode.Invisible), PDFLib.setTextMatrix(1,0,0,1,x0+cell[0]*cw,y),
      PDFLib.PDFOperator.of(PDFLib.PDFOperatorNames.ShowTextAdjusted, [ctx.obj(arr)]), PDFLib.endText());
  };
  groupLines(items).forEach(ln=>{
    // שורה עם פער גדול באמצע (תווית בצד אחד ותאריך בצד השני, או טורים של טבלה) נכתבת
    // כקטעים נפרדים. בלי זה התווים היו נמתחים על פני כל הרוחב, וקורא חיצוני היה רואה
    // רווח בין כל שתי אותיות.
    const byX=ln.parts.slice().sort((p,q)=>p.it.rect.x-q.it.rect.x);
    const segs=[[]];
    byX.forEach((p,i)=>{
      if(i){ const a=byX[i-1].it.rect, b=p.it.rect; if(b.x-(a.x+a.w)+4 > Math.max(a.h,b.h)*1.2) segs.push([]); }
      segs[segs.length-1].push(p);
    });
    if(ln.parts.some(p=>HEB.test(p.it.str||''))) segs.reverse();      // שורה עברית נקראת מימין
    segs.forEach(seg=>writeSegment(seg, ln));
  });
  if(!ops.length) return false;
  pg.pushOperators(PDFLib.pushGraphicsState(), ...ops, PDFLib.popGraphicsState());
  return true;
}
/* בדיקה בלתי תלויה של שכבת הטקסט: קוראים את הקובץ מחדש, ומחפשים בו כל ערך שאושר
   להסתרה (גם בסדר הפוך וגם בהתאמה רופפת), וכל מזהה מובנה שלא הושאר גלוי בכוונה.
   מחזיר תיאור של הבעיה, או מחרוזת ריקה כשהשכבה נקייה. */
async function layerProblem(f, blob){
  const txt=await extractOutputText('x.pdf', blob);
  if(txt===null) return 'לא ניתן היה לקרוא את הקובץ שנכתב';
  const big=normSpaceless(txt), loose=normLoose(txt);
  for(const a of activeFor(f)){
    const v=normSpaceless(a.value); if(v.length<2) continue;
    const rv=[...v].reverse().join('');
    if(big.includes(v) || big.includes(rv)) return 'ערך מאושר נשאר בטקסט';
    const vl=normLoose(a.value);
    if(vl.length>=4 && (loose.includes(vl) || loose.includes([...vl].reverse().join('')))) return 'ערך מאושר נשאר בטקסט (התאמה רופפת)';
  }
  const STRUCT=new Set(['id','hp','phone','email','cc','bank','iban','passport','vehicle','taxfile']);
  const left=new Set(state.findings.filter(x=>x.fileId===f.id && !x.checked).map(x=>normSpaceless(x.value)));
  syncDetectors();
  const stray=scanText(txt).filter(h=>STRUCT.has(h.type) && !left.has(normSpaceless(h.value)));
  if(stray.length) return 'בטקסט נמצא מזהה שלא סומן: '+stray[0].type;
  return '';
}

async function renderEntryCanvas(src, entry, visOut){
  const page=await src.getPage(entry.pageNum);
  const vp=page.getViewport({scale:state.pdfScale||2});
  const c=document.createElement('canvas'); c.width=vp.width; c.height=vp.height;
  const ctx=c.getContext('2d',{willReadFrequently:true});
  await page.render({canvasContext:ctx, viewport:vp}).promise;
  const rx=c.width/entry.canvas.width, ry=c.height/entry.canvas.height;
  if(visOut) visOut.flags=itemsVisible(ctx, c.width, c.height, entry.items||[], rx, ry);   // לפני שמציירים מלבנים
  const manual=entry.manualBoxes||[];
  const rects=effectiveBoxes(entry).map(b=>{
    const s={x:b.x*rx, y:b.y*ry, w:b.w*rx, h:b.h*ry};
    return (b.tpl || manual.includes(b)) ? s : snapToInk(ctx, c.width, c.height, s);     // כל ההצמדות לפני הציור הראשון
  });
  ctx.fillStyle='#000';
  rects.forEach(s=>ctx.fillRect(s.x, s.y, s.w, s.h));
  return c;
}

/* PDF טקסטואלי: שומר את הקובץ המקורי ומצייר מלבנים שחורים מעל האזורים.
   שים לב: הטקסט המקורי נשאר מתחת למלבן (הסתרה ויזואלית בלבד). */
async function exportPdfTextual(f){
  const orig=await PDFLib.PDFDocument.load(await f.file.arrayBuffer());
  const pages=orig.getPages();
  const stats={pages:0, boxes:0, textual:true};
  (f.pages||[]).forEach((entry,i)=>{
    const page=pages[i]; if(!page) return;
    const W=page.getWidth(), H=page.getHeight();
    const sx=W/entry.canvas.width, sy=H/entry.canvas.height;
    const boxes = effectiveBoxes(entry);
    stats.pages++; stats.boxes+=boxes.length;
    boxes.forEach(b0=>{
      const b=drawnRect(entry,b0);
      page.drawRectangle({ x:b.x*sx, y:H-(b.y+b.h)*sy, width:b.w*sx, height:b.h*sy, color:PDFLib.rgb(0,0,0) });
    });
  });
  scrubPdfMeta(orig);
  // מצב טקסטואלי שומר את המסמך המקורי, ולכן חייבים לנקות גם את מה ש-Info לא מכסה:
  // מטא-דאטה מסוג XMP, שמות ויעדים, וכן הערות ושדות טופס שהערכים שלהם חשופים.
  try{ orig.catalog.delete(PDFLib.PDFName.of('Metadata')); }catch(e){}
  try{ orig.catalog.delete(PDFLib.PDFName.of('Names')); }catch(e){}
  try{ orig.catalog.delete(PDFLib.PDFName.of('AcroForm')); }catch(e){}
  pages.forEach(pg=>{ try{ pg.node.set(PDFLib.PDFName.of('Annots'), orig.context.obj([])); }catch(e){} });
  const out=await orig.save({updateMetadata:false});
  return {name:cleanName(f,'pdf'), blob:new Blob([out],{type:'application/pdf'}), srcId:f.id, stats};
}
function dataURLtoBytes(d){
  const b=atob(d.split(',')[1]); const a=new Uint8Array(b.length);
  for(let i=0;i<b.length;i++) a[i]=b.charCodeAt(i); return a;
}

/* תמונה נקייה (מצייר את המלבנים לתוך הקנבס) */
async function exportImage(f){
  computeAutoBoxes(f);
  const entry=(f.pages||[])[0];
  if(entry && entry.canvas && entry.canvas.getContext && entry.canvas.width && entry.redraw){
    entry.redraw();
    const blob=await new Promise(res=>entry.canvas.toBlob(res,'image/png'));
    return {name:cleanName(f,'png'), blob, srcId:f.id, stats:await imageStats(blob, effectiveBoxes(entry), entry.canvas.width, entry.canvas.height)};
  }
  // תמונה שלא הוצגה (מצב אצווה): נטענת עכשיו ומקבלת את מלבני התבנית
  const bmp=await createImageBitmap(f.file);
  const c=document.createElement('canvas'); c.width=bmp.width; c.height=bmp.height;
  const ctx=c.getContext('2d'); ctx.drawImage(bmp,0,0);
  const e=entry || {canvas:{width:bmp.width, height:bmp.height}, autoBoxes:[], manualBoxes:[], __file:f};
  const rx=c.width/e.canvas.width, ry=c.height/e.canvas.height;
  ctx.fillStyle='#000';
  effectiveBoxes(e).forEach(b=>ctx.fillRect(b.x*rx, b.y*ry, b.w*rx, b.h*ry));
  const blob=await new Promise(res=>c.toBlob(res,'image/png'));
  const stats=await imageStats(blob, effectiveBoxes(e), e.canvas.width, e.canvas.height);
  c.width=0; c.height=0;
  return {name:cleanName(f,'png'), blob, srcId:f.id, stats};
}
async function imageStats(blob, boxes, cw, ch){
  const stats={pages:1, boxes:boxes.length, badBoxes:0, unchecked:0};
  if(boxes.length){
    const nb=await boxesNotDark(new Uint8Array(await blob.arrayBuffer()), 'image/png', boxes, cw, ch);
    if(nb<0) stats.unchecked=1; else stats.badBoxes=nb;
  }
  return stats;
}

/* שם הקובץ הוא נתיב דליפה קלאסי: שם הלקוח יושב בו כמעט תמיד.
   לכן כל מונח מאושר מוסר גם ממנו, ואופציונלית השם מוחלף לגמרי. */
function cleanName(f, newExt){
  const idx = state.files.indexOf(f)+1;
  if(state.anonName) return 'מסמך_'+(idx||1)+'_נקי.'+newExt;
  const base=(f.name||'').replace(/\.[^.]+$/,'');
  let clean=redactPlain(base, buildTargets(f))
              .replace(/[\\/:*?"<>|]+/g,'_')
              .replace(/\s{2,}/g,' ')
              .trim();
  if(!clean) clean='מסמך_'+(idx||1);
  return clean+'_נקי.'+newExt;
}
/* ============ UI wiring ============ */
const drop=document.getElementById('drop'), fileInput=document.getElementById('file');
drop.onclick=()=>fileInput.click();
fileInput.onchange=e=>addFiles(e.target.files);
['dragover','dragenter'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over');}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over');}));
/* גרירת תיקייה: הדפדפן נותן רק את התיקייה, ולכן עוברים עליה רקורסיבית.
   readEntries מחזיר עד 100 פריטים בקריאה, ולכן חובה לקרוא בלולאה עד שחוזר ריק. */
drop.addEventListener('drop',async e=>{
  const entries=[...(e.dataTransfer.items||[])].map(i=>i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
  if(!entries.some(x=>x.isDirectory)){ addFiles(e.dataTransfer.files); return; }
  const out=[];
  const walk=async en=>{
    if(en.isFile){ out.push(await new Promise((res,rej)=>en.file(res,rej))); return; }
    const reader=en.createReader();
    for(;;){
      const batch=await new Promise((res,rej)=>reader.readEntries(res,rej));
      if(!batch.length) break;
      for(const x of batch) await walk(x);
    }
  };
  for(const en of entries) await walk(en);
  addFiles(out);
});
const folderInput=document.getElementById('folder');
const pickFolder=document.getElementById('pickfolder');
if(folderInput && pickFolder){
  pickFolder.onclick=ev=>{ ev.stopPropagation(); folderInput.click(); };
  folderInput.onchange=ev=>{ addFiles(ev.target.files); folderInput.value=''; };
}
const anchorsEl=document.getElementById('anchors');
if(anchorsEl) anchorsEl.addEventListener('change', ()=>{ if(state.files.length && state.scanned) scan(); });

// הדבקת תמונה מהלוח (Ctrl+V)
window.addEventListener('paste', e=>{
  const items=(e.clipboardData||{}).items||[];
  const imgs=[];
  for(const it of items){
    if(it.type && it.type.startsWith('image/')){
      const blob=it.getAsFile();
      if(blob) imgs.push(new File([blob], 'הדבקה_'+Date.now()+'.png', {type:blob.type||'image/png'}));
    }
  }
  if(imgs.length){ e.preventDefault(); addFiles(imgs); }
});

// מתג תצוגה בהירה/כהה
const themeBtn=document.getElementById('themeBtn');
const sunIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
const moonIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>';
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t);
  themeBtn.innerHTML = t==='dark' ? sunIcon : moonIcon;
}
let theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
applyTheme(theme);
themeBtn.onclick=()=>{ theme = theme==='dark' ? 'light' : 'dark'; applyTheme(theme); };

// אזהרה מיד בטעינה כשפותחים בלחיצה כפולה. עד כה הגילוי היה רק כשה-OCR נכשל.
(function fileProtocolNotice(){
  if(location.protocol!=='file:') return;
  const note=document.getElementById('fileNote'); if(note) note.hidden=false;
  // כפתורי ה-OCR נבנים דינמית, ולכן מסומן דגל שנבדק שם
  window.__noOcr = true;
})();

// detectors UI
function buildDetectors(){
  const el=document.getElementById('detectors');
  el.innerHTML=Object.entries(DETECTORS).map(([k,d])=>
    `<button data-k="${k}" class="${d.on?'on':''}">${d.label}</button>`).join('');
  el.querySelectorAll('button').forEach(b=>b.onclick=()=>{b.classList.toggle('on');});
}
function syncDetectors(){
  document.querySelectorAll('#detectors button').forEach(b=>{
    state.detectors[b.dataset.k]=b.classList.contains('on');
  });
}
buildDetectors(); syncDetectors();
document.getElementById('detAll').onclick=()=>{ document.querySelectorAll('#detectors button').forEach(b=>b.classList.add('on')); };
document.getElementById('detNone').onclick=()=>{ document.querySelectorAll('#detectors button').forEach(b=>b.classList.remove('on')); };

// אופן הפקת PDF
const PDF_HINTS={
  image:'כל עמוד הופך לתמונה והטקסט המקורי נמחק לגמרי. זו הדרך הבטוחה להעלאה למודל.',
  layer:'כמו "תמונה", ובנוסף נכתב מחדש טקסט נקי שהמודל קורא במדויק, בלי מה שהוסתר. אם בדיקת הטקסט אינה עוברת, הקובץ מופק כתמונה בלבד.',
  text:'הקובץ המקורי נשמר ומלבן שחור מצויר מעל הטקסט. <b>הטקסט שמתחת למלבן נשאר בקובץ וניתן לחילוץ.</b> מתאים להדפסה, לא להעלאה למודל.'
};
document.querySelectorAll('#pdfmode button').forEach(b=>b.onclick=()=>{
  // במצב שמירת המקור הקובץ נראה מושחר אבל הטקסט קיים מתחת למלבן. לכן נדרש אישור מפורש.
  if(b.dataset.p==='text'){
    const okText=window.confirm(
      'שמירת המקור עם מלבנים\n\n'+
      'במצב זה הטקסט המקורי נשאר בקובץ מתחת למלבן השחור, וניתן לחלץ אותו בהעתקה או בכלי אוטומטי.\n\n'+
      'אין להעלות קובץ כזה למודל שפה ואין להעביר אותו לגורם חיצוני.\n\n'+
      'להמשיך?');
    if(!okText) return;
  }
  document.querySelectorAll('#pdfmode button').forEach(x=>x.classList.remove('on'));
  b.classList.add('on'); state.pdfMode=b.dataset.p;
  document.getElementById('pdfmodehint').innerHTML = PDF_HINTS[state.pdfMode]||'';
});

// רשימת שמות, סריקה מחדש אוטומטית אחרי עריכה
document.getElementById('names').addEventListener('change', ()=>{ if(state.files.length && state.scanned) scan(); });

// mode
document.querySelectorAll('#mode button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('#mode button').forEach(x=>x.classList.remove('on'));
  b.classList.add('on'); state.mode=b.dataset.m;
});
// context names
document.querySelectorAll('.ctxbtn').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('.ctxbtn').forEach(x=>x.classList.remove('on'));
  b.classList.add('on'); state.ctxNames=b.dataset.v;
});

// רזולוציית ומשקל הפלט
document.querySelectorAll('#pdfres button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('#pdfres button').forEach(x=>x.classList.remove('on'));
  b.classList.add('on'); state.pdfScale=parseFloat(b.dataset.r)||2;
  if(state.scanned && state.files.some(f=>f.isPdf)) scan();   // מרנדר מחדש ברזולוציה החדשה, ושומר על המלבנים הידניים
});
const anonEl=document.getElementById('anonname');
if(anonEl) anonEl.onchange=e=>{ state.anonName=e.target.checked; };
const stripEl=document.getElementById('stripmedia');
if(stripEl){ state.stripMedia=stripEl.checked; stripEl.onchange=e=>{ state.stripMedia=e.target.checked; }; }

/* ============ אשף: שלושה שלבים ============ */
function goStep(n){
  state.step=n;
  [1,2,3].forEach(i=>{ const v=document.getElementById('view'+i); if(v) v.classList.toggle('on', i===n); });
  document.querySelectorAll('#steps .step').forEach(b=>{
    const i=+b.dataset.step;
    b.classList.toggle('now', i===n);
    b.classList.toggle('done', i<n);
    b.disabled = i>1 && !state.scanned;
  });
  window.scrollTo(0,0);
}
document.querySelectorAll('#steps .step').forEach(b=>b.onclick=()=>goStep(+b.dataset.step));
document.getElementById('scan').onclick=async ()=>{ await scan(); goStep(2); };
document.getElementById('download').onclick=downloadClean;
document.getElementById('to3').onclick=()=>goStep(3);
document.getElementById('back1').onclick=()=>goStep(1);
document.getElementById('back2').onclick=()=>goStep(2);
const setAll=v=>{ state.findings.forEach(f=>f.checked=v); refreshBoxesFor(new Set(state.files.map(f=>f.id))); renderFindings(); };
document.getElementById('selall').onclick=()=>setAll(true);
document.getElementById('selnone').onclick=()=>setAll(false);

// חיפוש וסינון בטבלת הממצאים
const findQ=document.getElementById('findq'), findType=document.getElementById('findtype');
if(findQ) findQ.oninput=()=>{ state.findQ=findQ.value; state.findLimit=200; renderFindings(); findQ.focus(); };
if(findType) findType.onchange=()=>{ state.findType=findType.value; state.findLimit=200; renderFindings(); };

// טעינת קובץ מפתח מהפעלה קודמת
const keyBtn=document.getElementById('loadkey'), keyInput=document.getElementById('keyfile');
if(keyBtn && keyInput){
  keyBtn.onclick=()=>keyInput.click();
  keyInput.onchange=async ev=>{
    const file=ev.target.files[0]; keyInput.value=''; if(!file) return;
    const info=document.getElementById('keyinfo');
    try{
      const n=loadKeyText(await file.text());
      info.textContent = n
        ? (n===1 ? 'נטען ערך אחד מהמפתח הקודם. הוא יקבל' : 'נטענו '+n+' ערכים מהמפתח הקודם. כל אחד מהם יקבל')+' שוב את אותה תווית, והשמות שבמפתח יחופשו בכל הקבצים.'
        : 'בקובץ שנבחר לא נמצאו שורות של מפתח. יש לבחור את הקובץ "מפתח פענוח" שהורד בפעם הקודמת.';
      if(n && state.scanned) scan();
    }catch(e){ console.error(e); info.textContent='לא ניתן היה לקרוא את הקובץ: '+e.message; }
  };
}
