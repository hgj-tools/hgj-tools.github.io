﻿# שרת קבצים מקומי זעיר עבור "מנקה נתונים אישיים".
#
# למה זה נדרש: מנוע ה-OCR (Tesseract) חייב ליצור Worker ולקרוא את חבילות
# השפה ואת קובץ ה-wasm. דפדפנים חוסמים את שתי הפעולות האלה כשעמוד נפתח
# ישירות מהדיסק בפרוטוקול file://. הגשה דרך http://127.0.0.1 פותרת זאת.
#
# מה השרת הזה עושה, ומה הוא לא עושה:
#   - מאזין על 127.0.0.1 בלבד. אינו נגיש מהרשת ואינו פותח פורט חוצה.
#   - מגיש קבצים מהתיקייה שבה הוא יושב, לקריאה בלבד.
#   - אינו כותב, אינו מוחק, אינו מריץ קוד ואינו יוצא לאינטרנט.
#   - אינו דורש הרשאות מנהל.
# הקוד פתוח לעיון, וכל שורה בו ניתנת לבדיקה על ידי גורם אבטחת מידע.

param([switch]$NoBrowser)   # -NoBrowser: להרמת השרת בלי לפתוח דפדפן (בדיקות)

$ErrorActionPreference = 'Stop'

# קיבוע פלט הקונסולה ל-UTF-8, אחרת ההודעות בעברית יוצאות מקושקשות.
# קובץ ההפעלה נשאר ASCII בלבד: עברית בתוך .bat אינה אמינה, ו-chcp בתוך
# באטץ' מזיז את מצביע הקריאה בקובץ ומשבש את פרסור השורות שאחריו.
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { $Host.UI.RawUI.WindowTitle = 'מנקה נתונים אישיים' } catch {}
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$mime = @{
  '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
  '.js'='text/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'
  '.json'='application/json; charset=utf-8'; '.txt'='text/plain; charset=utf-8'
  '.wasm'='application/wasm'; '.gz'='application/gzip'
  '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'
  '.gif'='image/gif'; '.svg'='image/svg+xml'; '.ico'='image/x-icon'
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.pdf'='application/pdf'
}

# תיקיית הכלי הגלויה (מעל "קבצי מערכת"). המשתמש רואה בה רק את קובץ ההפעלה ואת
# "קרא אותי", ולכן "קבצי מערכת" מוסתרת בהפעלה הראשונה. מאפיין "מוסתר" לא
# שורד חילוץ של ZIP, ולכן זה קורה כאן ולא בחבילה. בתיקיית הפיתוח (יש לצידה
# _פיתוח) לא מסתירים.
$top = Split-Path -Parent $root
if (-not (Test-Path -LiteralPath (Join-Path $top '_פיתוח'))) {
  try { $di = Get-Item -LiteralPath $root -Force; if (-not ($di.Attributes -band [IO.FileAttributes]::Hidden)) { $di.Attributes = $di.Attributes -bor [IO.FileAttributes]::Hidden } } catch { }
}

# ---------- בדיקת עדכון ----------
# בודק אם באתר הכלים יש גרסה חדשה יותר, ומעדכן רק באישור המשתמש.
#
# אבטחה: החבילה חייבת להיות חתומה במפתח הפרטי של המשרד. המפתח הציבורי מוטמע
# כאן למטה, והמפתח הפרטי לא נמצא באתר, בגיט או ב-OneDrive. לכן גם מי שפרץ לאתר
# או לחשבון GitHub ומחליף את החבילה ואת קובץ הגרסה, לא יכול להפיק חתימה תקינה,
# והעדכון נחסם בלי לשנות אף קובץ. בנוסף: הגרסה שבתוך החבילה חייבת להתאים למה
# שהוצג ולהיות חדשה מהמותקנת, כדי שאי אפשר יהיה להחזיר משתמש לגרסה ישנה.
#
# הבדיקה יוצאת מחלון ההפעלה ולא מהדפדפן, ולא נשלח בה שום מידע: רק בקשת GET
# לקובץ הגרסה. בלי רשת, או בכל תקלה, ממשיכים בגרסה הקיימת.
# לכיבוי: יוצרים בתיקייה קובץ בשם "ללא בדיקת עדכונים.txt".
# הכל ב-.NET ולא ב-cmdlets, כדי שלא יהיה תלוי במודולים שעשויים לא להיטען.
$UPDATE_PUBKEY = '<RSAKeyValue><Modulus>s/bKHfvT9qvdSeCAq3ECv9BbdjDq+Ir2U9lCD8e96+wj6Zi/7VmmrOW24yXLeRRgTG3eSH/4uqyFI+3pdrK334zNbdZTDZcxXcT9Pp4pfS/vAVpMIaazQ8YxgqUw7XuzQdoWVlmKTd6tsVyrr4VcvaK0gpFe38mQaDqtNvZeX5qJKcNvgKbctzZ7zqo7ObYWkp1fVM4ChDpn+LBu2Q2kVlgE8wAzwyW180lq7i+FebgiiJKnDDHTc/6K4AYadDZN89X7W90LB+9sfMRXOmAFYmkHuGf9HxqPuvJ/iazP6q0m9MnNQ/d4KDF2vF4V+qiPEOtx3674/tRr5URitG0oyUUB83exSJCzVbHLEwVvJg2Cho+PlomUok97z5zNjAMtcQ5oVK23Sxc017CpNIfQOON6SV42lS5IXSoB4ZVIqWbJtkUHCC4iqxgBJ2N7ODpHqfaf6aPKTyBBai1oSjKSvg37aggnErKRB6AVWwmBhLym03dA31s0J5egYgNkIXsR</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$verFile  = Join-Path $root 'VERSION.txt'
$localVer = if (Test-Path -LiteralPath $verFile) { ([IO.File]::ReadAllText($verFile)).Trim() } else { '0' }
$noUpdate = (Test-Path -LiteralPath (Join-Path $root 'ללא בדיקת עדכונים.txt')) -or $NoBrowser -or $env:PII_NO_UPDATE
if (-not $noUpdate) {
  $tmp = $null
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    # PII_UPDATE_URL: כתובת חלופית לבדיקות בלבד
    $updUrl = if ($env:PII_UPDATE_URL) { $env:PII_UPDATE_URL } else { 'https://hgj-tools.github.io/pii-redactor/version.json' }
    $wc = New-Object Net.WebClient
    $wc.Encoding = [Text.Encoding]::UTF8
    $req = [Net.WebRequest]::Create($updUrl + '?t=' + [DateTime]::UtcNow.Ticks); $req.Timeout = 5000
    $resp = $req.GetResponse()
    $json = (New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)).ReadToEnd(); $resp.Close()
    $info = $json | ConvertFrom-Json
    if ([version]$info.version -gt [version]$localVer) {
      Write-Host ""
      Write-Host ("  יש גרסה חדשה של הכלי: {0}  (אצלך {1})" -f $info.version, $localVer) -ForegroundColor Cyan
      if ($info.notes) { Write-Host ("  מה חדש: " + $info.notes) }
      # 1 עובד בכל פריסת מקלדת. מתקבלים גם כ, כן, y, ו-f (המקש של כ במקלדת אנגלית).
      $ans = Read-Host "  לעדכן עכשיו? הקלד 1 ואז Enter לעדכון, או רק Enter כדי לדלג"
      if ($ans -match '^\s*(1|כ|כן|y|yes|f)\s*$') {
        $tmp = Join-Path $env:TEMP ('pii-update-' + [guid]::NewGuid().ToString('N'))
        [IO.Directory]::CreateDirectory($tmp) | Out-Null
        $zip = Join-Path $tmp 'update.zip'
        Write-Host "  מוריד..."
        $wc.DownloadFile(($info.url + '?v=' + $info.version), $zip)

        # 1. חתימה. בלי חתימה תקינה של המפתח הפרטי של המשרד, לא נוגעים בשום קובץ.
        $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
        $rsa.PersistKeyInCsp = $false
        $rsa.FromXmlString($UPDATE_PUBKEY)
        $sig = $null; try { $sig = [Convert]::FromBase64String([string]$info.signature) } catch { }
        if (-not $sig -or -not $rsa.VerifyData([IO.File]::ReadAllBytes($zip), 'SHA256', $sig)) {
          throw "החתימה הדיגיטלית של החבילה אינה תקינה. ייתכן שהקובץ באתר הוחלף. העדכון נחסם ולא שונה דבר. כדאי לדווח לאחראי על הכלי."
        }

        # 2. פריסה לתיקייה זמנית, ובדיקת מבנה וגרסה לפני החלפה
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $x = Join-Path $tmp 'x'
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, $x)
        # החבילה: <תיקיית הכלי>\ ובתוכה קובץ ההפעלה, קרא אותי, ותיקיית המערכת
        $inner = Get-ChildItem -LiteralPath $x -Directory | Select-Object -First 1
        $pkgSys = if ($inner) { Get-ChildItem -LiteralPath $inner.FullName -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'server.ps1') } | Select-Object -First 1 }
        if (-not $pkgSys -or -not (Test-Path -LiteralPath (Join-Path $pkgSys.FullName 'index.html'))) { throw "מבנה החבילה אינו תקין. העדכון בוטל." }
        $pkgVer = ([IO.File]::ReadAllText((Join-Path $pkgSys.FullName 'VERSION.txt'))).Trim()
        if ($pkgVer -ne [string]$info.version -or -not ([version]$pkgVer -gt [version]$localVer)) {
          throw ("הגרסה שבתוך החבילה ({0}) אינה תואמת לגרסה שהוצעה. העדכון בוטל." -f $pkgVer)
        }

        # 3. החלפת הקבצים
        # תיקיית המערכת המוסתרת: מעתיקים לתוכה ישירות, כי Copy-Item לא דורס תיקייה מוסתרת כראוי
        Copy-Item -Path (Join-Path $pkgSys.FullName '*') -Destination $root -Recurse -Force
        Get-ChildItem -LiteralPath $inner.FullName -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $top -Force }
        Write-Host ("  עודכן לגרסה {0}. מפעיל מחדש..." -f $pkgVer) -ForegroundColor Green
        [IO.Directory]::Delete($tmp, $true); $tmp = $null
        if ($env:PII_NO_RESTART) { exit 0 }   # בדיקות: בלי לפתוח חלון חדש
        Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', ('"' + (Join-Path $root 'server.ps1') + '"'))
        exit 0
      }
    }
  } catch {
    Write-Host ("  בדיקת העדכון לא הושלמה: " + $_.Exception.Message + " ממשיך בגרסה הקיימת.") -ForegroundColor DarkYellow
  } finally {
    if ($tmp -and (Test-Path -LiteralPath $tmp)) { try { [IO.Directory]::Delete($tmp, $true) } catch { } }
  }
}

# איתור פורט פנוי. TcpListener על פורט גבוה אינו מצריך הרשאות מנהל,
# בשונה מ-HttpListener שדורש רישום URL במערכת.
$listener = $null
foreach ($port in 8765..8790) {
  try {
    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $port)
    $listener.Start()
    break
  } catch { $listener = $null }
}
if (-not $listener) {
  Write-Host "לא נמצא פורט פנוי בטווח 8765-8790. יש לסגור חלונות קודמים של הכלי ולנסות שוב." -ForegroundColor Red
  Read-Host "Enter ליציאה" | Out-Null
  exit 1
}

$url = "http://127.0.0.1:$port/index.html"
Write-Host ""
Write-Host "  מנקה נתונים אישיים" -ForegroundColor Cyan
Write-Host "  ------------------"
Write-Host "  הכלי פועל בכתובת: $url"
Write-Host "  העיבוד כולו מתבצע בדפדפן שלך. שום קובץ אינו נשלח לרשת."
Write-Host ""
Write-Host "  אין לסגור את החלון הזה בזמן העבודה." -ForegroundColor Yellow
Write-Host "  לסיום: לסגור את החלון, או Ctrl+C."
Write-Host ""

if (-not $NoBrowser -and -not $env:PII_NO_BROWSER) { Start-Process $url | Out-Null }

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $client.ReceiveTimeout = 2000
      $client.SendTimeout    = 60000
      $client.NoDelay        = $true

      # כרום פותח שקעים מראש (preconnect) בלי לשלוח בקשה. בלולאה חד-חוטית
      # שקע כזה היה תוקע את התור ומפיל טעינות במקביל, וכך נכשלה טעינת מנוע
      # ה-OCR. לכן ממתינים קצרות לנתונים, ואם אין, סוגרים וממשיכים מיד.
      $waited = 0
      while ($client.Available -eq 0 -and $client.Connected -and $waited -lt 1200) {
        Start-Sleep -Milliseconds 10
        $waited += 10
      }
      if ($client.Available -eq 0) { continue }

      $stream = $client.GetStream()

      # קריאת שורת הבקשה והכותרות
      $sb = New-Object System.Text.StringBuilder
      $buf = New-Object byte[] 1
      $limit = 8192
      while ($sb.Length -lt $limit) {
        if ($stream.Read($buf, 0, 1) -le 0) { break }
        [void]$sb.Append([char]$buf[0])
        $s = $sb.ToString()
        if ($s.EndsWith("`r`n`r`n") -or $s.EndsWith("`n`n")) { break }
      }
      $request = $sb.ToString()
      if (-not $request) { continue }

      $first = ($request -split "`r?`n")[0]
      $parts = $first -split ' '
      $method = $parts[0]
      $target = if ($parts.Count -gt 1) { $parts[1] } else { '/' }

      # ניקוי הנתיב: הסרת query, פענוח אחוזים, ומניעת יציאה מהתיקייה
      $path = ($target -split '\?')[0]
      $path = [System.Uri]::UnescapeDataString($path)
      if ($path -eq '/' -or $path -eq '') { $path = '/index.html' }
      $rel = $path.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
      $full = [System.IO.Path]::GetFullPath((Join-Path $root $rel))
      $rootFull = [System.IO.Path]::GetFullPath($root)

      $status = '200 OK'; $body = $null; $ctype = 'application/octet-stream'

      if (-not $full.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        $status = '403 Forbidden'; $body = [System.Text.Encoding]::UTF8.GetBytes('403'); $ctype = 'text/plain'
      } elseif ($method -ne 'GET' -and $method -ne 'HEAD') {
        $status = '405 Method Not Allowed'; $body = [System.Text.Encoding]::UTF8.GetBytes('405'); $ctype = 'text/plain'
      } elseif (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $status = '404 Not Found'; $body = [System.Text.Encoding]::UTF8.GetBytes('404'); $ctype = 'text/plain'
      } else {
        $ext = [System.IO.Path]::GetExtension($full).ToLower()
        if ($mime.ContainsKey($ext)) { $ctype = $mime[$ext] }
        $body = [System.IO.File]::ReadAllBytes($full)
      }

      # שים לב: לקובצי .gz לא נשלח Content-Encoding בכוונה. מנוע ה-OCR מוריד
      # את חבילת השפה הדחוסה ומפרק אותה בעצמו, ופריקה כפולה בדפדפן שוברת אותה.
      $head = "HTTP/1.1 $status`r`n" +
              "Content-Type: $ctype`r`n" +
              "Content-Length: $($body.Length)`r`n" +
              "Cache-Control: no-store`r`n" +
              "X-Content-Type-Options: nosniff`r`n" +
              "Connection: close`r`n`r`n"
      $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
      $stream.Write($hb, 0, $hb.Length)
      if ($method -eq 'GET' -and $body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
      $stream.Flush()
    } catch {
      # חיבור שנקטע באמצע אינו שגיאה שמצדיקה עצירה של השרת
    } finally {
      if ($client) { $client.Close() }
    }
  }
} finally {
  $listener.Stop()
}
