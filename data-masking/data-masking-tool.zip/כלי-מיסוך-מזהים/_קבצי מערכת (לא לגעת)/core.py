# -*- coding: utf-8 -*-
"""
core.py - לוגיקה משותפת לכלי מיסוך המזהים (פסאודונימיזציה הפיכה).

עקרונות:
- אותו ערך מקורי -> אותו אסימון בכל הקבצים והגיליונות (שמירת הצלבות).
- טבלת המיפוי נשמרת מוצפנת (Fernet, מפתח נגזר מסיסמה ב-PBKDF2) מחוץ לתיקיית הפרויקט.
- שום ערך אישי אמיתי אינו נכתב לקבצי הפלט הממוסכים.
"""
import os
import re
import json
import base64
import datetime
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

MAGIC = b"HGJ-ANON-1\n"      # חתימה בתחילת קובץ המיפוי
VERSION = "2.1"
SALT_LEN = 16
PBKDF2_ITERATIONS = 390000


# ----------------------------- סביבת עבודה אחת -----------------------------
# מבנה: תיקייה ראשית ובה רק הפעלה.bat + תיקיות העבודה הממוספרות;
# כל קבצי המערכת (קוד, קונפיג, מפתח) בתת-תיקיית "_קבצי מערכת".
# הקוד מזהה לבד אם הוא רץ מתוך תיקיית המערכת (פריסה) או ממקום אחר (פיתוח).

CLIENT = ""   # אופציונלי: תווית לקוח שתוצג בכותרת החלון. ריק = בלי שם לקוח
SYS_NAME = "_קבצי מערכת (לא לגעת)"

_here = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_here) == SYS_NAME:
    ROOT_DIR = os.path.dirname(_here)          # פריסה: התיקייה הראשית היא ההורה
else:
    ROOT_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "כלי-מיסוך-מזהים")

SYS_DIR = os.path.join(ROOT_DIR, SYS_NAME)
DIR_RAW = os.path.join(ROOT_DIR, "1-קבצים מקוריים (לא להעלות)")
DIR_MASKED = os.path.join(ROOT_DIR, "2-קבצים ממוסכים (בטוח להעלאה)")
DIR_FINDINGS = os.path.join(ROOT_DIR, "3-ממצאים לשחזור (שים כאן)")
DIR_RESTORED = os.path.join(ROOT_DIR, "4-ממצאים משוחזרים (לא להעלות)")
MAPPING_PATH = os.path.join(SYS_DIR, "mapping.enc")

# מיקומי מפתח ישנים (גרסאות קודמות) - מועתקים אוטומטית למיקום החדש אם נמצאו
_DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
LEGACY_MAPPING_PATHS = [
    os.path.join(_DESKTOP, "_KEY_לא-להעלות", "mapping.enc"),
]


def ensure_workspace():
    """יוצר את סביבת העבודה; מהגר mapping.enc ממיקום ישן אם קיים.
    מחזיר רשימת הודעות (למשל על הגירה) להצגה למשתמש."""
    notes = []
    for d in (ROOT_DIR, DIR_RAW, DIR_MASKED, DIR_FINDINGS, DIR_RESTORED, SYS_DIR):
        os.makedirs(d, exist_ok=True)
    if not os.path.exists(MAPPING_PATH):
        for old in LEGACY_MAPPING_PATHS:
            if os.path.exists(old):
                import shutil
                shutil.copy2(old, MAPPING_PATH)
                notes.append("קובץ המפתח הועתק אוטומטית מהמיקום הישן - אותה סיסמה עובדת.")
                break
    return notes


# ----------------------------- קונפיג -----------------------------

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    # מיפוי כותרת מנורמלת -> הגדרת שדה
    alias_map = {}
    for field in cfg["fields"]:
        for alias in field["aliases"]:
            alias_map[normalize_header(alias)] = field
    cfg["_alias_map"] = alias_map
    return cfg


def normalize_header(h):
    """נרמול כותרת עמודה לצורך התאמה: הסרת רווחים בקצוות וכיווץ רווחים כפולים."""
    if h is None:
        return ""
    return " ".join(str(h).strip().split())


# ----------------------------- ערכים -----------------------------

def normalize_value(v):
    """
    נרמול ערך לפני יצירת אסימון, כדי ש-123, 123.0 ו-'123 ' יקבלו אותו אסימון.
    """
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, int):
        return str(v)
    return str(v).strip()


def is_blank(v):
    if v is None:
        return True
    try:
        # pandas NaN
        import math
        if isinstance(v, float) and math.isnan(v):
            return True
    except Exception:
        pass
    return str(v).strip() == ""


# ----------------------------- הצפנה / מיפוי -----------------------------

def _derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def new_mapping():
    return {"version": 1, "maps": {}, "counters": {}}


def load_mapping(path, password):
    """
    טוען מיפוי מוצפן. מחזיר (mapping_dict, salt).
    אם הקובץ לא קיים -> מיפוי חדש + salt חדש.
    זורק ValueError אם הסיסמה שגויה.
    """
    if not os.path.exists(path):
        salt = os.urandom(SALT_LEN)
        return new_mapping(), salt

    with open(path, "rb") as f:
        blob = f.read()
    if not blob.startswith(MAGIC):
        raise ValueError("קובץ המיפוי אינו בפורמט הצפוי (חתימה חסרה).")
    body = blob[len(MAGIC):]
    salt, token = body[:SALT_LEN], body[SALT_LEN:]
    key = _derive_key(password, salt)
    try:
        plaintext = Fernet(key).decrypt(token)
    except InvalidToken:
        raise ValueError("סיסמה שגויה או קובץ מיפוי פגום.")
    mapping = json.loads(plaintext.decode("utf-8"))
    return mapping, salt


def save_mapping(path, mapping, salt, password):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    key = _derive_key(password, salt)
    plaintext = json.dumps(mapping, ensure_ascii=False).encode("utf-8")
    token = Fernet(key).encrypt(plaintext)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(MAGIC + salt + token)
    os.replace(tmp, path)


def build_reverse(mapping):
    """token -> ערך מקורי (לשחזור)."""
    reverse = {}
    for logical, m in mapping.get("maps", {}).items():
        for original, token in m.items():
            reverse[token] = original
    return reverse


# ----------------------------- אסימון / טיפול -----------------------------

def get_token(mapping, field, value, pad):
    logical = field["logical"]
    prefix = field["prefix"]
    m = mapping["maps"].setdefault(logical, {})
    key = normalize_value(value)
    if key in m:
        return m[key]
    c = mapping["counters"].get(logical, 0) + 1
    mapping["counters"][logical] = c
    token = "%s-%0*d" % (prefix, pad, c)
    m[key] = token
    return token


def generalize_year(value):
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.year
    try:
        import pandas as pd
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
        if pd.isna(ts):
            return value
        return int(ts.year)
    except Exception:
        return value


def token_pattern(cfg):
    """תבנית regex לזיהוי ערך שכבר עבר מיסוך (אסימון קיים)."""
    prefixes = cfg.get("token_prefixes_for_reverse", [])
    if not prefixes:
        return None
    return re.compile(r"^(%s)-\d+$" % "|".join(re.escape(p) for p in prefixes))


def already_masked(value, cfg):
    """True אם הערך הוא אסימון קיים או placeholder של מיסוך - אין לגעת בו שוב."""
    s = str(value).strip()
    if s == cfg.get("redaction_placeholder", "***"):
        return True
    pat = cfg.get("_token_pattern")
    if pat is None:
        pat = token_pattern(cfg)
        cfg["_token_pattern"] = pat
    return bool(pat and pat.match(s))


def treat_value(value, field, mapping, cfg):
    """מפעיל את הטיפול על ערך בודד. NaN/ריק נשאר כפי שהוא; אסימון קיים לא מקודד שוב."""
    if is_blank(value):
        return value
    if already_masked(value, cfg):
        return value
    t = field["treatment"]
    if t == "pseudonymize":
        return get_token(mapping, field, value, cfg.get("pseudonymize_pad", 6))
    if t == "redact":
        return cfg.get("redaction_placeholder", "***")
    if t == "generalize_year":
        return generalize_year(value)
    return value


# ----------------------------- סריקת כותרות -----------------------------

HEADER_SCAN_ROWS = 60   # כמה שורות ראשונות לסרוק בחיפוש שורת הכותרת
ID_SAMPLE_MIN = 3       # מינימום ערכים בעמודה כדי לקבוע שהיא "נראית כמו ת"ז"
ID_SAMPLE_SHARE = 0.6   # שיעור הערכים בעמודה שצריכים להיות ת"ז תקינה


def _filled(row):
    return [v for v in row if not is_blank(v)]


def detect_header(rows, alias_map):
    """
    מאתר את שורת הכותרת בין השורות הראשונות. מחזיר (אינדקס שורה, שיטה):
      "alias"     - השורה עם הכי הרבה כותרות מוכרות מהקונפיג (שדה חובה אחד מספיק,
                    או שתי כותרות מוכרות כלשהן).
      "structure" - אין כותרות מוכרות: השורה הראשונה שנראית כמו שורת כותרות של
                    טבלה, כלומר רחבה כמו הטבלה, רובה טקסט, ומתחתיה שורת נתונים.
      "default"   - לא זוהה דבר, שורה ראשונה.
    """
    rows = rows[:HEADER_SCAN_ROWS]
    best_i, best_score = 0, 0
    for i, row in enumerate(rows):
        hits, mand = 0, 0
        for v in row:
            if is_blank(v):
                continue
            f = alias_map.get(normalize_header(v)) if alias_map else None
            if f is not None:
                hits += 1
                mand += 1 if f.get("mandatory") else 0
        score = hits + mand          # שדה חובה שוקל כפול
        if score > best_score:
            best_i, best_score = i, score
    if best_score >= 2:
        return best_i, "alias"

    widths = [len(_filled(r)) for r in rows]
    table_w = max(widths) if widths else 0
    if table_w >= 2:
        for i, row in enumerate(rows[:-1]):
            cells = _filled(row)
            # חצי מרוחב הטבלה מספיק: ייתכנו עמודות נתונים שתא הכותרת שלהן ריק
            if len(cells) < 2 or len(cells) < 0.5 * table_w:
                continue
            texts = sum(1 for v in cells if isinstance(v, str)
                        and not v.strip().replace(".", "").replace("-", "").isdigit())
            if texts < 0.8 * len(cells):
                continue
            if widths[i + 1] >= 2:
                return i, "structure"
    return 0, "default"


def detect_header_row(rows, alias_map):
    """תאימות לאחור: מחזיר רק את אינדקס השורה."""
    return detect_header(rows, alias_map)[0]


def looks_like_id(v):
    """True אם הערך הוא מספר בן 8 עד 9 ספרות עם ספרת ביקורת תקינה של ת"ז ישראלית."""
    if is_blank(v) or isinstance(v, bool):
        return False
    s = normalize_value(v)
    if not s.isdigit():
        # ת"ז שנכתבה עם מקפים או רווחים, למשל 01234567-8
        s = re.sub(r"[\s\-]", "", s)
    if not s.isdigit() or not (8 <= len(s) <= 9):
        return False
    return _id_checksum_ok(s)


def _id_checksum_ok(digits):
    s = digits.zfill(9)
    total = 0
    for i, ch in enumerate(s):
        d = int(ch) * (1 if i % 2 == 0 else 2)
        total += d if d < 10 else d - 9
    return total % 10 == 0


def column_looks_like_ids(values):
    vals = [v for v in values if not is_blank(v)]
    if len(vals) < ID_SAMPLE_MIN:
        return False
    return sum(1 for v in vals if looks_like_id(v)) >= ID_SAMPLE_SHARE * len(vals)


_ID_IN_TEXT = re.compile(r"(?<!\d)\d{8,9}(?!\d)")
_NAME_WORD = re.compile(r"^[A-Za-zא-ת][A-Za-zא-ת'\"׳״\-\.]*$")
NAME_SAMPLE_MIN = 5       # מינימום ערכים בעמודה כדי לקבוע שהיא "נראית כמו שמות"
NAME_SAMPLE_SHARE = 0.7   # שיעור הערכים שנראים כמו שם
NAME_DISTINCT_SHARE = 0.5  # שמות שונים זה מזה; ערכי קטגוריה (מסלול, יישוב) חוזרים על עצמם


def ids_in_text(v):
    """מספרי זהות תקינים שמופיעים בתוך טקסט חופשי (לא תא שכולו מספר)."""
    if not isinstance(v, str):
        return []
    s = v.strip()
    if s.isdigit():
        return []
    return [m for m in _ID_IN_TEXT.findall(s) if _id_checksum_ok(m)]


def looks_like_name(v):
    """True אם הערך נראה כמו שם של אדם: 2 עד 4 מילים של אותיות בלבד, בלי ספרות."""
    if not isinstance(v, str):
        return False
    words = v.replace(",", " ").split()
    if not (2 <= len(words) <= 4) or len(v) > 40:
        return False
    return all(_NAME_WORD.match(w) for w in words)


_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
_PHONE = re.compile(r"^0(5\d|7\d|[23489])\d{7}$")
CONTACT_SAMPLE_MIN = 3
CONTACT_SAMPLE_SHARE = 0.7


def looks_like_email(v):
    return isinstance(v, str) and bool(_EMAIL.match(v.strip()))


def looks_like_phone(v):
    """טלפון ישראלי: נייד או קווי, עם או בלי מקפים, עם קידומת +972, או נייד שאיבד את האפס המוביל."""
    if is_blank(v) or isinstance(v, bool):
        return False
    s = re.sub(r"[\s\-\(\)\.]", "", normalize_value(v))
    if s.startswith("+972"):
        s = "0" + s[4:]
    elif s.startswith("972") and len(s) in (11, 12):
        s = "0" + s[3:]
    elif re.match(r"^5\d{8}$", s) and not isinstance(v, str):
        s = "0" + s        # מספר נייד שנשמר כמספר ואיבד את האפס
    return bool(_PHONE.match(s))


def column_kind(values):
    """
    סוג המזהה שהעמודה מכילה לפי התוכן שלה: "id", "name", "email", "phone", או None.
    זה מה שמאפשר לכלי לעבוד על כל קובץ, גם כשהכותרות אינן מוכרות לו.
    """
    if column_looks_like_ids(values):
        return "id"
    vals = [v for v in values if not is_blank(v)]
    if len(vals) >= CONTACT_SAMPLE_MIN:
        if sum(1 for v in vals if looks_like_email(v)) >= CONTACT_SAMPLE_SHARE * len(vals):
            return "email"
        if sum(1 for v in vals if looks_like_phone(v)) >= CONTACT_SAMPLE_SHARE * len(vals):
            return "phone"
    if column_looks_like_names(values):
        return "name"
    return None


def column_looks_like_names(values):
    vals = [" ".join(str(v).split()) for v in values if not is_blank(v)]
    if len(vals) < NAME_SAMPLE_MIN:
        return False
    if sum(1 for v in vals if looks_like_name(v)) < NAME_SAMPLE_SHARE * len(vals):
        return False
    return len(set(vals)) >= NAME_DISTINCT_SHARE * len(vals)


def _sheet_info(rows, alias_map, override):
    """override: אינדקס שורת כותרת שהמשתמש קבע ידנית (או None לזיהוי אוטומטי)."""
    if override is not None and 0 <= override < max(len(rows), 1):
        hr, method = override, "manual"
    elif alias_map is not None:
        hr, method = detect_header(rows, alias_map)
    else:
        hr, method = 0, "default"
    names = column_names(rows, hr)
    headers, suspect, suspect_names, suspect_other = [], [], [], {}
    for j, h in enumerate(names):
        if h is None:
            continue
        if h not in headers:
            headers.append(h)
        sample = [r[j] for r in rows[hr + 1:] if j < len(r)]
        k = column_kind(sample)
        if k == "id" and h not in suspect:
            suspect.append(h)
        elif k == "name" and h not in suspect_names:
            suspect_names.append(h)
        elif k in ("email", "phone"):
            suspect_other.setdefault(h, k)
    top = rows[:max(hr + 6, 12)]
    return {"header_row": hr, "headers": headers, "method": method, "suspect": suspect,
            "suspect_names": suspect_names, "suspect_other": suspect_other, "top": top}


def unnamed_label(j):
    """שם לעמודה שיש בה נתונים אבל תא הכותרת שלה ריק (j = אינדקס מ-0)."""
    return "עמודה ללא כותרת (%d)" % (j + 1)


def column_names(rows, hr):
    """
    שמות העמודות לפי מיקום, מתוך שורת הכותרת hr. לכל עמודה: הכותרת המנורמלת,
    unnamed_label אם הכותרת ריקה אבל יש נתונים מתחתיה, או None לעמודה ריקה לגמרי.
    העבודה לפי מיקום (ולא לפי שם) היא מה שמבטיח ששתי עמודות באותו שם ימוסכו שתיהן.
    """
    head = rows[hr] if hr < len(rows) else []
    width = max([len(head)] + [len(r) for r in rows[hr + 1:]]) if rows else 0
    names = []
    for j in range(width):
        c = head[j] if j < len(head) else None
        if not is_blank(c):
            names.append(normalize_header(c))
        elif any(j < len(r) and not is_blank(r[j]) for r in rows[hr + 1:]):
            names.append(unnamed_label(j))
        else:
            names.append(None)
    return names


def read_rows(path, limits=None):
    """
    קורא את הגיליונות כרשימות של שורות, בדיוק לפי מספרי השורות של Excel (שורה 1 = אינדקס 0).
    limits: None לקריאת הכל, מספר לכל הגיליונות, או {גיליון: מספר שורות}.
    כל חלקי הכלי קוראים דרך הפונקציה הזו, כדי שמספר שורת הכותרת יהיה זהה בכולם.
    """
    def lim(name):
        if isinstance(limits, dict):
            return limits.get(str(name), limits.get(None))
        return limits

    result = {}
    if path.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                if hasattr(ws, "reset_dimensions"):
                    ws.reset_dimensions()    # לא לסמוך על טווח שנרשם בקובץ
                result[ws.title] = [list(r) for r in ws.iter_rows(min_row=1, max_row=lim(ws.title),
                                                                  values_only=True)]
        finally:
            wb.close()
        return result
    # .xls ישן
    import pandas as pd
    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    for name, df in sheets.items():
        rows = [[None if is_blank(v) else v for v in r] for r in df.values.tolist()]
        n = lim(name)
        result[name] = rows[:n] if n else rows
    return result


def scan_headers(path, alias_map=None, overrides=None):
    """
    קריאה מהירה של תחילת כל גיליון (ללא טעינת כל הנתונים) + איתור שורת הכותרת.
    overrides: {שם גיליון: אינדקס שורת כותרת} שנקבע ידנית.
    מחזיר: {sheet: {"header_row", "headers", "method", "suspect", "top"}}
    suspect = כותרות של עמודות שהערכים בהן נראים כמו מספרי זהות.
    top = השורות הראשונות כפי שהן, לתצוגה מקדימה.
    """
    overrides = overrides or {}
    # שורת כותרת ידנית יכולה להיות מעבר לטווח הסריקה הרגיל
    limits = {None: HEADER_SCAN_ROWS}
    for sh, ov in overrides.items():
        limits[str(sh)] = max(HEADER_SCAN_ROWS, (ov or 0) + 1 + 30)
    result = {}
    for name, rows in read_rows(path, limits).items():
        result[name] = _sheet_info(rows, alias_map, overrides.get(str(name)))
    return result


# ----------------------------- שסתום בטיחות -----------------------------

def masked_originals(mapping):
    """
    הערכים המקוריים של שמות ומספרי זהות שכבר מוסכו, לבדיקה שאינם מופיעים גלויים
    במקום אחר בפלט. מחזיר (שמות של שתי מילים ומעלה, מספרי זהות של 7 ספרות ומעלה).
    שם של מילה אחת אינו נבדק, כי הוא יכול להיות גם מילה רגילה.
    """
    names, ids = set(), set()
    if not mapping:
        return names, ids
    for original in mapping.get("maps", {}).get("name", {}):
        norm = " ".join(str(original).split())
        if len(norm.split()) >= 2 and len(norm) >= 5:
            names.add(norm)
    for original in mapping.get("maps", {}).get("id", {}):
        digits = re.sub(r"[\s\-]", "", str(original))
        if digits.isdigit() and len(digits) >= 7:
            ids.add(digits.lstrip("0") or "0")
    return names, ids


def _leaks_in_cell(v, names, ids):
    """True אם התא מכיל שם או מספר זהות שכבר מוסך במקום אחר."""
    if is_blank(v):
        return False
    s = normalize_value(v)
    if ids:
        for m in re.findall(r"\d{7,9}", re.sub(r"(?<=\d)[\-](?=\d)", "", s)):
            if (m.lstrip("0") or "0") in ids:
                return True
    if names and isinstance(v, str):
        words = s.replace(",", " ").split()
        if " ".join(words) in names:
            return True
        for size in (2, 3, 4):
            for i in range(len(words) - size + 1):
                if " ".join(words[i:i + size]) in names:
                    return True
    return False


def verify_masked(path, cfg, mapping=None, warnings=None, extra_names=None):
    """
    בדיקת בטיחות על קובץ פלט ממוסך. בודקת את התוכן עצמו, בכל גיליון:
    1. לפי שם: כל עמודה ששמה תואם שדה חובה (שם/ת"ז) מכילה אסימונים בלבד.
    2. לפי תוכן: אין אף עמודה, בכל שם שהוא, שרוב הערכים בה הם מספרי זהות תקינים.
       הבדיקה הזו אינה תלויה בזיהוי שורת הכותרת, ולכן תופסת גם קובץ שהכותרות שלו
       לא זוהו או שנקראות בשם לא מוכר.
    3. עם mapping: שם או מספר זהות שכבר מוסך אינו מופיע גלוי בתא אחר, כולל בתוך
       טקסט חופשי, בכותרות, בשם הגיליון ובשם הקובץ.
    מחזיר רשימת בעיות שחוסמות את הקובץ (ריק = תקין).
    warnings: רשימה שאליה מתווספות אזהרות שאינן חוסמות (עמודה שנראית כמו שמות,
    מספר שנראה כמו ת"ז בתוך טקסט).
    """
    alias_map = cfg["_alias_map"]
    pat = token_pattern(cfg)
    placeholder = cfg.get("redaction_placeholder", "***")
    problems = []
    if warnings is None:
        warnings = []
    orig_names, orig_ids = masked_originals(mapping)
    orig_names |= set(extra_names or ())
    base = os.path.basename(path)
    if _leaks_in_cell(os.path.splitext(base)[0].replace("_", " "), orig_names, orig_ids):
        warnings.append("שם הקובץ '%s' מכיל שם או מספר זהות שמוסך בתוך הקובץ. כדאי לשנות את שם הקובץ" % base)
    for sheet, rows in read_rows(path).items():
        if _leaks_in_cell(str(sheet).replace("_", " "), orig_names, orig_ids):
            warnings.append("שם הגיליון '%s' מכיל שם או מספר זהות שמוסך בתוך הקובץ" % sheet)
        hr = detect_header(rows, alias_map)[0]
        names = column_names(rows, hr)
        for j, name in enumerate(names):
            if name is None or not alias_map.get(name, {}).get("mandatory"):
                continue
            vals = [str(r[j]).strip() for r in rows[hr + 1:] if j < len(r) and not is_blank(r[j])]
            bad = sum(1 for v in vals if v != placeholder and not (pat and pat.match(v)))
            if bad:
                problems.append("גיליון '%s', עמודה '%s': %d ערכים לא ממוסכים" % (sheet, name, bad))
        # בדיקת תוכן על הגיליון כולו, בלי להסתמך על שורת הכותרת
        width = max([len(r) for r in rows]) if rows else 0
        for j in range(width):
            values = [r[j] for r in rows if j < len(r)]
            if column_looks_like_ids(values):
                n = sum(1 for v in values if looks_like_id(v))
                problems.append(
                    "גיליון '%s', עמודה מספר %d: %d ערכים שנראים כמו מספרי זהות גלויים. "
                    "יש לסמן את העמודה למיסוך, או לקבוע את שורת הכותרת הנכונה" % (sheet, j + 1, n))
                continue
            label = names[j] if j < len(names) and names[j] else "מספר %d" % (j + 1)
            leaked = sum(1 for v in values if _leaks_in_cell(v, orig_names, orig_ids))
            if leaked:
                problems.append(
                    "גיליון '%s', עמודה '%s': %d תאים מכילים שם או מספר זהות שמוסך בעמודה אחרת. "
                    "יש לסמן גם את העמודה הזו למיסוך" % (sheet, label, leaked))
                continue
            in_text = sum(1 for v in values if ids_in_text(v))
            if in_text:
                warnings.append("גיליון '%s', עמודה '%s': %d תאי טקסט מכילים מספר שנראה כמו ת\"ז" % (
                    sheet, label, in_text))
            data = [r[j] for r in rows[hr + 1:] if j < len(r)]
            k = column_kind(data)
            if k == "name":
                warnings.append("גיליון '%s', עמודה '%s' נראית כמו עמודת שמות ולא מוסכה" % (sheet, label))
            elif k == "email":
                warnings.append("גיליון '%s', עמודה '%s' נראית כמו כתובות דוא\"ל ולא מוסכה" % (sheet, label))
            elif k == "phone":
                warnings.append("גיליון '%s', עמודה '%s' נראית כמו מספרי טלפון ולא מוסכה" % (sheet, label))
    return problems


def column_formats(path, header_rows, sample_rows=200):
    """
    פורמט המספר של כל עמודה (תאריך, שעה, אחוז, מספר עשרוני), לפי תא הנתונים הראשון
    שאינו ריק מתחת לשורת הכותרת. מחזיר {גיליון: {אינדקס עמודה: פורמט}}.
    משמש כדי שהפלט הממוסך יוצג כמו המקור. לקובצי xls ישנים מוחזר מילון ריק.
    """
    result = {}
    if not path.lower().endswith((".xlsx", ".xlsm")):
        return result
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        for ws in wb.worksheets:
            if hasattr(ws, "reset_dimensions"):
                ws.reset_dimensions()
            hr = header_rows.get(ws.title, 0)
            found = {}
            for row in ws.iter_rows(min_row=hr + 2, max_row=hr + 1 + sample_rows):
                for j, cell in enumerate(row):
                    if j in found or cell.value is None:
                        continue
                    fmt = getattr(cell, "number_format", None)
                    if fmt and fmt != "General":
                        found[j] = fmt
                    else:
                        found[j] = None
            result[ws.title] = {j: f for j, f in found.items() if f}
    finally:
        wb.close()
    return result
