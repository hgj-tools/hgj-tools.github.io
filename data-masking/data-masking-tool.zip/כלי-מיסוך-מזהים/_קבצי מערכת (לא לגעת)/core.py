# -*- coding: utf-8 -*-
"""
core.py - לוגיקה משותפת לכלי מיסוך המזהים (פסאודונימיזציה הפיכה).

עקרונות:
- אותו ערך מקורי -> אותו אסימון בכל הקבצים והגיליונות (שמירת הצלבות).
- טבלת המיפוי נשמרת מוצפנת (Fernet, מפתח נגזר מסיסמה ב-PBKDF2) מחוץ לתיקיית הפרויקט.
- שום ערך אישי אמיתי אינו נכתב לקבצי הפלט הממוסכים.
"""
import os
import re
import json
import base64
import datetime
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

MAGIC = b"HGJ-ANON-1\n"      # חתימה בתחילת קובץ המיפוי
SALT_LEN = 16
PBKDF2_ITERATIONS = 390000


# ----------------------------- סביבת עבודה אחת -----------------------------
# מבנה: תיקייה ראשית ובה רק הפעלה.bat + תיקיות העבודה הממוספרות;
# כל קבצי המערכת (קוד, קונפיג, מפתח) בתת-תיקיית "_קבצי מערכת".
# הקוד מזהה לבד אם הוא רץ מתוך תיקיית המערכת (פריסה) או ממקום אחר (פיתוח).

CLIENT = ""   # אופציונלי: תווית לקוח שתוצג בכותרת החלון. ריק = בלי שם לקוח
SYS_NAME = "_קבצי מערכת (לא לגעת)"

_here = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_here) == SYS_NAME:
    ROOT_DIR = os.path.dirname(_here)          # פריסה: התיקייה הראשית היא ההורה
else:
    ROOT_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "כלי-מיסוך-מזהים")

SYS_DIR = os.path.join(ROOT_DIR, SYS_NAME)
DIR_RAW = os.path.join(ROOT_DIR, "1-קבצים מקוריים (לא להעלות)")
DIR_MASKED = os.path.join(ROOT_DIR, "2-קבצים ממוסכים (בטוח להעלאה)")
DIR_FINDINGS = os.path.join(ROOT_DIR, "3-ממצאים לשחזור (שים כאן)")
DIR_RESTORED = os.path.join(ROOT_DIR, "4-ממצאים משוחזרים (לא להעלות)")
MAPPING_PATH = os.path.join(SYS_DIR, "mapping.enc")

# מיקומי מפתח ישנים (גרסאות קודמות) - מועתקים אוטומטית למיקום החדש אם נמצאו
_DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
LEGACY_MAPPING_PATHS = [
    os.path.join(_DESKTOP, "_KEY_לא-להעלות", "mapping.enc"),
]


def ensure_workspace():
    """יוצר את סביבת העבודה; מהגר mapping.enc ממיקום ישן אם קיים.
    מחזיר רשימת הודעות (למשל על הגירה) להצגה למשתמש."""
    notes = []
    for d in (ROOT_DIR, DIR_RAW, DIR_MASKED, DIR_FINDINGS, DIR_RESTORED, SYS_DIR):
        os.makedirs(d, exist_ok=True)
    if not os.path.exists(MAPPING_PATH):
        for old in LEGACY_MAPPING_PATHS:
            if os.path.exists(old):
                import shutil
                shutil.copy2(old, MAPPING_PATH)
                notes.append("קובץ המפתח הועתק אוטומטית מהמיקום הישן - אותה סיסמה עובדת.")
                break
    return notes


# ----------------------------- קונפיג -----------------------------

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    # מיפוי כותרת מנורמלת -> הגדרת שדה
    alias_map = {}
    for field in cfg["fields"]:
        for alias in field["aliases"]:
            alias_map[normalize_header(alias)] = field
    cfg["_alias_map"] = alias_map
    return cfg


def normalize_header(h):
    """נרמול כותרת עמודה לצורך התאמה: הסרת רווחים בקצוות וכיווץ רווחים כפולים."""
    if h is None:
        return ""
    return " ".join(str(h).strip().split())


# ----------------------------- ערכים -----------------------------

def normalize_value(v):
    """
    נרמול ערך לפני יצירת אסימון, כדי ש-123, 123.0 ו-'123 ' יקבלו אותו אסימון.
    """
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, int):
        return str(v)
    return str(v).strip()


def is_blank(v):
    if v is None:
        return True
    try:
        # pandas NaN
        import math
        if isinstance(v, float) and math.isnan(v):
            return True
    except Exception:
        pass
    return str(v).strip() == ""


# ----------------------------- הצפנה / מיפוי -----------------------------

def _derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def new_mapping():
    return {"version": 1, "maps": {}, "counters": {}}


def load_mapping(path, password):
    """
    טוען מיפוי מוצפן. מחזיר (mapping_dict, salt).
    אם הקובץ לא קיים -> מיפוי חדש + salt חדש.
    זורק ValueError אם הסיסמה שגויה.
    """
    if not os.path.exists(path):
        salt = os.urandom(SALT_LEN)
        return new_mapping(), salt

    with open(path, "rb") as f:
        blob = f.read()
    if not blob.startswith(MAGIC):
        raise ValueError("קובץ המיפוי אינו בפורמט הצפוי (חתימה חסרה).")
    body = blob[len(MAGIC):]
    salt, token = body[:SALT_LEN], body[SALT_LEN:]
    key = _derive_key(password, salt)
    try:
        plaintext = Fernet(key).decrypt(token)
    except InvalidToken:
        raise ValueError("סיסמה שגויה או קובץ מיפוי פגום.")
    mapping = json.loads(plaintext.decode("utf-8"))
    return mapping, salt


def save_mapping(path, mapping, salt, password):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    key = _derive_key(password, salt)
    plaintext = json.dumps(mapping, ensure_ascii=False).encode("utf-8")
    token = Fernet(key).encrypt(plaintext)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(MAGIC + salt + token)
    os.replace(tmp, path)


def build_reverse(mapping):
    """token -> ערך מקורי (לשחזור)."""
    reverse = {}
    for logical, m in mapping.get("maps", {}).items():
        for original, token in m.items():
            reverse[token] = original
    return reverse


# ----------------------------- אסימון / טיפול -----------------------------

def get_token(mapping, field, value, pad):
    logical = field["logical"]
    prefix = field["prefix"]
    m = mapping["maps"].setdefault(logical, {})
    key = normalize_value(value)
    if key in m:
        return m[key]
    c = mapping["counters"].get(logical, 0) + 1
    mapping["counters"][logical] = c
    token = "%s-%0*d" % (prefix, pad, c)
    m[key] = token
    return token


def generalize_year(value):
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.year
    try:
        import pandas as pd
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
        if pd.isna(ts):
            return value
        return int(ts.year)
    except Exception:
        return value


def token_pattern(cfg):
    """תבנית regex לזיהוי ערך שכבר עבר מיסוך (אסימון קיים)."""
    prefixes = cfg.get("token_prefixes_for_reverse", [])
    if not prefixes:
        return None
    return re.compile(r"^(%s)-\d+$" % "|".join(re.escape(p) for p in prefixes))


def already_masked(value, cfg):
    """True אם הערך הוא אסימון קיים או placeholder של מיסוך - אין לגעת בו שוב."""
    s = str(value).strip()
    if s == cfg.get("redaction_placeholder", "***"):
        return True
    pat = cfg.get("_token_pattern")
    if pat is None:
        pat = token_pattern(cfg)
        cfg["_token_pattern"] = pat
    return bool(pat and pat.match(s))


def treat_value(value, field, mapping, cfg):
    """מפעיל את הטיפול על ערך בודד. NaN/ריק נשאר כפי שהוא; אסימון קיים לא מקודד שוב."""
    if is_blank(value):
        return value
    if already_masked(value, cfg):
        return value
    t = field["treatment"]
    if t == "pseudonymize":
        return get_token(mapping, field, value, cfg.get("pseudonymize_pad", 6))
    if t == "redact":
        return cfg.get("redaction_placeholder", "***")
    if t == "generalize_year":
        return generalize_year(value)
    return value


# ----------------------------- סריקת כותרות -----------------------------

HEADER_SCAN_ROWS = 10   # כמה שורות ראשונות לסרוק בחיפוש שורת הכותרת


def detect_header_row(rows, alias_map):
    """
    מאתר את שורת הכותרת בין השורות הראשונות: השורה עם הכי הרבה כותרות מוכרות
    (מהקונפיג). נדרשות לפחות 2 התאמות; אחרת ברירת המחדל היא שורה 0.
    מגן ממקרה של שורת כותרת-על מעל שורת הכותרות (שאחרת גורם למיסוך חסרה).
    """
    best_i, best_hits = 0, 0
    for i, row in enumerate(rows[:HEADER_SCAN_ROWS]):
        hits = sum(1 for v in row if v is not None and normalize_header(v) in alias_map)
        if hits > best_hits:
            best_i, best_hits = i, hits
    return best_i if best_hits >= 2 else 0


def scan_headers(path, alias_map=None):
    """
    קריאה מהירה של תחילת כל גיליון (ללא טעינת נתונים) + איתור שורת הכותרת.
    מחזיר: {sheet_name: {"header_row": i, "headers": [...]}}
    """
    def first_rows_xlsx(ws):
        rows = []
        for row in ws.iter_rows(min_row=1, max_row=HEADER_SCAN_ROWS, values_only=True):
            rows.append(list(row))
        return rows

    result = {}
    if path.lower().endswith(".xlsx"):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                rows = first_rows_xlsx(ws)
                hr = detect_header_row(rows, alias_map) if alias_map else 0
                headers = [normalize_header(c) for c in (rows[hr] if hr < len(rows) else []) if c is not None]
                result[ws.title] = {"header_row": hr, "headers": headers}
        finally:
            wb.close()
        return result
    # .xls ישן
    import pandas as pd
    sheets = pd.read_excel(path, sheet_name=None, header=None, nrows=HEADER_SCAN_ROWS)
    for name, df in sheets.items():
        rows = df.values.tolist()
        hr = detect_header_row(rows, alias_map) if alias_map else 0
        headers = [normalize_header(c) for c in (rows[hr] if hr < len(rows) else [])
                   if c is not None and str(c) != "nan"]
        result[name] = {"header_row": hr, "headers": headers}
    return result


# ----------------------------- שסתום בטיחות -----------------------------

def verify_masked(path, cfg):
    """
    בדיקת בטיחות על קובץ פלט ממוסך: בכל גיליון, כל עמודה ששמה תואם שדה חובה
    (שם/ת"ז) חייבת להכיל אך ורק אסימונים/ריקים. מחזיר רשימת בעיות (ריק = תקין).
    """
    import pandas as pd
    alias_map = cfg["_alias_map"]
    pat = token_pattern(cfg)
    problems = []
    scan = scan_headers(path, alias_map)
    for sheet, info in scan.items():
        hr, headers = info["header_row"], info["headers"]
        mand_cols = [h for h in headers if alias_map.get(h, {}).get("mandatory")]
        if not mand_cols:
            continue
        df = pd.read_excel(path, sheet_name=sheet, header=hr, dtype=object)
        df.columns = [normalize_header(c) for c in df.columns]
        for col in mand_cols:
            if col not in df.columns:
                continue
            s = df[col].dropna().astype(str).str.strip()
            s = s[s != ""]
            bad = (~s.str.match(pat)).sum() if pat is not None else len(s)
            if bad:
                problems.append("גיליון '%s', עמודה '%s': %d ערכים לא ממוסכים" % (sheet, col, bad))
    return problems
