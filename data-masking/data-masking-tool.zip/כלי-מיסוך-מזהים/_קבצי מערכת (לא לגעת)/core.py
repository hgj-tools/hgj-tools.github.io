# -*- coding: utf-8 -*-
"""
core.py - לוגיקה משותפת לכלי מיסוך המזהים (פסאודונימיזציה הפיכה).

עקרונות:
- אותו ערך מקורי -> אותו אסימון בכל הקבצים והגיליונות (שמירת הצלבות).
- טבלת המיפוי נשמרת מוצפנת (Fernet, מפתח נגזר מסיסמה ב-PBKDF2) מחוץ לתיקיית הפרויקט.
- שום ערך אישי אמיתי אינו נכתב לקבצי הפלט הממוסכים.
"""
import os
import re
import json
import base64
import datetime
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

MAGIC = b"HGJ-ANON-1\n"      # חתימה בתחילת קובץ המיפוי
VERSION = "1.3"
SALT_LEN = 16
PBKDF2_ITERATIONS = 390000


# ----------------------------- סביבת עבודה אחת -----------------------------
# מבנה: תיקייה ראשית ובה רק הפעלה.bat + תיקיות העבודה הממוספרות;
# כל קבצי המערכת (קוד, קונפיג, מפתח) בתת-תיקיית "_קבצי מערכת".
# הקוד מזהה לבד אם הוא רץ מתוך תיקיית המערכת (פריסה) או ממקום אחר (פיתוח).

CLIENT = ""   # אופציונלי: תווית לקוח שתוצג בכותרת החלון. ריק = בלי שם לקוח
SYS_NAME = "_קבצי מערכת (לא לגעת)"

_here = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(_here) == SYS_NAME:
    ROOT_DIR = os.path.dirname(_here)          # פריסה: התיקייה הראשית היא ההורה
else:
    ROOT_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "כלי-מיסוך-מזהים")

SYS_DIR = os.path.join(ROOT_DIR, SYS_NAME)
DIR_RAW = os.path.join(ROOT_DIR, "1-קבצים מקוריים (לא להעלות)")
DIR_MASKED = os.path.join(ROOT_DIR, "2-קבצים ממוסכים (בטוח להעלאה)")
DIR_FINDINGS = os.path.join(ROOT_DIR, "3-ממצאים לשחזור (שים כאן)")
DIR_RESTORED = os.path.join(ROOT_DIR, "4-ממצאים משוחזרים (לא להעלות)")
MAPPING_PATH = os.path.join(SYS_DIR, "mapping.enc")

# מיקומי מפתח ישנים (גרסאות קודמות) - מועתקים אוטומטית למיקום החדש אם נמצאו
_DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
LEGACY_MAPPING_PATHS = [
    os.path.join(_DESKTOP, "_KEY_לא-להעלות", "mapping.enc"),
]


def ensure_workspace():
    """יוצר את סביבת העבודה; מהגר mapping.enc ממיקום ישן אם קיים.
    מחזיר רשימת הודעות (למשל על הגירה) להצגה למשתמש."""
    notes = []
    for d in (ROOT_DIR, DIR_RAW, DIR_MASKED, DIR_FINDINGS, DIR_RESTORED, SYS_DIR):
        os.makedirs(d, exist_ok=True)
    if not os.path.exists(MAPPING_PATH):
        for old in LEGACY_MAPPING_PATHS:
            if os.path.exists(old):
                import shutil
                shutil.copy2(old, MAPPING_PATH)
                notes.append("קובץ המפתח הועתק אוטומטית מהמיקום הישן - אותה סיסמה עובדת.")
                break
    return notes


# ----------------------------- קונפיג -----------------------------

def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    # מיפוי כותרת מנורמלת -> הגדרת שדה
    alias_map = {}
    for field in cfg["fields"]:
        for alias in field["aliases"]:
            alias_map[normalize_header(alias)] = field
    cfg["_alias_map"] = alias_map
    return cfg


def normalize_header(h):
    """נרמול כותרת עמודה לצורך התאמה: הסרת רווחים בקצוות וכיווץ רווחים כפולים."""
    if h is None:
        return ""
    return " ".join(str(h).strip().split())


# ----------------------------- ערכים -----------------------------

def normalize_value(v):
    """
    נרמול ערך לפני יצירת אסימון, כדי ש-123, 123.0 ו-'123 ' יקבלו אותו אסימון.
    """
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    if isinstance(v, int):
        return str(v)
    return str(v).strip()


def is_blank(v):
    if v is None:
        return True
    try:
        # pandas NaN
        import math
        if isinstance(v, float) and math.isnan(v):
            return True
    except Exception:
        pass
    return str(v).strip() == ""


# ----------------------------- הצפנה / מיפוי -----------------------------

def _derive_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def new_mapping():
    return {"version": 1, "maps": {}, "counters": {}}


def load_mapping(path, password):
    """
    טוען מיפוי מוצפן. מחזיר (mapping_dict, salt).
    אם הקובץ לא קיים -> מיפוי חדש + salt חדש.
    זורק ValueError אם הסיסמה שגויה.
    """
    if not os.path.exists(path):
        salt = os.urandom(SALT_LEN)
        return new_mapping(), salt

    with open(path, "rb") as f:
        blob = f.read()
    if not blob.startswith(MAGIC):
        raise ValueError("קובץ המיפוי אינו בפורמט הצפוי (חתימה חסרה).")
    body = blob[len(MAGIC):]
    salt, token = body[:SALT_LEN], body[SALT_LEN:]
    key = _derive_key(password, salt)
    try:
        plaintext = Fernet(key).decrypt(token)
    except InvalidToken:
        raise ValueError("סיסמה שגויה או קובץ מיפוי פגום.")
    mapping = json.loads(plaintext.decode("utf-8"))
    return mapping, salt


def save_mapping(path, mapping, salt, password):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    key = _derive_key(password, salt)
    plaintext = json.dumps(mapping, ensure_ascii=False).encode("utf-8")
    token = Fernet(key).encrypt(plaintext)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(MAGIC + salt + token)
    os.replace(tmp, path)


def build_reverse(mapping):
    """token -> ערך מקורי (לשחזור)."""
    reverse = {}
    for logical, m in mapping.get("maps", {}).items():
        for original, token in m.items():
            reverse[token] = original
    return reverse


# ----------------------------- אסימון / טיפול -----------------------------

def get_token(mapping, field, value, pad):
    logical = field["logical"]
    prefix = field["prefix"]
    m = mapping["maps"].setdefault(logical, {})
    key = normalize_value(value)
    if key in m:
        return m[key]
    c = mapping["counters"].get(logical, 0) + 1
    mapping["counters"][logical] = c
    token = "%s-%0*d" % (prefix, pad, c)
    m[key] = token
    return token


def generalize_year(value):
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.year
    try:
        import pandas as pd
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
        if pd.isna(ts):
            return value
        return int(ts.year)
    except Exception:
        return value


def token_pattern(cfg):
    """תבנית regex לזיהוי ערך שכבר עבר מיסוך (אסימון קיים)."""
    prefixes = cfg.get("token_prefixes_for_reverse", [])
    if not prefixes:
        return None
    return re.compile(r"^(%s)-\d+$" % "|".join(re.escape(p) for p in prefixes))


def already_masked(value, cfg):
    """True אם הערך הוא אסימון קיים או placeholder של מיסוך - אין לגעת בו שוב."""
    s = str(value).strip()
    if s == cfg.get("redaction_placeholder", "***"):
        return True
    pat = cfg.get("_token_pattern")
    if pat is None:
        pat = token_pattern(cfg)
        cfg["_token_pattern"] = pat
    return bool(pat and pat.match(s))


def treat_value(value, field, mapping, cfg):
    """מפעיל את הטיפול על ערך בודד. NaN/ריק נשאר כפי שהוא; אסימון קיים לא מקודד שוב."""
    if is_blank(value):
        return value
    if already_masked(value, cfg):
        return value
    t = field["treatment"]
    if t == "pseudonymize":
        return get_token(mapping, field, value, cfg.get("pseudonymize_pad", 6))
    if t == "redact":
        return cfg.get("redaction_placeholder", "***")
    if t == "generalize_year":
        return generalize_year(value)
    return value


# ----------------------------- סריקת כותרות -----------------------------

HEADER_SCAN_ROWS = 60   # כמה שורות ראשונות לסרוק בחיפוש שורת הכותרת
ID_SAMPLE_MIN = 3       # מינימום ערכים בעמודה כדי לקבוע שהיא "נראית כמו ת"ז"
ID_SAMPLE_SHARE = 0.6   # שיעור הערכים בעמודה שצריכים להיות ת"ז תקינה


def _filled(row):
    return [v for v in row if not is_blank(v)]


def detect_header(rows, alias_map):
    """
    מאתר את שורת הכותרת בין השורות הראשונות. מחזיר (אינדקס שורה, שיטה):
      "alias"     - השורה עם הכי הרבה כותרות מוכרות מהקונפיג (שדה חובה אחד מספיק,
                    או שתי כותרות מוכרות כלשהן).
      "structure" - אין כותרות מוכרות: השורה הראשונה שנראית כמו שורת כותרות של
                    טבלה, כלומר רחבה כמו הטבלה, רובה טקסט, ומתחתיה שורת נתונים.
      "default"   - לא זוהה דבר, שורה ראשונה.
    """
    rows = rows[:HEADER_SCAN_ROWS]
    best_i, best_score = 0, 0
    for i, row in enumerate(rows):
        hits, mand = 0, 0
        for v in row:
            if is_blank(v):
                continue
            f = alias_map.get(normalize_header(v)) if alias_map else None
            if f is not None:
                hits += 1
                mand += 1 if f.get("mandatory") else 0
        score = hits + mand          # שדה חובה שוקל כפול
        if score > best_score:
            best_i, best_score = i, score
    if best_score >= 2:
        return best_i, "alias"

    widths = [len(_filled(r)) for r in rows]
    table_w = max(widths) if widths else 0
    if table_w >= 2:
        for i, row in enumerate(rows[:-1]):
            cells = _filled(row)
            # חצי מרוחב הטבלה מספיק: ייתכנו עמודות נתונים שתא הכותרת שלהן ריק
            if len(cells) < 2 or len(cells) < 0.5 * table_w:
                continue
            texts = sum(1 for v in cells if isinstance(v, str)
                        and not v.strip().replace(".", "").replace("-", "").isdigit())
            if texts < 0.8 * len(cells):
                continue
            if widths[i + 1] >= 2:
                return i, "structure"
    return 0, "default"


def detect_header_row(rows, alias_map):
    """תאימות לאחור: מחזיר רק את אינדקס השורה."""
    return detect_header(rows, alias_map)[0]


def looks_like_id(v):
    """True אם הערך הוא מספר בן 8 עד 9 ספרות עם ספרת ביקורת תקינה של ת"ז ישראלית."""
    if is_blank(v) or isinstance(v, bool):
        return False
    s = normalize_value(v)
    if not s.isdigit() or not (8 <= len(s) <= 9):
        return False
    s = s.zfill(9)
    total = 0
    for i, ch in enumerate(s):
        d = int(ch) * (1 if i % 2 == 0 else 2)
        total += d if d < 10 else d - 9
    return total % 10 == 0


def column_looks_like_ids(values):
    vals = [v for v in values if not is_blank(v)]
    if len(vals) < ID_SAMPLE_MIN:
        return False
    return sum(1 for v in vals if looks_like_id(v)) >= ID_SAMPLE_SHARE * len(vals)


def _sheet_info(rows, alias_map, override):
    """override: אינדקס שורת כותרת שהמשתמש קבע ידנית (או None לזיהוי אוטומטי)."""
    if override is not None and 0 <= override < max(len(rows), 1):
        hr, method = override, "manual"
    elif alias_map is not None:
        hr, method = detect_header(rows, alias_map)
    else:
        hr, method = 0, "default"
    names = column_names(rows, hr)
    headers, suspect = [], []
    for j, h in enumerate(names):
        if h is None:
            continue
        if h not in headers:
            headers.append(h)
        sample = [r[j] for r in rows[hr + 1:] if j < len(r)]
        if column_looks_like_ids(sample) and h not in suspect:
            suspect.append(h)
    top = rows[:max(hr + 6, 12)]
    return {"header_row": hr, "headers": headers, "method": method, "suspect": suspect, "top": top}


def unnamed_label(j):
    """שם לעמודה שיש בה נתונים אבל תא הכותרת שלה ריק (j = אינדקס מ-0)."""
    return "עמודה ללא כותרת (%d)" % (j + 1)


def column_names(rows, hr):
    """
    שמות העמודות לפי מיקום, מתוך שורת הכותרת hr. לכל עמודה: הכותרת המנורמלת,
    unnamed_label אם הכותרת ריקה אבל יש נתונים מתחתיה, או None לעמודה ריקה לגמרי.
    העבודה לפי מיקום (ולא לפי שם) היא מה שמבטיח ששתי עמודות באותו שם ימוסכו שתיהן.
    """
    head = rows[hr] if hr < len(rows) else []
    width = max([len(head)] + [len(r) for r in rows[hr + 1:]]) if rows else 0
    names = []
    for j in range(width):
        c = head[j] if j < len(head) else None
        if not is_blank(c):
            names.append(normalize_header(c))
        elif any(j < len(r) and not is_blank(r[j]) for r in rows[hr + 1:]):
            names.append(unnamed_label(j))
        else:
            names.append(None)
    return names


def read_rows(path, limits=None):
    """
    קורא את הגיליונות כרשימות של שורות, בדיוק לפי מספרי השורות של Excel (שורה 1 = אינדקס 0).
    limits: None לקריאת הכל, מספר לכל הגיליונות, או {גיליון: מספר שורות}.
    כל חלקי הכלי קוראים דרך הפונקציה הזו, כדי שמספר שורת הכותרת יהיה זהה בכולם.
    """
    def lim(name):
        if isinstance(limits, dict):
            return limits.get(str(name), limits.get(None))
        return limits

    result = {}
    if path.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                if hasattr(ws, "reset_dimensions"):
                    ws.reset_dimensions()    # לא לסמוך על טווח שנרשם בקובץ
                result[ws.title] = [list(r) for r in ws.iter_rows(min_row=1, max_row=lim(ws.title),
                                                                  values_only=True)]
        finally:
            wb.close()
        return result
    # .xls ישן
    import pandas as pd
    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    for name, df in sheets.items():
        rows = [[None if is_blank(v) else v for v in r] for r in df.values.tolist()]
        n = lim(name)
        result[name] = rows[:n] if n else rows
    return result


def scan_headers(path, alias_map=None, overrides=None):
    """
    קריאה מהירה של תחילת כל גיליון (ללא טעינת כל הנתונים) + איתור שורת הכותרת.
    overrides: {שם גיליון: אינדקס שורת כותרת} שנקבע ידנית.
    מחזיר: {sheet: {"header_row", "headers", "method", "suspect", "top"}}
    suspect = כותרות של עמודות שהערכים בהן נראים כמו מספרי זהות.
    top = השורות הראשונות כפי שהן, לתצוגה מקדימה.
    """
    overrides = overrides or {}
    # שורת כותרת ידנית יכולה להיות מעבר לטווח הסריקה הרגיל
    limits = {None: HEADER_SCAN_ROWS}
    for sh, ov in overrides.items():
        limits[str(sh)] = max(HEADER_SCAN_ROWS, (ov or 0) + 1 + 30)
    result = {}
    for name, rows in read_rows(path, limits).items():
        result[name] = _sheet_info(rows, alias_map, overrides.get(str(name)))
    return result


# ----------------------------- שסתום בטיחות -----------------------------

def verify_masked(path, cfg):
    """
    בדיקת בטיחות על קובץ פלט ממוסך. שתי בדיקות, בכל גיליון:
    1. לפי שם: כל עמודה ששמה תואם שדה חובה (שם/ת"ז) מכילה אסימונים בלבד.
    2. לפי תוכן: אין אף עמודה, בכל שם שהוא, שרוב הערכים בה הם מספרי זהות תקינים.
       הבדיקה הזו אינה תלויה בזיהוי שורת הכותרת, ולכן תופסת גם קובץ שהכותרות שלו
       לא זוהו או שנקראות בשם לא מוכר.
    מחזיר רשימת בעיות (ריק = תקין).
    """
    alias_map = cfg["_alias_map"]
    pat = token_pattern(cfg)
    placeholder = cfg.get("redaction_placeholder", "***")
    problems = []
    for sheet, rows in read_rows(path).items():
        hr = detect_header(rows, alias_map)[0]
        names = column_names(rows, hr)
        for j, name in enumerate(names):
            if name is None or not alias_map.get(name, {}).get("mandatory"):
                continue
            vals = [str(r[j]).strip() for r in rows[hr + 1:] if j < len(r) and not is_blank(r[j])]
            bad = sum(1 for v in vals if v != placeholder and not (pat and pat.match(v)))
            if bad:
                problems.append("גיליון '%s', עמודה '%s': %d ערכים לא ממוסכים" % (sheet, name, bad))
        # בדיקת תוכן על הגיליון כולו, בלי להסתמך על שורת הכותרת
        width = max([len(r) for r in rows]) if rows else 0
        for j in range(width):
            values = [r[j] for r in rows if j < len(r)]
            if column_looks_like_ids(values):
                n = sum(1 for v in values if looks_like_id(v))
                problems.append(
                    "גיליון '%s', עמודה מספר %d: %d ערכים שנראים כמו מספרי זהות גלויים. "
                    "יש לסמן את העמודה למיסוך, או לקבוע את שורת הכותרת הנכונה" % (sheet, j + 1, n))
    return problems
