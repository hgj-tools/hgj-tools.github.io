# -*- coding: utf-8 -*-
"""
anonymize.py - מיסוך קובצי Excel לפני העלאה לתיקיית הפרויקט.

שימוש:
    python anonymize.py <תיקיית_קלט> <תיקיית_פלט> [--config config.json]
                        [--mapping <נתיב mapping.enc>] [--selection selection.json]
                        [--in-place] [--password <סיסמה>]

התנהגות:
- סורק רקורסיבית קובצי .xlsx/.xls בתיקיית הקלט.
- שדות חובה (name/id, mandatory בקונפיג) ממוסכים תמיד.
- עם --selection: שאר העמודות ממוסכות רק אם נבחרו (לפי קובץ/גיליון/כותרת).
  עמודה נבחרת שאינה מוכרת בקונפיג מקבלת אסימון גנרי FLD.
- בלי --selection: תאימות לאחור - כל שדה מוכר בקונפיג ממוסך.
- ערך שכבר אסימון (ACC-.../ID-.../***) לעולם לא מקודד שוב - בטוח להרצה חוזרת.
- עם --in-place: קלט=פלט (מיסוך נוסף על תיקייה שכבר עברה מיסוך); כתיבה אטומית.
- טבלת המיפוי המוצפנת מתעדכנת (אותו ערך -> אותו אסימון בכל הקבצים).
"""
import os
import sys
import glob
import json
import shutil
import argparse
import getpass

import pandas as pd

import core

DEFAULT_MAPPING = core.MAPPING_PATH


def get_password(new_file):
    if new_file:
        while True:
            p1 = getpass.getpass("בחר/י סיסמה למפתח ההצפנה: ")
            if len(p1) < 6:
                print("  הסיסמה קצרה מדי (מינימום 6 תווים).")
                continue
            p2 = getpass.getpass("אימות סיסמה: ")
            if p1 != p2:
                print("  הסיסמאות אינן תואמות, נסה/י שוב.")
                continue
            return p1
    return getpass.getpass("סיסמת המפתח: ")


def load_selection(path):
    """selection.json: {"selected": {rel_path: {sheet: [headers...]}}}. None = הכל (תאימות לאחור)."""
    if not path:
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("selected", {})


def load_header_rows(path):
    """selection.json: {"header_rows": {rel_path: {sheet: אינדקס שורה}}}, שורות כותרת שנקבעו ידנית."""
    if not path or not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f).get("header_rows", {}) or {}


def column_action(rel, sheet_name, col, cfg, selection):
    """
    מחזיר את הגדרת השדה למיסוך עבור עמודה, או None אם אין למסך.
    - שדה חובה: תמיד ממוסך.
    - עם selection: ממוסך רק אם נבחר; עמודה לא-מוכרת שנבחרה -> custom_field (FLD).
    - בלי selection: כל שדה מוכר ממוסך (התנהגות ישנה).
    """
    norm = core.normalize_header(col)
    field = cfg["_alias_map"].get(norm)
    if field is not None and field.get("mandatory"):
        return field
    if selection is None:
        return field
    sel_sheets = selection.get(rel, {})
    sel_headers = sel_sheets.get(sheet_name, [])
    if norm in sel_headers:
        return field if field is not None else cfg.get("custom_field")
    return None


def sheet_columns_to_mask(rel, sheet_name, names, cfg, selection):
    """names: שמות העמודות לפי מיקום. מחזיר {אינדקס עמודה: הגדרת שדה}."""
    out = {}
    for j, name in enumerate(names):
        if name is None:
            continue
        field = column_action(rel, sheet_name, name, cfg, selection)
        if field is not None:
            out[j] = field
    return out


def process_file(in_path, out_path, rel, cfg, mapping, selection, in_place, header_rows=None, warnings=None):
    try:
        # איתור שורת הכותרת בכל גיליון, וקריאת הנתונים באותו קורא בדיוק (אותם מספרי שורות)
        scan = core.scan_headers(in_path, cfg["_alias_map"], (header_rows or {}).get(rel))
        all_rows = core.read_rows(in_path)
        sheets, names = {}, {}
        for sheet_name, info in scan.items():
            rows = all_rows.get(sheet_name, [])
            hr = info["header_row"]
            names[sheet_name] = core.column_names(rows, hr)
            width = len(names[sheet_name])
            body = [list(r) + [None] * (width - len(r)) for r in rows[hr:]]   # הכותרת והנתונים
            sheets[sheet_name] = pd.DataFrame(body, dtype=object)
    except Exception as e:
        print("  [דילוג] לא ניתן לקרוא %s: %s" % (os.path.basename(in_path), e))
        return "error", []

    plan = {name: sheet_columns_to_mask(rel, name, names[name], cfg, selection)
            for name in sheets}
    masked_any = any(plan.values())
    if not masked_any and in_place:
        return "unchanged", []
    # גם קובץ שאין בו מה למסך נכתב מחדש ולא מועתק כפי שהוא, כדי שהערות תאים,
    # גיליונות מוסתרים, נוסחאות ומאפייני הקובץ (שם המחבר) לא יעברו לפלט.

    out_xlsx = os.path.splitext(out_path)[0] + ".xlsx"
    os.makedirs(os.path.dirname(out_xlsx), exist_ok=True)
    tmp_path = out_xlsx + ".tmp.xlsx"
    touched_cols = []
    by_logical = {f["logical"]: f for f in cfg["fields"]}
    custom = cfg.get("custom_field")
    full_names = set()
    for sheet_name, df in sheets.items():
        # עמודה חופשית שהתוכן שלה הוא מספרי זהות או שמות מקבלת את סוג השדה המתאים
        # (ID- / NAME-), וכך היא נכנסת גם לבדיקת "מזהה שמוסך ומופיע גלוי במקום אחר".
        for j, field in list(plan[sheet_name].items()):
            # גם עמודת "לקוח" או "ספק" שמכילה בפועל שמות של אנשים או מספרי זהות
            if field is custom or field.get("logical") == "company":
                data = df.iloc[1:, j].tolist()
                k = core.column_kind(data)
                if k in by_logical:
                    plan[sheet_name][j] = by_logical[k]
        # שם פרטי ושם משפחה בעמודות נפרדות: גם הצירוף שלהם נבדק שאינו מופיע גלוי
        name_cols = [j for j, f in plan[sheet_name].items() if f.get("logical") == "name"]
        if len(name_cols) >= 2:
            for row in df.iloc[1:, name_cols].itertuples(index=False):
                parts = [" ".join(str(v).split()) for v in row if not core.is_blank(v)]
                for a in parts:
                    for b in parts:
                        if a != b:
                            full_names.add(a + " " + b)
    # הכתיבה נעשית ישירות ב-openpyxl ולא דרך pandas, כדי שסוגי הנתונים יישמרו:
    # שעה נשארת שעה (ולא שבר עשרוני), תאריך נשאר תאריך, ומספר נשאר מספר.
    import openpyxl
    formats = core.column_formats(in_path, {s: i["header_row"] for s, i in scan.items()})
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for sheet_name, df in sheets.items():
        for j, field in plan[sheet_name].items():
            touched_cols.append("%s:%s [%s]" % (sheet_name, names[sheet_name][j], field["treatment"]))
            # שורה 0 היא הכותרת עצמה, והיא נשארת כפי שהיא
            df.iloc[1:, j] = df.iloc[1:, j].map(lambda v: core.treat_value(v, field, mapping, cfg))
        ws = wb.create_sheet(str(sheet_name)[:31])
        ws.sheet_view.rightToLeft = True
        masked_cols = set(plan[sheet_name])
        fmts = formats.get(sheet_name, {})
        for i, row in enumerate(df.itertuples(index=False, name=None)):
            ws.append([None if core.is_blank(v) else v for v in row])
            if i == 0:
                continue
            for j, fmt in fmts.items():
                if j in masked_cols or j >= len(row) or isinstance(row[j], str) or core.is_blank(row[j]):
                    continue
                ws.cell(row=i + 1, column=j + 1).number_format = fmt
    if not wb.sheetnames:
        wb.create_sheet("Sheet1")
    wb.save(tmp_path)
    wb.close()
    os.replace(tmp_path, out_xlsx)
    # שסתום בטיחות: בדיקת הפלט עצמו, כולל מזהים שמוסכו ומופיעים גלויים במקום אחר
    file_warnings = []
    problems = core.verify_masked(out_xlsx, cfg, mapping, file_warnings, extra_names=full_names)
    if problems:
        if not in_place:
            os.remove(out_xlsx)
        return "blocked", problems
    if warnings is not None:
        warnings.extend("%s: %s" % (rel, w) for w in file_warnings)
    return ("anonymized" if masked_any else "copied"), touched_cols


def run(input_dir, output_dir, config_path, mapping_path, selection_path=None,
        in_place=False, password=None, log=print):
    """מריץ מיסוך. מוחזר dict סיכום (משמש גם את ה-GUI)."""
    cfg = core.load_config(config_path)
    selection = load_selection(selection_path)
    header_rows = load_header_rows(selection_path)

    new_file = not os.path.exists(mapping_path)
    if password is None:
        password = get_password(new_file)
    mapping, salt = core.load_mapping(mapping_path, password)

    counters_before = dict(mapping["counters"])

    files = []
    for ext in ("*.xlsx", "*.xls"):
        files.extend(glob.glob(os.path.join(input_dir, "**", ext), recursive=True))
    files = sorted(f for f in set(files) if not f.endswith(".tmp.xlsx"))
    files = [f for f in files if not os.path.basename(f).startswith("~$")]
    skipped = sorted(os.path.relpath(f, input_dir).replace("\\", "/")
                     for ext in ("*.xlsm", "*.xlsb", "*.csv", "*.ods")
                     for f in glob.glob(os.path.join(input_dir, "**", ext), recursive=True))
    if not files:
        log("לא נמצאו קובצי Excel בתיקיית הקלט.")
        for s in skipped:
            log("[דולג] %s - סוג קובץ שאינו נתמך (נתמכים xlsx ו-xls בלבד)" % s)
        return {"stats": {}, "new_tokens": {}, "details": [], "warnings": [], "skipped": skipped}

    stats = {"anonymized": 0, "copied": 0, "unchanged": 0, "error": 0, "blocked": 0}
    details = []
    warnings = []
    log("=" * 60)
    for s in skipped:
        log("[דולג] %s - סוג קובץ שאינו נתמך (נתמכים xlsx ו-xls בלבד)" % s)
    for in_path in files:
        rel = os.path.relpath(in_path, input_dir).replace("\\", "/")
        out_path = in_path if in_place else os.path.join(output_dir, rel)
        status, cols = process_file(in_path, out_path, rel, cfg, mapping, selection, in_place,
                                    header_rows, warnings)
        stats[status] += 1
        label = {"anonymized": "ממוסך", "copied": "נכתב מחדש, בלי עמודות למיסוך", "unchanged": "ללא שינוי",
                 "error": "שגיאה", "blocked": "!! נחסם - נותר מידע אישי"}[status]
        log("[%s] %s" % (label, rel))
        details.append((rel, status, cols))
        for c in cols:
            log("        - %s" % c)
        if status == "blocked":
            log("        הקובץ לא נשמר בפלט. במסך בחירת השדות: לחיצה כפולה על שורת הגיליון "
                "קובעת את שורת הכותרת, ולחיצה כפולה על עמודה מסמנת אותה למיסוך.")

    core.save_mapping(mapping_path, mapping, salt, password)

    new_tokens = {}
    for logical, after in mapping["counters"].items():
        delta = after - counters_before.get(logical, 0)
        if delta:
            new_tokens[logical] = (delta, after)

    log("=" * 60)
    log("סיכום: מוסכו %d | הועתקו %d | ללא שינוי %d | שגיאות %d | נחסמו %d" %
        (stats["anonymized"], stats["copied"], stats["unchanged"], stats["error"], stats["blocked"]))
    if stats["blocked"]:
        log("!! אזהרה: קבצים שנחסמו לא נכתבו לפלט כי נותר בהם מידע אישי גלוי.")
    if warnings:
        log("לבדיקה לפני העלאה (%d):" % len(warnings))
        for w in warnings:
            log("        ? %s" % w)
    if new_tokens:
        log("אסימונים חדשים שנוצרו בריצה זו (לפי שדה לוגי):")
        for logical, (delta, after) in new_tokens.items():
            log("        %-10s +%d (סה\"כ %d)" % (logical, delta, after))
    log("קובץ המיפוי המוצפן: " + os.path.abspath(mapping_path))
    log("תיקיית הפלט הממוסך: " + os.path.abspath(input_dir if in_place else output_dir))
    return {"stats": stats, "new_tokens": new_tokens, "details": details,
            "warnings": warnings, "skipped": skipped}


def main():
    ap = argparse.ArgumentParser(description="מיסוך קובצי Excel (פסאודונימיזציה הפיכה).")
    ap.add_argument("input_dir", help="תיקיית הקלט (קבצים מקוריים)")
    ap.add_argument("output_dir", nargs="?", default=None,
                    help="תיקיית הפלט (קבצים ממוסכים); לא נדרש עם --in-place")
    ap.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "config.json"))
    ap.add_argument("--mapping", default=DEFAULT_MAPPING)
    ap.add_argument("--selection", default=None, help="selection.json - אילו עמודות למסך (חובה תמיד ממוסך)")
    ap.add_argument("--in-place", action="store_true",
                    help="מיסוך נוסף על התיקייה עצמה (קלט=פלט), לקבצים שכבר עברו מיסוך")
    args = ap.parse_args()

    if args.in_place:
        output_dir = args.input_dir
    else:
        if not args.output_dir:
            print("שגיאה: נדרשת תיקיית פלט (או --in-place).")
            sys.exit(1)
        if os.path.abspath(args.input_dir) == os.path.abspath(args.output_dir):
            print("שגיאה: תיקיית הקלט והפלט חייבות להיות שונות (למיסוך חוזר השתמש/י ב---in-place).")
            sys.exit(1)
        output_dir = args.output_dir

    try:
        run(args.input_dir, output_dir, args.config, args.mapping,
            selection_path=args.selection, in_place=args.in_place)
    except ValueError as e:
        print("שגיאה:", e)
        sys.exit(1)
    print("שמור/י על קובץ המיפוי ועל הסיסמה - בלעדיהם לא ניתן לשחזר את הנתונים.")


if __name__ == "__main__":
    main()
