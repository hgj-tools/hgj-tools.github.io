# -*- coding: utf-8 -*-
"""
anonymize.py - מיסוך קובצי Excel לפני העלאה לתיקיית הפרויקט.

שימוש:
    python anonymize.py <תיקיית_קלט> <תיקיית_פלט> [--config config.json]
                        [--mapping <נתיב mapping.enc>] [--selection selection.json]
                        [--in-place] [--password <סיסמה>]

התנהגות:
- סורק רקורסיבית קובצי .xlsx/.xls בתיקיית הקלט.
- שדות חובה (name/id, mandatory בקונפיג) ממוסכים תמיד.
- עם --selection: שאר העמודות ממוסכות רק אם נבחרו (לפי קובץ/גיליון/כותרת).
  עמודה נבחרת שאינה מוכרת בקונפיג מקבלת אסימון גנרי FLD.
- בלי --selection: תאימות לאחור - כל שדה מוכר בקונפיג ממוסך.
- ערך שכבר אסימון (ACC-.../ID-.../***) לעולם לא מקודד שוב - בטוח להרצה חוזרת.
- עם --in-place: קלט=פלט (מיסוך נוסף על תיקייה שכבר עברה מיסוך); כתיבה אטומית.
- טבלת המיפוי המוצפנת מתעדכנת (אותו ערך -> אותו אסימון בכל הקבצים).
"""
import os
import sys
import glob
import json
import shutil
import argparse
import getpass

import pandas as pd

import core

DEFAULT_MAPPING = core.MAPPING_PATH


def get_password(new_file):
    if new_file:
        while True:
            p1 = getpass.getpass("בחר/י סיסמה למפתח ההצפנה: ")
            if len(p1) < 6:
                print("  הסיסמה קצרה מדי (מינימום 6 תווים).")
                continue
            p2 = getpass.getpass("אימות סיסמה: ")
            if p1 != p2:
                print("  הסיסמאות אינן תואמות, נסה/י שוב.")
                continue
            return p1
    return getpass.getpass("סיסמת המפתח: ")


def load_selection(path):
    """selection.json: {"selected": {rel_path: {sheet: [headers...]}}}. None = הכל (תאימות לאחור)."""
    if not path:
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("selected", {})


def load_header_rows(path):
    """selection.json: {"header_rows": {rel_path: {sheet: אינדקס שורה}}}, שורות כותרת שנקבעו ידנית."""
    if not path or not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f).get("header_rows", {}) or {}


def column_action(rel, sheet_name, col, cfg, selection):
    """
    מחזיר את הגדרת השדה למיסוך עבור עמודה, או None אם אין למסך.
    - שדה חובה: תמיד ממוסך.
    - עם selection: ממוסך רק אם נבחר; עמודה לא-מוכרת שנבחרה -> custom_field (FLD).
    - בלי selection: כל שדה מוכר ממוסך (התנהגות ישנה).
    """
    norm = core.normalize_header(col)
    field = cfg["_alias_map"].get(norm)
    if field is not None and field.get("mandatory"):
        return field
    if selection is None:
        return field
    sel_sheets = selection.get(rel, {})
    sel_headers = sel_sheets.get(sheet_name, [])
    if norm in sel_headers:
        return field if field is not None else cfg.get("custom_field")
    return None


def sheet_columns_to_mask(rel, sheet_name, names, cfg, selection):
    """names: שמות העמודות לפי מיקום. מחזיר {אינדקס עמודה: הגדרת שדה}."""
    out = {}
    for j, name in enumerate(names):
        if name is None:
            continue
        field = column_action(rel, sheet_name, name, cfg, selection)
        if field is not None:
            out[j] = field
    return out


def process_file(in_path, out_path, rel, cfg, mapping, selection, in_place, header_rows=None):
    try:
        # איתור שורת הכותרת בכל גיליון, וקריאת הנתונים באותו קורא בדיוק (אותם מספרי שורות)
        scan = core.scan_headers(in_path, cfg["_alias_map"], (header_rows or {}).get(rel))
        all_rows = core.read_rows(in_path)
        sheets, names = {}, {}
        for sheet_name, info in scan.items():
            rows = all_rows.get(sheet_name, [])
            hr = info["header_row"]
            names[sheet_name] = core.column_names(rows, hr)
            width = len(names[sheet_name])
            body = [list(r) + [None] * (width - len(r)) for r in rows[hr:]]   # הכותרת והנתונים
            sheets[sheet_name] = pd.DataFrame(body, dtype=object)
    except Exception as e:
        print("  [דילוג] לא ניתן לקרוא %s: %s" % (os.path.basename(in_path), e))
        return "error", []

    plan = {name: sheet_columns_to_mask(rel, name, names[name], cfg, selection)
            for name in sheets}
    if not any(plan.values()):
        if in_place:
            return "unchanged", []
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        shutil.copy2(in_path, out_path)
        problems = core.verify_masked(out_path, cfg)
        if problems:
            os.remove(out_path)
            return "blocked", problems
        return "copied", []

    out_xlsx = os.path.splitext(out_path)[0] + ".xlsx"
    os.makedirs(os.path.dirname(out_xlsx), exist_ok=True)
    tmp_path = out_xlsx + ".tmp.xlsx"
    touched_cols = []
    with pd.ExcelWriter(tmp_path, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            for j, field in plan[sheet_name].items():
                touched_cols.append("%s:%s [%s]" % (sheet_name, names[sheet_name][j], field["treatment"]))
                # שורה 0 היא הכותרת עצמה, והיא נשארת כפי שהיא
                df.iloc[1:, j] = df.iloc[1:, j].map(lambda v: core.treat_value(v, field, mapping, cfg))
            safe_name = str(sheet_name)[:31]
            df.to_excel(writer, sheet_name=safe_name, index=False, header=False)
            writer.sheets[safe_name].sheet_view.rightToLeft = True
    os.replace(tmp_path, out_xlsx)
    # שסתום בטיחות: אימות שכל עמודות החובה בפלט מכילות אסימונים בלבד
    problems = core.verify_masked(out_xlsx, cfg)
    if problems:
        if not in_place:
            os.remove(out_xlsx)
        return "blocked", problems
    return "anonymized", touched_cols


def run(input_dir, output_dir, config_path, mapping_path, selection_path=None,
        in_place=False, password=None, log=print):
    """מריץ מיסוך. מוחזר dict סיכום (משמש גם את ה-GUI)."""
    cfg = core.load_config(config_path)
    selection = load_selection(selection_path)
    header_rows = load_header_rows(selection_path)

    new_file = not os.path.exists(mapping_path)
    if password is None:
        password = get_password(new_file)
    mapping, salt = core.load_mapping(mapping_path, password)

    counters_before = dict(mapping["counters"])

    files = []
    for ext in ("*.xlsx", "*.xls"):
        files.extend(glob.glob(os.path.join(input_dir, "**", ext), recursive=True))
    files = sorted(f for f in set(files) if not f.endswith(".tmp.xlsx"))
    if not files:
        log("לא נמצאו קובצי Excel בתיקיית הקלט.")
        return {"stats": {}, "new_tokens": {}, "details": []}

    stats = {"anonymized": 0, "copied": 0, "unchanged": 0, "error": 0, "blocked": 0}
    details = []
    log("=" * 60)
    for in_path in files:
        rel = os.path.relpath(in_path, input_dir).replace("\\", "/")
        out_path = in_path if in_place else os.path.join(output_dir, rel)
        status, cols = process_file(in_path, out_path, rel, cfg, mapping, selection, in_place, header_rows)
        stats[status] += 1
        label = {"anonymized": "ממוסך", "copied": "הועתק", "unchanged": "ללא שינוי",
                 "error": "שגיאה", "blocked": "!! נחסם - נותר מידע אישי"}[status]
        log("[%s] %s" % (label, rel))
        details.append((rel, status, cols))
        for c in cols:
            log("        - %s" % c)
        if status == "blocked":
            log("        הקובץ לא נשמר בפלט. במסך בחירת השדות: לחיצה כפולה על שורת הגיליון "
                "קובעת את שורת הכותרת, ולחיצה כפולה על עמודה מסמנת אותה למיסוך.")

    core.save_mapping(mapping_path, mapping, salt, password)

    new_tokens = {}
    for logical, after in mapping["counters"].items():
        delta = after - counters_before.get(logical, 0)
        if delta:
            new_tokens[logical] = (delta, after)

    log("=" * 60)
    log("סיכום: מוסכו %d | הועתקו %d | ללא שינוי %d | שגיאות %d | נחסמו %d" %
        (stats["anonymized"], stats["copied"], stats["unchanged"], stats["error"], stats["blocked"]))
    if stats["blocked"]:
        log("!! אזהרה: קבצים שנחסמו לא נכתבו לפלט כי נותר בהם מידע אישי גלוי.")
    if new_tokens:
        log("אסימונים חדשים שנוצרו בריצה זו (לפי שדה לוגי):")
        for logical, (delta, after) in new_tokens.items():
            log("        %-10s +%d (סה\"כ %d)" % (logical, delta, after))
    log("קובץ המיפוי המוצפן: " + os.path.abspath(mapping_path))
    log("תיקיית הפלט הממוסך: " + os.path.abspath(input_dir if in_place else output_dir))
    return {"stats": stats, "new_tokens": new_tokens, "details": details}


def main():
    ap = argparse.ArgumentParser(description="מיסוך קובצי Excel (פסאודונימיזציה הפיכה).")
    ap.add_argument("input_dir", help="תיקיית הקלט (קבצים מקוריים)")
    ap.add_argument("output_dir", nargs="?", default=None,
                    help="תיקיית הפלט (קבצים ממוסכים); לא נדרש עם --in-place")
    ap.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "config.json"))
    ap.add_argument("--mapping", default=DEFAULT_MAPPING)
    ap.add_argument("--selection", default=None, help="selection.json - אילו עמודות למסך (חובה תמיד ממוסך)")
    ap.add_argument("--in-place", action="store_true",
                    help="מיסוך נוסף על התיקייה עצמה (קלט=פלט), לקבצים שכבר עברו מיסוך")
    args = ap.parse_args()

    if args.in_place:
        output_dir = args.input_dir
    else:
        if not args.output_dir:
            print("שגיאה: נדרשת תיקיית פלט (או --in-place).")
            sys.exit(1)
        if os.path.abspath(args.input_dir) == os.path.abspath(args.output_dir):
            print("שגיאה: תיקיית הקלט והפלט חייבות להיות שונות (למיסוך חוזר השתמש/י ב---in-place).")
            sys.exit(1)
        output_dir = args.output_dir

    try:
        run(args.input_dir, output_dir, args.config, args.mapping,
            selection_path=args.selection, in_place=args.in_place)
    except ValueError as e:
        print("שגיאה:", e)
        sys.exit(1)
    print("שמור/י על קובץ המיפוי ועל הסיסמה - בלעדיהם לא ניתן לשחזר את הנתונים.")


if __name__ == "__main__":
    main()
