# -*- coding: utf-8 -*-
"""
select_gui.py - כלי מיסוך מזהים: אפליקציה אחת לכל הזרימה.

מסך בית עם שלוש פעולות:
  1. מיסוך        - קבצים מקוריים (תיקייה 1) → קבצים ממוסכים (תיקייה 2)
  2. מיסוך נוסף   - על הקבצים הממוסכים עצמם (תיקייה 2, in-place)
  3. שחזור ממצאים - קובצי ממצאים עם אסימונים (תיקייה 3) → מזוהים (תיקייה 4)

הכל בסביבת עבודה אחת: תיקיית כלי-מיסוך-מזהים
שם ות"ז ממוסכים תמיד; כל השאר לבחירת המשתמש; כל אסימון ניתן לשחזור.

שימוש: python select_gui.py [--mode home|mask|remask|restore]
"""
import os
import sys
import glob
import json
import queue
import shutil
import argparse
import datetime
import textwrap
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# ייבוא מוגן: pandas / openpyxl / cryptography הן חבילות חיצוניות.
# בהרצה דרך pythonw אין קונסולה, ולכן בלי המלכודת הזו כשל ייבוא היה
# סוגר את הכלי בשקט מוחלט (חלון מהבהב ונסגר, בלי שום הודעה).
try:
    import core
    import anonymize
    import deanonymize
except Exception:
    import traceback
    _details = traceback.format_exc()
    _last = _details.strip().splitlines()[-1] if _details.strip() else ""
    _msg = (
        "הכלי לא הצליח לעלות כי חסרות חבילות פייתון נדרשות." "\n\n"
        "פתח שורת פקודה (cmd) והרץ:" "\n\n"
        "pip install pandas openpyxl xlrd cryptography" "\n\n"
        "ואז הפעל שוב את הפעלה.bat" "\n\n"
        "פירוט השגיאה:" "\n" + _last
    )
    try:
        _root = tk.Tk()
        _root.withdraw()
        messagebox.showerror("כלי מיסוך מזהים - חסרות חבילות פייתון", _msg)
        _root.destroy()
    except Exception:
        sys.stderr.write(_details)
    raise SystemExit(1)

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
SELECTION_PATH = os.path.join(TOOL_DIR, "selection.json")
CONFIG_PATH = os.path.join(TOOL_DIR, "config.json")
VERSION = getattr(core, "VERSION", "")

CHECKED, UNCHECKED, LOCKED = "☑", "☐", "\U0001F512"

# ----- צבעים וגופנים -----
BG = "#f1f5f9"
CARD = "#ffffff"
TEXT = "#0f172a"
MUTED = "#64748b"
BORDER = "#e2e8f0"
NAVY = "#1e3a5f"
BLUE = "#2563eb"
GREEN = "#16a34a"
ORANGE = "#d97706"
RED = "#dc2626"
PURPLE = "#7c3aed"
HOVER = {NAVY: "#17304f", BLUE: "#1d4ed8", GREEN: "#15803d", ORANGE: "#b45309",
         RED: "#b91c1c", PURPLE: "#6d28d9", CARD: "#eef2f7"}
SOFT = {NAVY: "#e8eef6", BLUE: "#e6efff", GREEN: "#e7f6ec", ORANGE: "#fdf1dd", RED: "#fdeaea", PURPLE: "#f0e9fe"}

FONT = "Arial"
F = (FONT, 11)
F_S = (FONT, 10)
F_XS = (FONT, 9)
F_B = (FONT, 11, "bold")
F_BIG = (FONT, 13, "bold")
F_TITLE = (FONT, 17, "bold")
F_HERO = (FONT, 22, "bold")
F_ICON = ("Segoe UI Emoji", 26)


RLE, PDF = "\u202b", "\u202c"


def R(text):
    """עוטף כל שורה בסימני כיווניות מימין לשמאל. בלי זה Tk מסדר טקסט מעורב
    (עברית עם אנגלית, ספרות ופיסוק) כאילו הפסקה משמאל לימין, והמילים מתהפכות."""
    return "\n".join(ln if (not ln or ln.startswith(RLE)) else RLE + ln + PDF for ln in str(text).split("\n"))


def wrap_text(text, chars):
    out = []
    for para in str(text).split("\n"):
        out.extend(textwrap.wrap(para, chars) or [""])
    return "\n".join(out)


def fix_rtl(widget):
    """עובר על כל התוויות והכפתורים בחלון ומחיל עליהם R(), כולל שבירת שורות ידנית."""
    for c in widget.winfo_children():
        if isinstance(c, (tk.Label, tk.Button, tk.Checkbutton)) and not str(c.cget("textvariable")):
            t = c.cget("text")
            if t and RLE not in t and any("\u0590" <= ch <= "\u05ff" for ch in t):
                try:
                    wl = int(float(str(c.cget("wraplength")) or 0))
                except Exception:
                    wl = 0
                if wl:
                    t = wrap_text(t, max(20, min(95, int(wl / 7.4))))
                    c.config(wraplength=0)
                c.config(text=R(t))
        fix_rtl(c)


def project_masked_dir():
    """תיקיית יעד לסנכרון אוטומטי של הקבצים הממוסכים (אופציונלי) - מוגדרת בקונפיג."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f).get("project_masked_dir")
    except Exception:
        return None


def open_folder(path):
    os.makedirs(path, exist_ok=True)
    try:
        os.startfile(path)
    except Exception:
        subprocess.Popen(["explorer", path])


def count_excel(folder):
    n = 0
    for ext in ("*.xlsx", "*.xls"):
        n += len([f for f in glob.glob(os.path.join(folder, "**", ext), recursive=True)
                  if not f.endswith(".tmp.xlsx") and not os.path.basename(f).startswith("~$")])
    return n


def button(parent, text, command, color=GREEN, big=False, **kw):
    """כפתור מלא בצבע, עם הדגשה במעבר עכבר."""
    hover = HOVER.get(color, color)
    b = tk.Button(parent, text=text, command=command, bg=color, fg="white",
                  activebackground=hover, activeforeground="white",
                  font=F_BIG if big else F_B, relief="flat", bd=0, cursor="hand2",
                  padx=20 if big else 14, pady=10 if big else 7, **kw)
    b.bind("<Enter>", lambda e: b.config(bg=hover))
    b.bind("<Leave>", lambda e: b.config(bg=color))
    return b


def ghost(parent, text, command, fg=TEXT, **kw):
    """כפתור משני: לבן עם מסגרת דקה."""
    b = tk.Button(parent, text=text, command=command, bg=CARD, fg=fg,
                  activebackground=HOVER[CARD], activeforeground=fg, font=F_S,
                  relief="flat", bd=0, cursor="hand2", padx=12, pady=6,
                  highlightthickness=1, highlightbackground=BORDER, **kw)
    b.bind("<Enter>", lambda e: b.config(bg=HOVER[CARD]))
    b.bind("<Leave>", lambda e: b.config(bg=CARD))
    return b


def big_button(parent, text, color, command, **kw):
    """תאימות לאחור."""
    return button(parent, text, command, color=color, big=True, **kw)


def card(parent, **kw):
    return tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=BORDER, **kw)


def top_bar(frame, title, color, on_back):
    head = tk.Frame(frame, bg=color)
    head.pack(fill="x")
    b = tk.Button(head, text="→  חזרה למסך הבית", command=on_back, bg=color, fg="white",
                  activebackground=HOVER.get(color, color), activeforeground="white",
                  font=F_S, relief="flat", bd=0, cursor="hand2", padx=12, pady=6)
    b.pack(side="left", padx=10, pady=10)
    tk.Label(head, text=title, bg=color, fg="white", font=F_TITLE, pady=12).pack(side="right", padx=18)
    return head


def sync_to_project(log):
    """מעתיק את כל הקבצים מתיקייה 2 (ממוסכים) לתיקיית היעד שהוגדרה בקונפיג, אם הוגדרה."""
    target = project_masked_dir()
    if not target:
        return
    os.makedirs(target, exist_ok=True)
    n = 0
    for f in glob.glob(os.path.join(core.DIR_MASKED, "**", "*.*"), recursive=True):
        if f.endswith(".tmp.xlsx"):
            continue
        rel = os.path.relpath(f, core.DIR_MASKED)
        dst = os.path.join(target, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(f, dst)
        n += 1
    if n:
        log("סונכרנו %d קבצים ממוסכים לתיקיית היעד: %s" % (n, target))


def center(win, root):
    win.update_idletasks()
    try:
        x = root.winfo_rootx() + (root.winfo_width() - win.winfo_width()) // 2
        y = root.winfo_rooty() + (root.winfo_height() - win.winfo_height()) // 3
        win.geometry("+%d+%d" % (max(x, 0), max(y, 0)))
    except Exception:
        pass


# ============================ דיאלוג סיסמה ============================

def ask_password(root, mapping_path):
    new_file = not os.path.exists(mapping_path)
    dlg = tk.Toplevel(root)
    dlg.title("סיסמת מפתח ההצפנה")
    dlg.configure(bg=CARD)
    dlg.transient(root)
    dlg.grab_set()
    dlg.resizable(False, False)

    tk.Frame(dlg, bg=NAVY, height=6).pack(fill="x")
    tk.Label(dlg, text="\U0001F511  " + ("בחירת סיסמה חדשה" if new_file else "הזנת הסיסמה"),
             bg=CARD, fg=NAVY, font=F_BIG, anchor="e").pack(fill="x", padx=22, pady=(16, 4))
    msg = ("זו הפעם הראשונה: בחר סיסמה למפתח ההצפנה, 6 תווים לפחות.\nמומלץ משפט של כמה מילים."
           if new_file else "הזן את הסיסמה שבחרת במיסוך הראשון.")
    tk.Label(dlg, text=msg, justify="right", anchor="e", bg=CARD, fg=TEXT, font=F).pack(fill="x", padx=22)

    def field(label):
        tk.Label(dlg, text=label, anchor="e", bg=CARD, fg=MUTED, font=F_S).pack(fill="x", padx=22, pady=(10, 2))
        e = tk.Entry(dlg, show="●", justify="right", font=F, width=38, relief="flat",
                     highlightthickness=1, highlightbackground=BORDER, highlightcolor=BLUE)
        e.pack(padx=22, ipady=5)
        return e

    p1 = field("סיסמה")
    p2 = field("אימות סיסמה") if new_file else None

    show = tk.BooleanVar(value=False)

    def toggle():
        ch = "" if show.get() else "●"
        p1.config(show=ch)
        if p2 is not None:
            p2.config(show=ch)

    tk.Checkbutton(dlg, text="הצג סיסמה", variable=show, command=toggle, bg=CARD, fg=MUTED,
                   activebackground=CARD, font=F_S, anchor="e").pack(fill="x", padx=18, pady=(6, 0))
    if new_file:
        tk.Label(dlg, text="אין דרך לשחזר סיסמה שנשכחה. בלי הסיסמה לא ניתן להחזיר את המזהים.",
                 bg=SOFT[ORANGE], fg="#7c4a03", font=F_S, anchor="e", justify="right",
                 padx=10, pady=7, wraplength=380).pack(fill="x", padx=22, pady=(10, 0))
    err = tk.Label(dlg, text="", bg=CARD, fg=RED, font=F_S, anchor="e")
    err.pack(fill="x", padx=22, pady=(6, 0))
    result = {"pw": None}

    def ok(*_):
        v1 = p1.get()
        if len(v1) < 6:
            err.config(text="הסיסמה קצרה מדי (לפחות 6 תווים).")
            return
        if p2 is not None and p2.get() != v1:
            err.config(text="שתי הסיסמאות אינן זהות.")
            return
        result["pw"] = v1
        dlg.destroy()

    row = tk.Frame(dlg, bg=CARD)
    row.pack(fill="x", padx=22, pady=16)
    button(row, "אישור", ok, color=GREEN).pack(side="right")
    ghost(row, "ביטול", dlg.destroy).pack(side="right", padx=8)
    dlg.bind("<Return>", ok)
    dlg.bind("<Escape>", lambda e: dlg.destroy())
    fix_rtl(dlg)
    center(dlg, root)
    p1.focus_set()
    root.wait_window(dlg)
    return result["pw"]


# ============================ חלון ריצה ============================

class LogWindow:
    """חלון ריצה: מקבל שורות מת'רד עבודה דרך תור (בטוח ל-Tkinter)."""

    def __init__(self, root, title):
        self.win = tk.Toplevel(root)
        self.win.title(title)
        self.win.geometry("820x520")
        self.win.configure(bg=BG)
        self.head = tk.Frame(self.win, bg=NAVY)
        self.head.pack(fill="x")
        self.head_lbl = tk.Label(self.head, text="⏳  " + title, bg=NAVY, fg="white", font=F_BIG, pady=12)
        self.head_lbl.pack()
        self.bar = ttk.Progressbar(self.win, mode="indeterminate")
        self.bar.pack(fill="x")
        self.bar.start(12)
        box = card(self.win)
        box.pack(fill="both", expand=True, padx=12, pady=12)
        self.txt = tk.Text(box, wrap="none", font=("Consolas", 10), bg=CARD, fg=TEXT,
                           relief="flat", padx=10, pady=8)
        vsb = ttk.Scrollbar(box, orient="vertical", command=self.txt.yview)
        self.txt.configure(yscrollcommand=vsb.set)
        vsb.pack(side="left", fill="y")
        self.txt.pack(side="right", fill="both", expand=True)
        self.txt.tag_configure("bad", foreground=RED)
        self.txt.tag_configure("good", foreground=GREEN)
        self.txt.tag_configure("rtl", justify="right")
        row = tk.Frame(self.win, bg=BG)
        row.pack(fill="x", padx=12, pady=(0, 12))
        self.btn = button(row, "פתח את תיקיית התוצאה", lambda: None, color=BLUE)
        ghost(row, "סגור", self.win.destroy).pack(side="left")
        self.queue = queue.Queue()
        self.done = False
        fix_rtl(self.win)
        center(self.win, root)
        self.win.after(100, self._poll)

    def log(self, line):
        self.queue.put(str(line))

    def finish(self, ok, open_path=None, warn=None):
        self.queue.put(("__DONE__", ok, open_path, warn))

    def _poll(self):
        try:
            while True:
                item = self.queue.get_nowait()
                if isinstance(item, tuple) and item[0] == "__DONE__":
                    _, ok, open_path, warn = item
                    color = RED if not ok else (ORANGE if warn else GREEN)
                    text = "✘  שגיאה" if not ok else (("⚠  " + warn) if warn else "✔  הושלם בהצלחה")
                    self.head.config(bg=color)
                    self.head_lbl.config(text=R(text), bg=color)
                    self.win.title("הושלם" if ok else "שגיאה")
                    self.bar.stop()
                    self.bar.pack_forget()
                    if open_path:
                        self.btn.config(command=lambda: open_folder(open_path))
                        self.btn.pack(side="right")
                    self.done = True
                else:
                    tag = "bad" if ("!!" in item or "שגיאה" in item or "נחסם" in item) else (
                        "good" if item.startswith("[ממוסך]") or item.startswith("[שוחזר]") else None)
                    self.txt.insert("end", R(item) + "\n", ("rtl", tag) if tag else ("rtl",))
                    self.txt.see("end")
        except queue.Empty:
            pass
        if not self.done:
            self.win.after(100, self._poll)


# ============================ מסך מיסוך (בחירת שדות) ============================

class MaskFrame(tk.Frame):
    METHOD_NOTE = {
        "alias": "זוהתה אוטומטית",
        "structure": "זוהתה לפי מבנה הטבלה",
        "manual": "נקבעה ידנית",
        "default": "לא זוהתה! יש לקבוע בתצוגה המקדימה",
    }
    PREVIEW_COLS = 14

    def __init__(self, app, remask=False):
        super().__init__(app.root, bg=BG)
        self.app = app
        self.remask = remask
        self.cfg = core.load_config(CONFIG_PATH)
        self.alias_map = self.cfg["_alias_map"]
        self.state = {}
        self.item_key = {}
        self.sheet_items = {}    # פריט בעץ -> (קובץ, גיליון)
        self.header_rows = None  # (קובץ, גיליון) -> אינדקס שורת כותרת שנקבע ידנית
        self.inventory = {}
        self.current = None      # (קובץ, גיליון) שמוצג בתצוגה המקדימה

        color = ORANGE if remask else NAVY
        top_bar(self, "מיסוך נוסף - על קבצים שכבר עברו מיסוך" if remask else "מיסוך - בחירת העמודות",
                color, app.show_home)

        # --- תיקייה ---
        top = card(self)
        top.pack(fill="x", padx=14, pady=(12, 6))
        default_dir = core.DIR_MASKED if remask else core.DIR_RAW
        self.dir_var = tk.StringVar(value=default_dir)
        tk.Label(top, text="התיקייה הממוסכת (2)" if remask else "תיקיית הקבצים המקוריים (1)",
                 bg=CARD, fg=MUTED, font=F_S).pack(side="right", padx=(8, 12), pady=8)
        ghost(top, "פתח תיקייה", lambda: open_folder(self.dir_var.get())).pack(side="left", padx=(10, 4), pady=8)
        ghost(top, "בחר תיקייה אחרת", self.browse).pack(side="left", padx=4)
        ghost(top, "⟳ סרוק מחדש", self.rescan).pack(side="left", padx=4)
        tk.Entry(top, textvariable=self.dir_var, justify="right", font=F_S, relief="flat",
                 bg=CARD, fg=TEXT, readonlybackground=CARD, state="readonly").pack(
            side="left", fill="x", expand=True, padx=8)

        # --- מקרא ---
        legend = tk.Frame(self, bg=BG)
        legend.pack(fill="x", padx=14)
        for txt, fg, bg in [("\U0001F512 שם / ת\"ז: ממוסך תמיד", "#991b1b", SOFT[RED]),
                            ("☑ ימוסך (הפיך, ניתן לשחזור)", "#166534", SOFT[GREEN]),
                            ("☐ יישאר גלוי", TEXT, CARD),
                            ("לחיצה כפולה על עמודה משנה את הסימון", MUTED, BG)]:
            tk.Label(legend, text=txt, bg=bg, fg=fg, font=F_S, padx=10, pady=4).pack(side="right", padx=3, pady=4)

        # --- פעולות ---
        bottom = tk.Frame(self, bg=BG)
        bottom.pack(side="bottom", fill="x", padx=14, pady=(6, 10))
        button(bottom, "▶  התחל מיסוך", self.start, color=GREEN, big=True).pack(side="left")
        ghost(bottom, "סמן את כל השדות המוכרים", self.select_known).pack(side="right", padx=(4, 0))
        ghost(bottom, "נקה סימונים", self.clear_all).pack(side="right", padx=4)

        self.status_var = tk.StringVar(value="")
        self.status_lbl = tk.Label(self, textvariable=self.status_var, anchor="e", justify="right",
                                   bg=BG, fg=MUTED, font=F_S, padx=14, pady=6)
        self.status_lbl.pack(side="bottom", fill="x")
        # --- עץ העמודות + תצוגה מקדימה ---
        panes = tk.PanedWindow(self, orient="vertical", bg=BG, sashwidth=8, bd=0, relief="flat")
        panes.pack(fill="both", expand=True, padx=14, pady=4)

        mid = card(panes)
        self.tree = ttk.Treeview(mid, columns=("status",), show="tree headings", style="Mask.Treeview")
        self.tree.heading("#0", text="קובץ / גיליון / עמודה", anchor="e")
        self.tree.heading("status", text="סיווג", anchor="e")
        self.tree.column("#0", width=600, anchor="w")
        self.tree.column("status", width=250, anchor="e")
        vsb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="left", fill="y")
        self.tree.pack(side="right", fill="both", expand=True)
        self.tree.tag_configure("file", background="#dbe7f5", foreground=NAVY, font=F_B)
        self.tree.tag_configure("sheet", background="#f1f5f9", foreground=TEXT)
        self.tree.tag_configure("sheetwarn", background="#fee2e2", foreground="#991b1b", font=F_B)
        self.tree.tag_configure("mandatory", foreground="#991b1b", background=SOFT[RED])
        self.tree.tag_configure("on", foreground="#166534", background=SOFT[GREEN])
        self.tree.tag_configure("off", foreground=TEXT)
        self.tree.bind("<Double-1>", self.on_toggle)
        self.tree.bind("<space>", self.on_toggle)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        panes.add(mid, minsize=150, stretch="always")

        pv = card(panes)
        bar = tk.Frame(pv, bg=CARD)
        bar.pack(fill="x", padx=10, pady=(8, 4))
        self.pv_title = tk.Label(bar, text="תצוגה מקדימה", bg=CARD, fg=NAVY, font=F_B, anchor="e")
        self.pv_title.pack(side="right")
        ghost(bar, "זיהוי אוטומטי", self.header_auto).pack(side="left", padx=(0, 4))
        button(bar, "קבע לכל הקבצים", self.header_apply_all, color=PURPLE).pack(side="left", padx=4)
        button(bar, "קבע לגיליון הזה", self.header_apply, color=BLUE).pack(side="left", padx=4)
        self.hr_var = tk.StringVar(value="1")
        tk.Spinbox(bar, from_=1, to=100000, textvariable=self.hr_var, width=6, font=F_B,
                   justify="center", relief="flat", highlightthickness=1,
                   highlightbackground=BORDER).pack(side="left", padx=6, ipady=3)
        tk.Label(bar, text="שורת הכותרת:", bg=CARD, fg=TEXT, font=F_B).pack(side="left")
        tk.Label(pv, text="השורה הצבועה היא שורת הכותרת. לחיצה על שורה אחרת בוחרת אותה, ואז \"קבע\".",
                 bg=CARD, fg=MUTED, font=F_XS, anchor="e").pack(fill="x", padx=10)
        pbox = tk.Frame(pv, bg=CARD)
        pbox.pack(fill="both", expand=True, padx=10, pady=(4, 10))
        self.pv = ttk.Treeview(pbox, show="headings", style="Prev.Treeview", height=6, selectmode="browse")
        hsb = ttk.Scrollbar(pbox, orient="horizontal", command=self.pv.xview)
        pvsb = ttk.Scrollbar(pbox, orient="vertical", command=self.pv.yview)
        self.pv.configure(xscrollcommand=hsb.set, yscrollcommand=pvsb.set)
        hsb.pack(side="bottom", fill="x")
        pvsb.pack(side="left", fill="y")
        self.pv.pack(side="right", fill="both", expand=True)
        self.pv.tag_configure("hdr", background="#fde68a", foreground="#78350f", font=F_B)
        self.pv.tag_configure("above", foreground="#94a3b8")
        self.pv.tag_configure("data", foreground=TEXT)
        self.pv.bind("<<TreeviewSelect>>", self.on_preview_pick)
        panes.add(pv, minsize=170, stretch="never")

        self.rescan()

    # ---------- סיווג ----------
    def classify(self, header):
        field = self.alias_map.get(core.normalize_header(header))
        if field is None:
            return "other", None
        if field.get("mandatory"):
            return "mandatory", field
        return "known", field

    def browse(self):
        d = filedialog.askdirectory(initialdir=self.dir_var.get() or os.path.expanduser("~"))
        if d:
            self.dir_var.set(d)
            self.rescan()

    # ---------- סריקה ----------
    def rescan(self, keep_state=False):
        folder = self.dir_var.get()
        old_state = dict(self.state) if keep_state else {}
        self.tree.delete(*self.tree.get_children())
        self.item_key.clear()
        self.sheet_items.clear()
        self.state.clear()
        self.inventory = {}
        if not os.path.isdir(folder):
            self.set_status("התיקייה לא נמצאה: " + folder, RED)
            return
        self.set_status("סורק כותרות...", MUTED)
        self.update_idletasks()
        prev = self.load_previous_selection()
        if self.header_rows is None:
            self.header_rows = self.load_previous_header_rows()
        files = []
        for ext in ("*.xlsx", "*.xls"):
            files.extend(glob.glob(os.path.join(folder, "**", ext), recursive=True))
        for f in sorted(set(files)):
            if f.endswith(".tmp.xlsx") or os.path.basename(f).startswith("~$"):
                continue
            rel = os.path.relpath(f, folder).replace("\\", "/")
            overrides = {sh: r for (rl, sh), r in self.header_rows.items() if rl == rel}
            try:
                self.inventory[rel] = core.scan_headers(f, self.alias_map, overrides)
            except Exception as e:
                self.inventory[rel] = {"<שגיאת קריאה>": {"header_row": 0, "headers": [str(e)],
                                                         "method": "manual", "suspect": [], "top": []}}
        n_cols, n_undetected, n_suspect = 0, 0, 0
        first_sheet, first_warn = None, None
        for rel, sheets in self.inventory.items():
            f_id = self.tree.insert("", "end", text=R("📄 " + rel), open=True, tags=("file",))
            for sheet, info in sheets.items():
                headers = info["headers"]
                method = info.get("method", "alias")
                if method == "default" and not headers:
                    note, tag = "  ·  גיליון ריק", "sheet"
                else:
                    note = "  ·  כותרות בשורה %d (%s)" % (info["header_row"] + 1, self.METHOD_NOTE[method])
                    tag = "sheetwarn" if method == "default" else "sheet"
                    n_undetected += 1 if method == "default" else 0
                s_id = self.tree.insert(f_id, "end", text=R("גיליון: " + str(sheet) + note),
                                        open=True, tags=(tag,))
                self.sheet_items[s_id] = (rel, str(sheet))
                first_sheet = first_sheet or s_id
                if tag == "sheetwarn":
                    first_warn = first_warn or s_id
                for h in headers:
                    kind, field = self.classify(h)
                    key = (rel, str(sheet), core.normalize_header(h))
                    if kind == "mandatory":
                        self.tree.insert(s_id, "end", text=R("%s %s" % (LOCKED, h)),
                                         values=(R("חובה: שם / ת\"ז"),), tags=("mandatory",))
                    else:
                        is_suspect = h in info.get("suspect", [])
                        checked = old_state.get(key, prev.get(key, False) or is_suspect)
                        self.state[key] = checked
                        if is_suspect:
                            status = "נראה כמו ת\"ז, סומן אוטומטית"
                            n_suspect += 1
                        else:
                            status = "מוכר (%s)" % field["logical"] if kind == "known" else "עמודה חופשית"
                        item = self.tree.insert(s_id, "end", text=R("%s %s" % (CHECKED if checked else UNCHECKED, h)),
                                                values=(R(status),), tags=("on" if checked else "off",))
                        self.item_key[item] = key
                    n_cols += 1
        if not self.inventory:
            self.set_status("לא נמצאו קובצי Excel בתיקייה. שים בה קבצים ולחץ \"סרוק מחדש\".", ORANGE)
            self.show_preview(None)
            return
        if n_undetected:
            self.set_status("ב-%d גיליונות שורת הכותרת לא זוהתה (מסומנים באדום). "
                            "בחר את הגיליון וקבע את שורת הכותרת בתצוגה המקדימה." % n_undetected, RED)
        elif n_suspect:
            self.set_status("נמצאו %d קבצים ו-%d עמודות. %d עמודות שנראות כמו ת\"ז סומנו אוטומטית." % (
                len(self.inventory), n_cols, n_suspect), GREEN)
        else:
            self.set_status("נמצאו %d קבצים ו-%d עמודות." % (len(self.inventory), n_cols), MUTED)
        # לשמור על הגיליון שהוצג, או לקפוץ לראשון שדורש טיפול
        target = None
        if self.current:
            target = next((i for i, k in self.sheet_items.items() if k == self.current), None)
        target = target or first_warn or first_sheet
        if target:
            self.tree.selection_set(target)
            self.tree.see(target)
            self.show_preview(self.sheet_items[target])

    def set_status(self, text, color=MUTED):
        self.status_var.set(R(text))
        self.status_lbl.config(fg=color)

    def load_previous_selection(self):
        if not os.path.exists(SELECTION_PATH):
            return {}
        try:
            with open(SELECTION_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            prev = {}
            for rel, sheets in data.get("selected", {}).items():
                for sheet, headers in sheets.items():
                    for h in headers:
                        prev[(rel, sheet, h)] = True
            return prev
        except Exception:
            return {}

    def load_previous_header_rows(self):
        try:
            with open(SELECTION_PATH, "r", encoding="utf-8") as f:
                data = json.load(f).get("header_rows", {}) or {}
            return {(rel, sh): int(r) for rel, d in data.items() for sh, r in d.items()}
        except Exception:
            return {}

    # ---------- תצוגה מקדימה ושורת כותרת ----------
    @staticmethod
    def col_letter(j):
        s = ""
        j += 1
        while j:
            j, r = divmod(j - 1, 26)
            s = chr(65 + r) + s
        return s

    @staticmethod
    def fmt(v):
        if core.is_blank(v):
            return ""
        if isinstance(v, datetime.datetime):
            return v.strftime("%d/%m/%Y")
        if isinstance(v, float) and v.is_integer():
            return str(int(v))
        s = str(v)
        return s if len(s) <= 40 else s[:38] + "…"

    def sheet_of(self, item):
        while item and item not in self.sheet_items:
            kids = self.tree.get_children(item) if not self.tree.parent(item) else ()
            item = kids[0] if kids else self.tree.parent(item)
        return self.sheet_items.get(item)

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if sel:
            key = self.sheet_of(sel[0])
            if key and key != self.current:
                self.show_preview(key)

    def show_preview(self, key):
        self.current = key
        self.pv.delete(*self.pv.get_children())
        if not key:
            self.pv["columns"] = ()
            self.pv_title.config(text="תצוגה מקדימה")
            return
        rel, sheet = key
        info = self.inventory.get(rel, {}).get(sheet) or next(
            (i for s, i in self.inventory.get(rel, {}).items() if str(s) == sheet), None)
        if not info:
            return
        top = info.get("top", [])
        hr = info["header_row"]
        width = min(max([len(r) for r in top] + [1]), self.PREVIEW_COLS)
        # גיליון מימין לשמאל: עמודה A הכי ימנית, ומספר השורה מימין לה
        cols = [self.col_letter(j) for j in reversed(range(width))] + ["row"]
        self.pv["columns"] = cols
        for c in cols[:-1]:
            self.pv.heading(c, text=c, anchor="center")
            self.pv.column(c, width=120, minwidth=60, anchor="e", stretch=True)
        self.pv.heading("row", text="שורה", anchor="center")
        self.pv.column("row", width=56, minwidth=56, anchor="center", stretch=False)
        for i, r in enumerate(top):
            vals = [self.fmt(r[j]) if j < len(r) else "" for j in reversed(range(width))] + [i + 1]
            tag = "hdr" if i == hr else ("above" if i < hr else "data")
            self.pv.insert("", "end", iid="r%d" % i, values=vals, tags=(tag,))
        self.hr_var.set(str(hr + 1))
        self.pv_title.config(text=R("תצוגה מקדימה: %s  ·  %s" % (rel, sheet)))

    def on_preview_pick(self, _event=None):
        sel = self.pv.selection()
        if sel:
            self.hr_var.set(str(int(sel[0][1:]) + 1))

    def _hr_value(self):
        try:
            n = int(self.hr_var.get())
            return n if n >= 1 else None
        except ValueError:
            return None

    def header_apply(self):
        n = self._hr_value()
        if not self.current or n is None:
            return
        self.header_rows[self.current] = n - 1
        self.rescan(keep_state=True)

    def header_apply_all(self):
        n = self._hr_value()
        if n is None:
            return
        for key in list(self.sheet_items.values()):
            self.header_rows[key] = n - 1
        self.rescan(keep_state=True)

    def header_auto(self):
        if self.current:
            self.header_rows.pop(self.current, None)
            self.rescan(keep_state=True)

    # ---------- סימון ----------
    def refresh_item(self, item):
        key = self.item_key.get(item)
        if key is None:
            return
        on = self.state.get(key, False)
        self.tree.item(item, text=R("%s %s" % (CHECKED if on else UNCHECKED, key[2])),
                       tags=("on" if on else "off",))

    def on_toggle(self, event):
        item = self.tree.focus()
        if getattr(event, "y", None) is not None and event.type == tk.EventType.ButtonPress:
            item = self.tree.identify_row(event.y) or item
        key = self.item_key.get(item)
        if key is None:
            return
        new_val = not self.state.get(key, False)
        header = key[2]
        for it, k in self.item_key.items():
            if k[2] == header:
                self.state[k] = new_val
                self.refresh_item(it)
        return "break"

    def select_known(self):
        for it, key in self.item_key.items():
            if self.classify(key[2])[0] == "known":
                self.state[key] = True
                self.refresh_item(it)

    def clear_all(self):
        for it, key in self.item_key.items():
            self.state[key] = False
            self.refresh_item(it)

    # ---------- הרצה ----------
    def build_selection(self):
        selected = {}
        for (rel, sheet, header), on in self.state.items():
            if on:
                selected.setdefault(rel, {}).setdefault(sheet, []).append(header)
        header_rows = {}
        for (rel, sheet), r in (self.header_rows or {}).items():
            header_rows.setdefault(rel, {})[sheet] = r
        return {"version": 1, "selected": selected, "header_rows": header_rows}

    def undetected(self):
        return [(rel, sh) for rel, sheets in self.inventory.items() for sh, info in sheets.items()
                if info.get("method") == "default" and info.get("headers")]

    def start(self):
        folder = self.dir_var.get()
        if not os.path.isdir(folder):
            messagebox.showerror("שגיאה", "התיקייה לא נמצאה:\n" + folder)
            return
        if not self.inventory:
            messagebox.showinfo("מיסוך", "אין קובצי Excel בתיקייה.")
            return
        bad = self.undetected()
        if bad and not messagebox.askyesno(
                "שורת כותרת לא זוהתה",
                "ב-%d גיליונות שורת הכותרת לא זוהתה:\n\n%s\n\n"
                "קובץ שיישאר בו מספר זהות גלוי ייחסם ולא ייכתב לתיקייה 2.\nלהמשיך בכל זאת?" % (
                    len(bad), "\n".join("• %s / %s" % b for b in bad[:6]))):
            return
        with open(SELECTION_PATH, "w", encoding="utf-8") as f:
            json.dump(self.build_selection(), f, ensure_ascii=False, indent=1)

        pw = ask_password(self.app.root, core.MAPPING_PATH)
        if not pw:
            return
        out_dir = folder if self.remask else core.DIR_MASKED
        lw = LogWindow(self.app.root, "מריץ מיסוך נוסף..." if self.remask else "מריץ מיסוך...")

        def work():
            try:
                res = anonymize.run(folder, out_dir, CONFIG_PATH, core.MAPPING_PATH,
                                    selection_path=SELECTION_PATH, in_place=self.remask,
                                    password=pw, log=lw.log)
                sync_to_project(lw.log)
                stats = res.get("stats", {})
                warn = None
                if stats.get("blocked"):
                    warn = "הושלם, אבל %d קבצים נחסמו ולא נכתבו" % stats["blocked"]
                elif stats.get("error"):
                    warn = "הושלם, אבל %d קבצים לא נקראו" % stats["error"]
                lw.finish(True, open_path=core.DIR_MASKED, warn=warn)
            except ValueError as e:
                lw.log("שגיאה: %s" % e)
                lw.finish(False)
            except Exception as e:
                lw.log("שגיאה בלתי צפויה: %s" % e)
                lw.finish(False)

        threading.Thread(target=work, daemon=True).start()


# ============================ מסך שחזור ============================

class RestoreFrame(tk.Frame):
    def __init__(self, app):
        super().__init__(app.root, bg=BG)
        self.app = app
        top_bar(self, "שחזור ממצאים - זיהוי חזרה", GREEN, app.show_home)

        tk.Label(self, bg=SOFT[GREEN], fg="#14532d", font=F, justify="right", anchor="e",
                 padx=14, pady=10, text=(
                     "שים את קובצי הממצאים (עם אסימונים כמו ID-000123) בתיקייה 3 ולחץ \"שחזר\".\n"
                     "הקבצים עם השמות ומספרי הזהות האמיתיים ייווצרו בתיקייה 4, לשימוש מקומי בלבד.")
                 ).pack(fill="x", padx=14, pady=(12, 6))

        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", padx=14, pady=4)
        ghost(row, "פתח את תיקייה 3 (ממצאים)", lambda: open_folder(core.DIR_FINDINGS)).pack(side="right")
        ghost(row, "⟳ רענן רשימה", self.refresh).pack(side="right", padx=6)

        box = card(self)
        box.pack(fill="both", expand=True, padx=14, pady=6)
        self.listbox = tk.Listbox(box, font=F, justify="right", bg=CARD, fg=TEXT, relief="flat",
                                  highlightthickness=0, selectbackground=SOFT[GREEN],
                                  selectforeground=TEXT, activestyle="none")
        self.listbox.pack(fill="both", expand=True, padx=10, pady=10)

        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill="x", padx=14, pady=(6, 4))
        button(bottom, "\U0001F513  שחזר את כל הקבצים", self.restore, color=GREEN, big=True).pack(side="left")
        self.status_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self.status_var, anchor="e", bg=BG, fg=MUTED, font=F_S,
                 padx=14, pady=6).pack(fill="x")
        self.refresh()

    def files(self):
        return sorted(f for f in glob.glob(os.path.join(core.DIR_FINDINGS, "**", "*.xlsx"), recursive=True)
                      if not os.path.basename(f).startswith("~$"))

    def refresh(self):
        self.listbox.delete(0, "end")
        fs = self.files()
        for f in fs:
            self.listbox.insert("end", R("📄  " + os.path.relpath(f, core.DIR_FINDINGS)))
        self.status_var.set(R("%d קבצים ממתינים לשחזור בתיקייה 3." % len(fs) if fs
                              else "תיקייה 3 ריקה. שים בה את קובצי הממצאים (xlsx) ולחץ \"רענן רשימה\"."))

    def restore(self):
        fs = self.files()
        if not fs:
            messagebox.showinfo("שחזור", "אין קבצים בתיקייה 3.")
            return
        if not os.path.exists(core.MAPPING_PATH):
            messagebox.showerror("שגיאה", "קובץ המפתח לא נמצא בתיקיית המערכת.\n"
                                          "שחזור אפשרי רק במחשב ובתיקייה שבהם בוצע המיסוך.")
            return
        pw = ask_password(self.app.root, core.MAPPING_PATH)
        if not pw:
            return
        lw = LogWindow(self.app.root, "משחזר ממצאים...")

        def work():
            try:
                cfg = core.load_config(CONFIG_PATH)
                mapping, _ = core.load_mapping(core.MAPPING_PATH, pw)
                reverse = core.build_reverse(mapping)
                token_re = deanonymize.build_token_regex(cfg)
                total = 0
                for f in fs:
                    rel = os.path.relpath(f, core.DIR_FINDINGS)
                    out = os.path.join(core.DIR_RESTORED, rel)
                    cnt = deanonymize.process_file(f, out, reverse, token_re)
                    total += cnt
                    lw.log("[שוחזר] %s  (%d אסימונים)" % (rel, cnt))
                lw.log("=" * 60)
                lw.log("סה\"כ אסימונים ששוחזרו: %d" % total)
                lw.log("תיקיית הפלט המזוהה (מקומי בלבד): " + core.DIR_RESTORED)
                lw.finish(True, open_path=core.DIR_RESTORED,
                          warn=None if total else "לא נמצאו אסימונים בקבצים")
            except ValueError as e:
                lw.log("שגיאה: %s" % e)
                lw.finish(False)
            except Exception as e:
                lw.log("שגיאה בלתי צפויה: %s" % e)
                lw.finish(False)

        threading.Thread(target=work, daemon=True).start()


# ============================ מסך הבית ============================

class HomeFrame(tk.Frame):
    def __init__(self, app, notes):
        super().__init__(app.root, bg=BG)

        # --- כותרת ---
        hero = tk.Frame(self, bg=NAVY)
        hero.pack(fill="x")
        logo_path = os.path.join(TOOL_DIR, "logo.png")
        if os.path.exists(logo_path):
            try:
                self._logo_img = tk.PhotoImage(file=logo_path)
                chip = tk.Frame(hero, bg="white")
                chip.pack(side="left", padx=18, pady=16)
                tk.Label(chip, image=self._logo_img, bg="white").pack(padx=10, pady=6)
            except Exception:
                pass
        titles = tk.Frame(hero, bg=NAVY)
        titles.pack(side="right", padx=22, pady=14)
        tk.Label(titles, text="\U0001F6E1  כלי מיסוך מזהים" + (" - " + core.CLIENT if core.CLIENT else ""),
                 bg=NAVY, fg="white", font=F_HERO, anchor="e").pack(fill="x")
        tk.Label(titles, text="פסאודונימיזציה הפיכה של קובצי Excel, עם שחזור מלא בסיסמה",
                 bg=NAVY, fg="#bfd3ea", font=F, anchor="e").pack(fill="x", pady=(2, 0))

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=22, pady=16)

        # --- שלוש הפעולות ---
        grid = tk.Frame(body, bg=BG)
        grid.pack(fill="x")
        actions = [
            ("\U0001F512", "מיסוך", "מחליף שמות, מספרי זהות ועמודות שתבחר באסימונים. "
                                    "מתיקייה 1 לתיקייה 2.", NAVY, "התחל מיסוך", app.show_mask),
            ("➕", "מיסוך נוסף", "נזכרת בעוד עמודה? ממסך אותה ישירות על הקבצים שכבר "
                                 "בתיקייה 2.", ORANGE, "מיסוך נוסף", app.show_remask),
            ("\U0001F513", "שחזור ממצאים", "מחזיר את המזהים האמיתיים לקובצי הממצאים. "
                                           "מתיקייה 3 לתיקייה 4.", GREEN, "שחזר ממצאים", app.show_restore),
        ]
        for i, (icon, title, desc, color, btn, cmd) in enumerate(actions):
            c = card(grid)
            c.grid(row=0, column=2 - i, sticky="nsew", padx=6)      # הראשון מימין
            grid.columnconfigure(2 - i, weight=1, uniform="a")
            tk.Frame(c, bg=color, height=6).pack(fill="x")
            head = tk.Frame(c, bg=CARD)
            head.pack(fill="x", padx=16, pady=(14, 4))
            tk.Label(head, text=icon, bg=SOFT[color], fg=color, font=F_ICON, width=3).pack(side="right")
            tk.Label(head, text=title, bg=CARD, fg=TEXT, font=F_TITLE, anchor="e").pack(
                side="right", padx=12)
            tk.Label(c, text=desc, bg=CARD, fg=MUTED, font=F_S, anchor="e", justify="right",
                     wraplength=250, height=3).pack(fill="x", padx=16)
            button(c, btn, cmd, color=color, big=True).pack(fill="x", padx=16, pady=(8, 16))

        # --- איך זה עובד ---
        flow = card(body)
        flow.pack(fill="x", padx=6, pady=(16, 0))
        steps = [("קובץ מקורי", RED), ("מיסוך", NAVY), ("שיתוף וניתוח של הקובץ הממוסך", GREEN),
                 ("קובץ ממצאים עם אסימונים", BLUE), ("שחזור: רואים למי שייך כל ממצא", GREEN)]
        inner = tk.Frame(flow, bg=CARD)
        inner.pack(pady=10)
        for i, (txt, color) in enumerate(steps):
            if i:
                tk.Label(inner, text="←", bg=CARD, fg=MUTED, font=F_BIG).pack(side="right", padx=4)
            tk.Label(inner, text=txt, bg=SOFT[color], fg=TEXT, font=F_S, padx=10, pady=5).pack(side="right", padx=2)

        # --- תיקיות העבודה ---
        tk.Label(body, text="תיקיות העבודה", bg=BG, fg=NAVY, font=F_BIG, anchor="e").pack(
            fill="x", pady=(18, 6), padx=6)
        frow = tk.Frame(body, bg=BG)
        frow.pack(fill="x")
        folders = [
            ("1", "קבצים מקוריים", "לא להעלות", core.DIR_RAW, RED),
            ("2", "קבצים ממוסכים", "לשיתוף ולניתוח", core.DIR_MASKED, GREEN),
            ("3", "ממצאים לשחזור", "שמים כאן", core.DIR_FINDINGS, BLUE),
            ("4", "ממצאים משוחזרים", "לא להעלות", core.DIR_RESTORED, RED),
        ]
        for i, (num, name, hint, path, color) in enumerate(folders):
            c = card(frow, cursor="hand2")
            c.grid(row=0, column=3 - i, sticky="nsew", padx=6)
            frow.columnconfigure(3 - i, weight=1, uniform="f")
            n = count_excel(path)
            w = [c,
                 tk.Label(c, text=num, bg=color, fg="white", font=F_BIG, width=3, pady=10),
                 None, None, None]
            w[1].pack(side="right", fill="y")
            inner = tk.Frame(c, bg=CARD)
            inner.pack(side="right", fill="both", expand=True, padx=10, pady=8)
            w[2] = tk.Label(inner, text=name, bg=CARD, fg=TEXT, font=F_B, anchor="e")
            w[2].pack(fill="x")
            w[3] = tk.Label(inner, text="%s  ·  %d קבצים" % (hint, n), bg=CARD, fg=color, font=F_XS, anchor="e")
            w[3].pack(fill="x")
            w[4] = inner
            for x in w:
                x.bind("<Button-1>", lambda e, p=path: open_folder(p))

        # --- הבהרת ציות ---
        legal = ("הפלט פסאודונימי, לא אנונימי. כל עוד קובץ המפתח קיים ניתן לזהות חזרה, "
                 "ולכן הקבצים הממוסכים נשארים מידע אישי לעניין חוק הגנת הפרטיות, "
                 "ואין להתייחס אליהם כאל מידע אנונימי." "\n"
                 "החריג היחיד: תאריך לידה או פטירה מוכלל לשנה בלבד, וזה בלתי הפיך.")
        tk.Label(body, text=legal, bg=SOFT[ORANGE], fg="#7c4a03", font=F_XS, anchor="e", justify="right",
                 padx=12, pady=9, wraplength=930).pack(fill="x", pady=(16, 4), padx=6)

        for n in notes:
            tk.Label(body, text=n, bg=SOFT[BLUE], fg="#1e3a8a", font=F_S, anchor="e",
                     padx=12, pady=7).pack(fill="x", pady=3, padx=6)

        foot = tk.Frame(self, bg=BG)
        foot.pack(fill="x", side="bottom", padx=28, pady=(0, 10))
        tk.Label(foot, text="Excel בלבד (xlsx, xls)  ·  הכל רץ מקומית, שום נתון לא נשלח לרשת",
                 bg=BG, fg=MUTED, font=F_XS).pack(side="right")
        tk.Label(foot, text=("גרסה " + VERSION) if VERSION else "", bg=BG, fg=MUTED, font=F_XS).pack(side="left")
        help_path = os.path.join(TOOL_DIR, "הוראות-שימוש.html")
        if os.path.exists(help_path):
            lnk = tk.Label(foot, text="הוראות שימוש", bg=BG, fg=BLUE, font=(FONT, 9, "underline"), cursor="hand2")
            lnk.pack(side="left", padx=14)
            lnk.bind("<Button-1>", lambda e: os.startfile(help_path))


# ============================ האפליקציה ============================

def apply_style(root):
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("Treeview", font=F, rowheight=28, background=CARD, fieldbackground=CARD,
                    foreground=TEXT, bordercolor=BORDER, borderwidth=0)
    style.configure("Treeview.Heading", font=F_B, background="#e2e8f0", foreground=NAVY,
                    relief="flat", padding=6)
    style.map("Treeview", background=[("selected", "#bfdbfe")], foreground=[("selected", TEXT)])
    style.configure("Mask.Treeview", font=F, rowheight=28)
    style.configure("Prev.Treeview", font=F_S, rowheight=24)
    style.configure("Prev.Treeview.Heading", font=F_XS, background="#e2e8f0", foreground=MUTED, padding=3)
    style.configure("TProgressbar", background=BLUE, troughcolor=BORDER, borderwidth=0)
    root.option_add("*Font", F)


class App:
    def __init__(self, root, start_mode="home"):
        self.root = root
        root.title("כלי מיסוך מזהים" + (" - " + core.CLIENT if core.CLIENT else ""))
        root.geometry("1040x780")
        root.minsize(940, 680)
        root.configure(bg=BG)
        self.notes = core.ensure_workspace()
        self.current = None
        {"home": self.show_home, "mask": self.show_mask,
         "remask": self.show_remask, "restore": self.show_restore}.get(start_mode, self.show_home)()

    def _swap(self, frame):
        if self.current is not None:
            self.current.destroy()
        self.current = frame
        fix_rtl(frame)
        frame.pack(fill="both", expand=True)

    def show_home(self):
        self._swap(HomeFrame(self, self.notes))

    def show_mask(self):
        self._swap(MaskFrame(self, remask=False))

    def show_remask(self):
        self._swap(MaskFrame(self, remask=True))

    def show_restore(self):
        self._swap(RestoreFrame(self))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="home", choices=["home", "mask", "remask", "restore"])
    ap.add_argument("--in-place", action="store_true", help="(תאימות לאחור) שקול ל---mode remask")
    args = ap.parse_args()
    mode = "remask" if args.in_place else args.mode
    root = tk.Tk()
    apply_style(root)
    App(root, start_mode=mode)
    root.mainloop()


if __name__ == "__main__":
    main()
