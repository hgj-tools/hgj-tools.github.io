# -*- coding: utf-8 -*-
"""
server.py - הממשק של כלי מיסוך מזהים, גרסה 2: המסכים מוצגים בדפדפן, והכל רץ במחשב הזה בלבד.

איך זה עובד:
- שרת קטן נפתח על 127.0.0.1 בלבד (לא נגיש ממחשב אחר), בפורט פנוי אקראי.
- הדפדפן נפתח על הכתובת המקומית ומציג את ui/index.html.
- כל בקשה לשרת חייבת לשאת אסימון אקראי שנוצר בהפעלה, וכותרת Host מקומית. כך אתר אחר
  שפתוח בדפדפן אינו יכול לפנות לכלי.
- אין שום פנייה לאינטרנט: הגופנים והעיצוב ארוזים בתוך index.html.
- הכלי נשאר פתוח כל עוד הלשונית פתוחה, גם כשהיא ברקע. כשסוגרים אותה, הוא נסגר לבד.

אם השרת לא מצליח לעלות, נפתח הממשק הקלאסי (select_gui.py).
"""
import os
import sys
import glob
import json
import time
import secrets
import datetime
import threading
import subprocess
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import core
import anonymize
import deanonymize

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
UI_PATH = os.path.join(TOOL_DIR, "ui", "index.html")
CONFIG_PATH = os.path.join(TOOL_DIR, "config.json")
SELECTION_PATH = os.path.join(TOOL_DIR, "selection.json")
LOCK_PATH = os.path.join(TOOL_DIR, "server.lock")
HELP_PATH = os.path.join(TOOL_DIR, "הוראות-שימוש.html")

TOKEN = secrets.token_urlsafe(24)
# מתי הכלי נסגר:
# 1. כשסוגרים את הלשונית, הדפדפן מודיע על כך (bye), והכלי נסגר אחרי BYE_SECONDS.
#    רענון של הדף שולח bye ומיד אחריו בקשה חדשה, ולכן אינו סוגר.
# 2. גיבוי: אם לא התקבלה שום בקשה במשך IDLE_SECONDS (למשל הדפדפן קרס).
# הזמן הארוך מכוון: דפדפנים מאטים טיימרים בלשונית שברקע, ולכן אי אפשר להסיק מהיעדר
# "דופק" שהלשונית נסגרה. בגרסה 2.0 הזמן היה 30 שניות, והכלי נסגר למשתמש באמצע העבודה.
IDLE_SECONDS = int(os.environ.get("MASK_TOOL_IDLE", str(3 * 60 * 60)))
BYE_SECONDS = 20
STARTUP_GRACE = 180        # זמן לדפדפן להיפתח בהפעלה
PREVIEW_COLS = 40
STATE = {"last_ping": time.time() + STARTUP_GRACE, "job": None, "server": None, "bye_at": None}
FOLDERS = {"1": lambda: core.DIR_RAW, "2": lambda: core.DIR_MASKED,
           "3": lambda: core.DIR_FINDINGS, "4": lambda: core.DIR_RESTORED}


# ----------------------------- עזרים -----------------------------

def excel_files(folder, exts=("*.xlsx", "*.xls")):
    out = []
    for ext in exts:
        out.extend(glob.glob(os.path.join(folder, "**", ext), recursive=True))
    return sorted(f for f in set(out)
                  if not f.endswith(".tmp.xlsx") and not os.path.basename(f).startswith("~$"))


def fmt(v):
    if core.is_blank(v):
        return ""
    if isinstance(v, datetime.datetime):
        return v.strftime("%d/%m/%Y") if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%d/%m/%Y %H:%M")
    if isinstance(v, datetime.time):
        return v.strftime("%H:%M")
    if isinstance(v, datetime.timedelta):
        m = int(v.total_seconds() // 60)
        return "%02d:%02d" % (m // 60, m % 60)
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else ("%.2f" % v).rstrip("0").rstrip(".")
    s = str(v)
    return s if len(s) <= 40 else s[:38] + "…"


def load_selection_file():
    try:
        with open(SELECTION_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def project_masked_dir():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f).get("project_masked_dir")
    except Exception:
        return None


def sync_to_project(log):
    import shutil
    target = project_masked_dir()
    if not target:
        return
    os.makedirs(target, exist_ok=True)
    n = 0
    for f in glob.glob(os.path.join(core.DIR_MASKED, "**", "*.*"), recursive=True):
        if f.endswith(".tmp.xlsx"):
            continue
        dst = os.path.join(target, os.path.relpath(f, core.DIR_MASKED))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(f, dst)
        n += 1
    if n:
        log("סונכרנו %d קבצים ממוסכים לתיקיית היעד: %s" % (n, target))


# ----------------------------- פעולות ה-API -----------------------------

def api_state(_body):
    counts = {k: len(excel_files(fn())) for k, fn in FOLDERS.items()}
    return {
        "version": getattr(core, "VERSION", ""),
        "counts": counts,
        "has_key": os.path.exists(core.MAPPING_PATH),
        "has_help": os.path.exists(HELP_PATH),
        "client": core.CLIENT,
        "root": core.ROOT_DIR,
    }


def api_scan(body):
    mode = body.get("mode", "mask")
    folder = core.DIR_MASKED if mode == "remask" else core.DIR_RAW
    cfg = core.load_config(CONFIG_PATH)
    am = cfg["_alias_map"]
    saved = load_selection_file()
    header_rows = body.get("header_rows")
    if header_rows is None:
        # בקבצים שכבר מוסכו (תיקייה 2) הכותרת תמיד בשורה הראשונה, ולכן שורות כותרת
        # שנשמרו ממיסוך הקבצים המקוריים אינן חלות עליהם.
        header_rows = {} if mode == "remask" else (saved.get("header_rows", {}) or {})
    prev = saved.get("selected", {}) or {}
    files = []
    for f in excel_files(folder):
        rel = os.path.relpath(f, folder).replace("\\", "/")
        item = {"rel": rel, "sheets": []}
        try:
            scan = core.scan_headers(f, am, {s: int(r) for s, r in (header_rows.get(rel) or {}).items()})
        except Exception as e:
            item["error"] = str(e)
            files.append(item)
            continue
        for sheet, info in scan.items():
            top = info.get("top", [])
            hr = info["header_row"]
            colnames = core.column_names(top, hr)[:PREVIEW_COLS]
            width = min(max([len(r) for r in top] + [len(colnames), 1]), PREVIEW_COLS)
            cols = []
            for h in info["headers"]:
                field = am.get(h)
                if field is not None and field.get("mandatory"):
                    cls = "mandatory"
                elif field is not None:
                    cls = "known"
                else:
                    cls = "free"
                auto = ("id" if h in info["suspect"] else
                        "name" if h in info.get("suspect_names", []) else
                        info.get("suspect_other", {}).get(h))
                was = h in (prev.get(rel, {}).get(str(sheet), []))
                cols.append({"name": h, "cls": cls, "logical": field["logical"] if field else None,
                             "auto": auto, "checked": cls == "mandatory" or was or bool(auto)})
            item["sheets"].append({
                "name": str(sheet), "header_row": hr, "method": info.get("method", "alias"),
                "empty": not info["headers"], "columns": cols, "colnames": colnames,
                "top": [[fmt(r[j]) if j < len(r) else "" for j in range(width)] for r in top],
            })
        files.append(item)
    skipped = [os.path.relpath(f, folder).replace("\\", "/")
               for f in excel_files(folder, ("*.xlsm", "*.xlsb", "*.csv", "*.ods"))]
    return {"mode": mode, "folder": folder, "files": files, "skipped": skipped, "header_rows": header_rows}


class Job:
    def __init__(self, kind):
        self.kind = kind
        self.lines = []
        self.done = False
        self.ok = False
        self.warn = None
        self.open = None
        self.summary = {}

    def log(self, line):
        self.lines.append(str(line))

    def as_dict(self, since=0):
        return {"kind": self.kind, "lines": self.lines[since:], "count": len(self.lines), "done": self.done,
                "ok": self.ok, "warn": self.warn, "open": self.open, "summary": self.summary}


def api_run(body):
    if STATE["job"] and not STATE["job"].done:
        return {"error": "פעולה אחרת עדיין רצה"}
    mode = body.get("mode", "mask")
    pw = body.get("password") or ""
    if len(pw) < 6:
        return {"error": "הסיסמה קצרה מדי (לפחות 6 תווים)"}
    with open(SELECTION_PATH, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "selected": body.get("selected", {}),
                   "header_rows": body.get("header_rows", {})}, f, ensure_ascii=False, indent=1)
    in_place = mode == "remask"
    folder = core.DIR_MASKED if in_place else core.DIR_RAW
    out_dir = folder if in_place else core.DIR_MASKED
    job = Job(mode)
    STATE["job"] = job

    def work():
        try:
            res = anonymize.run(folder, out_dir, CONFIG_PATH, core.MAPPING_PATH, selection_path=SELECTION_PATH,
                                in_place=in_place, password=pw, log=job.log)
            sync_to_project(job.log)
            stats = res.get("stats", {})
            job.summary = {"stats": stats, "warnings": res.get("warnings", []), "skipped": res.get("skipped", []),
                           "files": [{"file": rel, "status": st, "items": cols}
                                     for rel, st, cols in res.get("details", [])],
                           "blocked": [{"file": rel, "reasons": cols} for rel, st, cols in res.get("details", [])
                                       if st == "blocked"]}
            if stats.get("blocked"):
                job.warn = "%d קבצים נחסמו ולא נכתבו" % stats["blocked"]
            elif stats.get("error"):
                job.warn = "%d קבצים לא נקראו" % stats["error"]
            elif res.get("warnings"):
                job.warn = "%d נקודות לבדיקה לפני העלאה" % len(res["warnings"])
            job.ok = True
            job.open = "2"
        except ValueError as e:
            job.log("שגיאה: %s" % e)
            job.summary = {"error": str(e)}
        except Exception as e:
            job.log("שגיאה בלתי צפויה: %s" % e)
            job.summary = {"error": "שגיאה בלתי צפויה: %s" % e}
        job.done = True

    threading.Thread(target=work, daemon=True).start()
    return {"started": True}


def api_restore_files(_body):
    return {"files": [os.path.relpath(f, core.DIR_FINDINGS).replace("\\", "/")
                      for f in excel_files(core.DIR_FINDINGS, ("*.xlsx",))],
            "has_key": os.path.exists(core.MAPPING_PATH)}


def api_restore(body):
    if STATE["job"] and not STATE["job"].done:
        return {"error": "פעולה אחרת עדיין רצה"}
    pw = body.get("password") or ""
    files = excel_files(core.DIR_FINDINGS, ("*.xlsx",))
    if not files:
        return {"error": "אין קבצים בתיקייה 3"}
    if not os.path.exists(core.MAPPING_PATH):
        return {"error": "קובץ המפתח לא נמצא. שחזור אפשרי רק במחשב ובתיקייה שבהם בוצע המיסוך"}
    job = Job("restore")
    STATE["job"] = job

    def work():
        try:
            cfg = core.load_config(CONFIG_PATH)
            mapping, _ = core.load_mapping(core.MAPPING_PATH, pw)
            reverse = core.build_reverse(mapping)
            token_re = deanonymize.build_token_regex(cfg)
            total = 0
            for f in files:
                rel = os.path.relpath(f, core.DIR_FINDINGS)
                cnt = deanonymize.process_file(f, os.path.join(core.DIR_RESTORED, rel), reverse, token_re)
                total += cnt
                job.log("[שוחזר] %s  (%d אסימונים)" % (rel, cnt))
            job.summary = {"restored": total, "files": len(files)}
            if not total:
                job.warn = "לא נמצאו אסימונים בקבצים"
            job.ok = True
            job.open = "4"
        except ValueError as e:
            job.log("שגיאה: %s" % e)
            job.summary = {"error": str(e)}
        except Exception as e:
            job.log("שגיאה בלתי צפויה: %s" % e)
            job.summary = {"error": "שגיאה בלתי צפויה: %s" % e}
        job.done = True

    threading.Thread(target=work, daemon=True).start()
    return {"started": True}


def api_job(body):
    job = STATE["job"]
    return job.as_dict(int(body.get("since", 0))) if job else {"none": True}


def api_open(body):
    which = str(body.get("which", ""))
    path = HELP_PATH if which == "help" else (FOLDERS[which]() if which in FOLDERS else None)
    if not path:
        return {"error": "לא ידוע"}
    if which != "help":
        os.makedirs(path, exist_ok=True)
    try:
        os.startfile(path)
    except Exception:
        subprocess.Popen(["explorer", path])
    return {"ok": True}


def api_ping(_body):
    return {"ok": True}


def api_quit(_body):
    threading.Thread(target=shutdown, daemon=True).start()
    return {"ok": True}


def api_bye(_body):
    STATE["bye_at"] = time.time()
    return {"ok": True}


ROUTES = {"state": api_state, "scan": api_scan, "run": api_run, "job": api_job, "open": api_open,
          "restore_files": api_restore_files, "restore": api_restore, "ping": api_ping, "quit": api_quit,
          "bye": api_bye}


# ----------------------------- שרת -----------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "MaskTool"
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        # הדף אינו רשאי לטעון או לשלוח דבר לשום כתובת מלבד השרת המקומי הזה
        self.send_header("Content-Security-Policy",
                         "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                         "font-src data:; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'")
        self.end_headers()
        self.wfile.write(data)

    def _local(self):
        host = (self.headers.get("Host") or "").lower()
        port = self.server.server_address[1]
        return host in ("127.0.0.1:%d" % port, "localhost:%d" % port)

    def do_GET(self):
        if not self._local():
            return self._send(403, {"error": "forbidden"})
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            with open(UI_PATH, "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if path == "/logo.png":
            p = os.path.join(TOOL_DIR, "logo.png")
            if os.path.exists(p):
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "image/png")
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._local() or not self.path.startswith("/api/"):
            return self._send(403, {"error": "forbidden"})
        route = self.path[5:].split("?")[0]
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n > 20 * 1024 * 1024:
                return self._send(413, {"error": "too large"})
            body = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
        except Exception:
            return self._send(400, {"error": "bad request"})
        # הודעת הסגירה נשלחת ב-sendBeacon, שאינו יכול לשאת כותרת, ולכן האסימון בגוף ההודעה
        token = self.headers.get("X-Token") or (str(body.get("t") or "") if route == "bye" else "")
        if not secrets.compare_digest(token, TOKEN):
            return self._send(403, {"error": "forbidden"})
        fn = ROUTES.get(route)
        if not fn:
            return self._send(404, {"error": "not found"})
        STATE["last_ping"] = time.time()
        if route != "bye":
            STATE["bye_at"] = None
        try:
            self._send(200, fn(body))
        except Exception as e:
            self._send(200, {"error": "שגיאה: %s" % e})


def shutdown():
    time.sleep(0.3)
    try:
        os.remove(LOCK_PATH)
    except OSError:
        pass
    if STATE["server"]:
        STATE["server"].shutdown()


WATCH_TICK = 5
RESUME_GAP = 60


def resumed_from_sleep(prev, now):
    """True אם בין שתי בדיקות עוקבות עבר הרבה יותר זמן מהצפוי, כלומר המחשב ישן."""
    return now - prev > RESUME_GAP


def watchdog():
    prev = time.time()
    while True:
        time.sleep(WATCH_TICK)
        now = time.time()
        if resumed_from_sleep(prev, now):
            # המחשב חזר משינה: הלשונית עדיין פתוחה אבל לא יכלה לשלוח אות. לא סוגרים,
            # ונותנים לה זמן מלא לחדש את הקשר.
            STATE["last_ping"] = now
        prev = now
        job = STATE["job"]
        if job and not job.done:
            STATE["last_ping"] = time.time()
            STATE["bye_at"] = None
            continue
        bye = STATE["bye_at"]
        if (bye and time.time() - bye > BYE_SECONDS) or time.time() - STATE["last_ping"] > IDLE_SECONDS:
            shutdown()
            return


def already_running():
    """אם הכלי כבר פתוח, פותח את הלשונית שלו במקום להפעיל עותק שני."""
    try:
        with open(LOCK_PATH, "r", encoding="utf-8") as f:
            lock = json.load(f)
        import urllib.request
        req = urllib.request.Request("http://127.0.0.1:%d/api/ping" % lock["port"], data=b"{}",
                                     headers={"X-Token": lock["token"], "Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=2).read()
        webbrowser.open("http://127.0.0.1:%d/#t=%s" % (lock["port"], lock["token"]))
        return True
    except Exception:
        return False


def main(open_browser=True):
    core.ensure_workspace()
    if open_browser and already_running():
        return
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    srv.daemon_threads = True
    STATE["server"] = srv
    port = srv.server_address[1]
    with open(LOCK_PATH, "w", encoding="utf-8") as f:
        json.dump({"port": port, "token": TOKEN, "pid": os.getpid()}, f)
    url = "http://127.0.0.1:%d/#t=%s" % (port, TOKEN)
    threading.Thread(target=watchdog, daemon=True).start()
    if open_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    else:
        print(url, flush=True)
    try:
        srv.serve_forever()
    finally:
        try:
            os.remove(LOCK_PATH)
        except OSError:
            pass


if __name__ == "__main__":
    try:
        if not os.path.exists(UI_PATH):
            raise RuntimeError("ui/index.html חסר")
        main(open_browser="--no-browser" not in sys.argv)
    except Exception:
        # גיבוי: הממשק הקלאסי
        import select_gui
        select_gui.main()
