# -*- coding: utf-8 -*-
"""
select_gui.py - כלי השחרת נתונים: אפליקציה אחת לכל הזרימה.

מסך בית עם שלוש פעולות:
  1. השחרה        — קבצים מקוריים (תיקייה 1) → קבצים מושחרים (תיקייה 2)
  2. השחרה נוספת  — על הקבצים המושחרים עצמם (תיקייה 2, in-place)
  3. שחזור ממצאים — קובצי ממצאים עם אסימונים (תיקייה 3) → מזוהים (תיקייה 4)

הכל בסביבת עבודה אחת: תיקיית כלי-השחרת-נתונים
שם ות"ז מושחרים תמיד; כל השאר לבחירת המשתמש; כל אסימון ניתן לשחזור.
לאחר השחרה הקבצים מסונכרנים אוטומטית גם לתיקיית הפרויקט (output-masked).

שימוש: python select_gui.py [--mode home|mask|remask|restore]
"""
import os
import sys
import glob
import json
import queue
import shutil
import argparse
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import core
import anonymize
import deanonymize

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
SELECTION_PATH = os.path.join(TOOL_DIR, "selection.json")
CONFIG_PATH = os.path.join(TOOL_DIR, "config.json")


def project_masked_dir():
    """תיקיית output-masked של הפרויקט (לסנכרון אוטומטי) — מוגדרת בקונפיג."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f).get("project_masked_dir")
    except Exception:
        return None

CHECKED, UNCHECKED, LOCKED = "☑", "☐", "\U0001F512"

# ----- צבעים ופונטים -----
NAVY = "#14406b"
BLUE = "#2a6fbb"
GREEN = "#2e7d32"
ORANGE = "#e07b00"
RED = "#b30000"
BG = "#eef2f7"
CARD = "#ffffff"
F = ("Segoe UI", 11)
F_B = ("Segoe UI", 11, "bold")
F_TITLE = ("Segoe UI", 16, "bold")
F_BIG = ("Segoe UI", 13, "bold")


def open_folder(path):
    os.makedirs(path, exist_ok=True)
    try:
        os.startfile(path)
    except Exception:
        subprocess.Popen(["explorer", path])


def big_button(parent, text, color, command, **kw):
    b = tk.Button(parent, text=text, command=command, bg=color, fg="white",
                  activebackground=color, activeforeground="white",
                  font=F_BIG, relief="flat", cursor="hand2", bd=0,
                  padx=18, pady=12, **kw)
    return b


def sync_to_project(log):
    """מעתיק את כל הקבצים מתיקייה 2 (מושחרים) לתיקיית הפרויקט output-masked."""
    target = project_masked_dir()
    if not target:
        return
    os.makedirs(target, exist_ok=True)
    n = 0
    for f in glob.glob(os.path.join(core.DIR_MASKED, "**", "*.*"), recursive=True):
        if f.endswith(".tmp.xlsx"):
            continue
        rel = os.path.relpath(f, core.DIR_MASKED)
        dst = os.path.join(target, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(f, dst)
        n += 1
    if n:
        log("סונכרנו %d קבצים מושחרים לתיקיית הפרויקט: %s" % (n, target))


# ============================ דיאלוג סיסמה ============================

def ask_password(root, mapping_path):
    new_file = not os.path.exists(mapping_path)
    dlg = tk.Toplevel(root)
    dlg.title("סיסמת מפתח ההצפנה")
    dlg.configure(bg=CARD)
    dlg.grab_set()
    dlg.resizable(False, False)
    msg = ("בחר/י סיסמה חדשה למפתח ההצפנה (6 תווים לפחות).\nמומלץ משפט ארוך של כמה מילים — ושמור/י אותו היטב!"
           if new_file else "הזן/הזיני את סיסמת המפתח הקיימת:")
    tk.Label(dlg, text=msg, justify="right", anchor="e", bg=CARD, font=F, padx=12, pady=8).pack(fill="x")
    p1 = tk.Entry(dlg, show="*", justify="right", font=F, width=36)
    p1.pack(padx=14, pady=4)
    p2 = None
    if new_file:
        tk.Label(dlg, text="אימות סיסמה:", anchor="e", bg=CARD, font=F, padx=12).pack(fill="x")
        p2 = tk.Entry(dlg, show="*", justify="right", font=F, width=36)
        p2.pack(padx=14, pady=4)
    result = {"pw": None}

    def ok(*_):
        v1 = p1.get()
        if len(v1) < 6:
            messagebox.showwarning("סיסמה", "הסיסמה קצרה מדי (מינימום 6 תווים).", parent=dlg)
            return
        if p2 is not None and p2.get() != v1:
            messagebox.showwarning("סיסמה", "הסיסמאות אינן תואמות.", parent=dlg)
            return
        result["pw"] = v1
        dlg.destroy()

    big_button(dlg, "אישור", GREEN, ok).pack(pady=10)
    dlg.bind("<Return>", ok)
    p1.focus_set()
    root.wait_window(dlg)
    return result["pw"]


# ============================ חלון לוג ============================

class LogWindow:
    """חלון ריצה: מקבל שורות מת'רד עבודה דרך תור (בטוח ל-Tkinter)."""

    def __init__(self, root, title):
        self.win = tk.Toplevel(root)
        self.win.title(title)
        self.win.geometry("780x500")
        self.win.configure(bg=BG)
        head = tk.Frame(self.win, bg=NAVY)
        head.pack(fill="x")
        self.head_lbl = tk.Label(head, text=title, bg=NAVY, fg="white", font=F_B, pady=6)
        self.head_lbl.pack()
        self.txt = tk.Text(self.win, wrap="none", font=("Consolas", 10), bg="#10263f",
                           fg="#d8e6f5", insertbackground="white")
        self.txt.pack(fill="both", expand=True, padx=8, pady=8)
        self.btn = big_button(self.win, "פתח את תיקיית התוצאה", BLUE, lambda: None)
        self.queue = queue.Queue()
        self.done = False
        self.win.after(100, self._poll)

    def log(self, line):
        self.queue.put(str(line))

    def finish(self, ok, open_path=None):
        self.queue.put(("__DONE__", ok, open_path))

    def _poll(self):
        try:
            while True:
                item = self.queue.get_nowait()
                if isinstance(item, tuple) and item[0] == "__DONE__":
                    _, ok, open_path = item
                    self.head_lbl.config(text="✔ הושלם בהצלחה" if ok else "✘ שגיאה",
                                         bg=GREEN if ok else RED)
                    self.win.title("הושלם" if ok else "שגיאה")
                    if open_path:
                        self.btn.config(command=lambda: open_folder(open_path))
                        self.btn.pack(pady=(0, 10))
                    self.done = True
                else:
                    self.txt.insert("end", item + "\n")
                    self.txt.see("end")
        except queue.Empty:
            pass
        if not self.done:
            self.win.after(100, self._poll)


# ============================ מסך השחרה (בחירת שדות) ============================

class MaskFrame(tk.Frame):
    def __init__(self, app, remask=False):
        super().__init__(app.root, bg=BG)
        self.app = app
        self.remask = remask
        self.cfg = core.load_config(CONFIG_PATH)
        self.alias_map = self.cfg["_alias_map"]
        self.state = {}
        self.item_key = {}

        title = "השחרה נוספת — על קבצים שכבר הושחרו" if remask else "השחרה — בחירת שדות"
        color = ORANGE if remask else NAVY
        head = tk.Frame(self, bg=color)
        head.pack(fill="x")
        tk.Button(head, text="→ חזרה", command=app.show_home, bg=color, fg="white",
                  font=F, relief="flat", cursor="hand2", bd=0).pack(side="left", padx=8)
        tk.Label(head, text=title, bg=color, fg="white", font=F_TITLE, pady=10).pack(side="right", padx=14)

        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        default_dir = core.DIR_MASKED if remask else core.DIR_RAW
        self.dir_var = tk.StringVar(value=default_dir)
        tk.Button(top, text="עיון...", command=self.browse, font=F, cursor="hand2").pack(side="left")
        tk.Entry(top, textvariable=self.dir_var, justify="right", font=F).pack(
            side="left", fill="x", expand=True, padx=6)
        lbl = "התיקייה המושחרת (2):" if remask else "תיקיית הקבצים המקוריים (1):"
        tk.Label(top, text=lbl, bg=BG, font=F_B).pack(side="right")

        legend = tk.Frame(self, bg=BG)
        legend.pack(fill="x", padx=10)
        for txt, fg in [("🔒 שם / ת\"ז — מושחר תמיד", "#7a2222"),
                        ("☑ יושחר (הפיך — ניתן לשחזור)", GREEN),
                        ("☐ יישאר גלוי — לחיצה כפולה לשינוי", "#333333")]:
            tk.Label(legend, text=txt, bg="#ffffff", fg=fg, font=F, padx=10, pady=3,
                     relief="groove", bd=1).pack(side="right", padx=4, pady=4)

        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True, padx=10, pady=4)
        style = ttk.Style()
        style.configure("Mask.Treeview", font=F, rowheight=26)
        style.configure("Mask.Treeview.Heading", font=F_B)
        self.tree = ttk.Treeview(mid, columns=("status",), show="tree headings", style="Mask.Treeview")
        self.tree.heading("#0", text="קובץ / גיליון / עמודה", anchor="e")
        self.tree.heading("status", text="סיווג", anchor="e")
        self.tree.column("#0", width=540)
        self.tree.column("status", width=230, anchor="e")
        vsb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="left", fill="y")
        self.tree.pack(side="right", fill="both", expand=True)
        self.tree.tag_configure("file", background="#dbe7f3", font=F_B)
        self.tree.tag_configure("sheet", background="#eef2f7")
        self.tree.tag_configure("mandatory", foreground="#7a2222", background="#f7ecec")
        self.tree.tag_configure("on", foreground=GREEN, background="#e9f5e9")
        self.tree.tag_configure("off", foreground="#333333")
        self.tree.bind("<Double-1>", self.on_toggle)
        self.tree.bind("<space>", self.on_toggle)

        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill="x", padx=10, pady=8)
        big_button(bottom, "▶ התחל השחרה", GREEN, self.start).pack(side="left", padx=4)
        tk.Button(bottom, text="סרוק מחדש", command=self.rescan, font=F, cursor="hand2").pack(side="left", padx=4)
        tk.Button(bottom, text="סמן כל השדות המוכרים", command=self.select_known,
                  font=F, cursor="hand2").pack(side="right", padx=4)
        tk.Button(bottom, text="נקה בחירה (חוץ מחובה)", command=self.clear_all,
                  font=F, cursor="hand2").pack(side="right", padx=4)

        self.status_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self.status_var, anchor="e", bg=BG, font=F,
                 padx=10, pady=4).pack(fill="x")
        self.rescan()

    # ---------- סיווג ----------
    def classify(self, header):
        field = self.alias_map.get(core.normalize_header(header))
        if field is None:
            return "other", None
        if field.get("mandatory"):
            return "mandatory", field
        return "known", field

    def browse(self):
        d = filedialog.askdirectory(initialdir=self.dir_var.get() or os.path.expanduser("~"))
        if d:
            self.dir_var.set(d)
            self.rescan()

    def rescan(self):
        folder = self.dir_var.get()
        self.tree.delete(*self.tree.get_children())
        self.item_key.clear()
        self.state.clear()
        if not os.path.isdir(folder):
            self.status_var.set("התיקייה לא נמצאה: " + folder)
            return
        self.status_var.set("סורק כותרות...")
        self.update_idletasks()
        inventory = {}
        files = []
        for ext in ("*.xlsx", "*.xls"):
            files.extend(glob.glob(os.path.join(folder, "**", ext), recursive=True))
        for f in sorted(set(files)):
            if f.endswith(".tmp.xlsx"):
                continue
            rel = os.path.relpath(f, folder).replace("\\", "/")
            try:
                inventory[rel] = core.scan_headers(f, self.alias_map)
            except Exception as e:
                inventory[rel] = {"<שגיאת קריאה>": {"header_row": 0, "headers": [str(e)]}}
        prev = self.load_previous_selection()
        n_cols = 0
        for rel, sheets in inventory.items():
            f_id = self.tree.insert("", "end", text="📄 " + rel, open=True, tags=("file",))
            for sheet, info in sheets.items():
                headers = info["headers"]
                note = " (כותרות בשורה %d)" % (info["header_row"] + 1) if info["header_row"] else ""
                s_id = self.tree.insert(f_id, "end", text="גיליון: " + str(sheet) + note,
                                        open=True, tags=("sheet",))
                for h in headers:
                    kind, field = self.classify(h)
                    key = (rel, str(sheet), core.normalize_header(h))
                    if kind == "mandatory":
                        item = self.tree.insert(s_id, "end", text="%s %s" % (LOCKED, h),
                                                values=("חובה — שם/ת\"ז",), tags=("mandatory",))
                    else:
                        checked = prev.get(key, False)
                        self.state[key] = checked
                        box = CHECKED if checked else UNCHECKED
                        status = "מוכר (%s)" % field["logical"] if kind == "known" else "עמודה חופשית"
                        item = self.tree.insert(s_id, "end", text="%s %s" % (box, h),
                                                values=(status,), tags=("on" if checked else "off",))
                        self.item_key[item] = key
                    n_cols += 1
        if not inventory:
            self.status_var.set("לא נמצאו קובצי Excel בתיקייה. שים קבצים ולחץ 'סרוק מחדש'.")
        else:
            self.status_var.set("נמצאו %d קבצים, %d עמודות. לחיצה כפולה על עמודה מסמנת/מבטלת השחרה." %
                                (len(inventory), n_cols))

    def load_previous_selection(self):
        if not os.path.exists(SELECTION_PATH):
            return {}
        try:
            with open(SELECTION_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            prev = {}
            for rel, sheets in data.get("selected", {}).items():
                for sheet, headers in sheets.items():
                    for h in headers:
                        prev[(rel, sheet, h)] = True
            return prev
        except Exception:
            return {}

    # ---------- סימון ----------
    def refresh_item(self, item):
        key = self.item_key.get(item)
        if key is None:
            return
        on = self.state.get(key, False)
        self.tree.item(item, text="%s %s" % (CHECKED if on else UNCHECKED, key[2]),
                       tags=("on" if on else "off",))

    def on_toggle(self, event):
        item = self.tree.focus()
        if getattr(event, "y", None) is not None and event.type == tk.EventType.ButtonPress:
            item = self.tree.identify_row(event.y) or item
        key = self.item_key.get(item)
        if key is None:
            return
        new_val = not self.state.get(key, False)
        header = key[2]
        for it, k in self.item_key.items():
            if k[2] == header:
                self.state[k] = new_val
                self.refresh_item(it)

    def select_known(self):
        for it, key in self.item_key.items():
            if self.classify(key[2])[0] == "known":
                self.state[key] = True
                self.refresh_item(it)

    def clear_all(self):
        for it, key in self.item_key.items():
            self.state[key] = False
            self.refresh_item(it)

    # ---------- הרצה ----------
    def build_selection(self):
        selected = {}
        for (rel, sheet, header), on in self.state.items():
            if on:
                selected.setdefault(rel, {}).setdefault(sheet, []).append(header)
        return {"version": 1, "selected": selected}

    def start(self):
        folder = self.dir_var.get()
        if not os.path.isdir(folder):
            messagebox.showerror("שגיאה", "התיקייה לא נמצאה:\n" + folder)
            return
        with open(SELECTION_PATH, "w", encoding="utf-8") as f:
            json.dump(self.build_selection(), f, ensure_ascii=False, indent=1)

        pw = ask_password(self.app.root, core.MAPPING_PATH)
        if not pw:
            return
        out_dir = folder if self.remask else core.DIR_MASKED
        lw = LogWindow(self.app.root, "מריץ השחרה נוספת..." if self.remask else "מריץ השחרה...")

        def work():
            try:
                anonymize.run(folder, out_dir, CONFIG_PATH, core.MAPPING_PATH,
                              selection_path=SELECTION_PATH, in_place=self.remask,
                              password=pw, log=lw.log)
                sync_to_project(lw.log)
                lw.finish(True, open_path=core.DIR_MASKED)
            except ValueError as e:
                lw.log("שגיאה: %s" % e)
                lw.finish(False)
            except Exception as e:
                lw.log("שגיאה בלתי צפויה: %s" % e)
                lw.finish(False)

        threading.Thread(target=work, daemon=True).start()


# ============================ מסך שחזור ============================

class RestoreFrame(tk.Frame):
    def __init__(self, app):
        super().__init__(app.root, bg=BG)
        self.app = app
        head = tk.Frame(self, bg=GREEN)
        head.pack(fill="x")
        tk.Button(head, text="→ חזרה", command=app.show_home, bg=GREEN, fg="white",
                  font=F, relief="flat", cursor="hand2", bd=0).pack(side="left", padx=8)
        tk.Label(head, text="שחזור ממצאים — זיהוי חזרה", bg=GREEN, fg="white",
                 font=F_TITLE, pady=10).pack(side="right", padx=14)

        info = tk.Label(self, bg="#eff8ef", fg="#145214", font=F, justify="right", anchor="e",
                        padx=12, pady=8, relief="groove", bd=1, text=(
                            "שים את קובצי הממצאים (עם אסימונים כמו ID-000123) בתיקייה 3,\n"
                            "לחץ 'שחזר' — והקבצים המזוהים (שמות/ת\"ז אמיתיים) ייווצרו בתיקייה 4.\n"
                            "הקבצים המזוהים לשימוש מקומי בלבד — לא להעלאה!"))
        info.pack(fill="x", padx=10, pady=8)

        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", padx=10)
        tk.Button(row, text="פתח את תיקייה 3 (ממצאים)", command=lambda: open_folder(core.DIR_FINDINGS),
                  font=F, cursor="hand2").pack(side="right", padx=4)
        tk.Button(row, text="רענן רשימה", command=self.refresh, font=F, cursor="hand2").pack(side="right", padx=4)

        self.listbox = tk.Listbox(self, font=F, justify="right", height=12, bg=CARD)
        self.listbox.pack(fill="both", expand=True, padx=10, pady=8)

        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill="x", padx=10, pady=8)
        big_button(bottom, "🔓 שחזר את כל הקבצים", GREEN, self.restore).pack(side="left", padx=4)
        self.status_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self.status_var, anchor="e", bg=BG, font=F,
                 padx=10, pady=4).pack(fill="x")
        self.refresh()

    def files(self):
        return sorted(glob.glob(os.path.join(core.DIR_FINDINGS, "**", "*.xlsx"), recursive=True))

    def refresh(self):
        self.listbox.delete(0, "end")
        fs = self.files()
        for f in fs:
            self.listbox.insert("end", os.path.relpath(f, core.DIR_FINDINGS))
        self.status_var.set("%d קבצים ממתינים לשחזור בתיקייה 3." % len(fs) if fs
                            else "תיקייה 3 ריקה — שים בה את קובצי הממצאים ולחץ 'רענן רשימה'.")

    def restore(self):
        fs = self.files()
        if not fs:
            messagebox.showinfo("שחזור", "אין קבצים בתיקייה 3.")
            return
        if not os.path.exists(core.MAPPING_PATH):
            messagebox.showerror("שגיאה", "קובץ המפתח לא נמצא:\n" + core.MAPPING_PATH)
            return
        pw = ask_password(self.app.root, core.MAPPING_PATH)
        if not pw:
            return
        lw = LogWindow(self.app.root, "משחזר ממצאים...")

        def work():
            try:
                cfg = core.load_config(CONFIG_PATH)
                mapping, _ = core.load_mapping(core.MAPPING_PATH, pw)
                reverse = core.build_reverse(mapping)
                token_re = deanonymize.build_token_regex(cfg)
                lw.log("=" * 60)
                total = 0
                for f in fs:
                    rel = os.path.relpath(f, core.DIR_FINDINGS)
                    out = os.path.join(core.DIR_RESTORED, rel)
                    cnt = deanonymize.process_file(f, out, reverse, token_re)
                    total += cnt
                    lw.log("[שוחזר] %s  (%d אסימונים)" % (rel, cnt))
                lw.log("=" * 60)
                lw.log("סה\"כ אסימונים ששוחזרו: %d" % total)
                lw.log("תיקיית הפלט המזוהה (מקומי בלבד): " + core.DIR_RESTORED)
                lw.finish(True, open_path=core.DIR_RESTORED)
            except ValueError as e:
                lw.log("שגיאה: %s" % e)
                lw.finish(False)
            except Exception as e:
                lw.log("שגיאה בלתי צפויה: %s" % e)
                lw.finish(False)

        threading.Thread(target=work, daemon=True).start()


# ============================ מסך הבית ============================

class HomeFrame(tk.Frame):
    def __init__(self, app, notes):
        super().__init__(app.root, bg=BG)
        # רצועת לוגו לבנה מעל הכותרת (הלוגו כהה ולכן לא על רקע כחול)
        logo_path = os.path.join(TOOL_DIR, "logo.png")
        if os.path.exists(logo_path):
            try:
                self._logo_img = tk.PhotoImage(file=logo_path)
                logo_bar = tk.Frame(self, bg="white")
                logo_bar.pack(fill="x")
                tk.Label(logo_bar, image=self._logo_img, bg="white").pack(pady=8)
            except Exception:
                pass
        head = tk.Frame(self, bg=NAVY)
        head.pack(fill="x")
        tk.Label(head, text="🛡 כלי השחרת נתונים" + (" - " + core.CLIENT if core.CLIENT else ""),
                 bg=NAVY, fg="white",
                 font=("Segoe UI", 18, "bold"), pady=14).pack()
        tk.Label(head, text="שם ות\"ז מושחרים תמיד · כל השאר לבחירתך · כל אסימון ניתן לשחזור",
                 bg=NAVY, fg="#bcd2e8", font=F, pady=2).pack()

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=24, pady=16)

        actions = [
            ("1", "🔒  השחרה", "קבצים מקוריים (תיקייה 1) ← מושחרים (תיקייה 2)", NAVY, app.show_mask),
            ("2", "➕  השחרה נוספת", "הוספת שדות על קבצים שכבר הושחרו (תיקייה 2)", ORANGE, app.show_remask),
            ("3", "🔓  שחזור ממצאים", "ממצאים עם אסימונים (תיקייה 3) ← מזוהים (תיקייה 4)", GREEN, app.show_restore),
        ]
        for num, title, sub, color, cmd in actions:
            card = tk.Frame(body, bg=CARD, highlightbackground="#c9d4e0", highlightthickness=1)
            card.pack(fill="x", pady=7)
            b = big_button(card, title, color, cmd, width=18)
            b.pack(side="right", padx=12, pady=12)
            tk.Label(card, text=sub, bg=CARD, fg="#444444", font=F, anchor="e",
                     justify="right").pack(side="right", padx=8, fill="x", expand=True)

        folders = tk.LabelFrame(body, text=" סביבת העבודה (תיקייה אחת בשולחן העבודה) ", bg=BG,
                                font=F_B, fg=NAVY, labelanchor="ne")
        folders.pack(fill="x", pady=12)
        for label, path, danger in [
            ("1 · מקוריים", core.DIR_RAW, True),
            ("2 · מושחרים ✔", core.DIR_MASKED, False),
            ("3 · ממצאים", core.DIR_FINDINGS, False),
            ("4 · משוחזרים", core.DIR_RESTORED, True),
        ]:
            tk.Button(folders, text=label, command=lambda p=path: open_folder(p),
                      bg="#f7ecec" if danger else "#e9f5e9",
                      fg=RED if danger else GREEN, font=F, relief="groove",
                      cursor="hand2", padx=10, pady=6).pack(side="right", padx=6, pady=8)
        tk.Label(folders, text="אדום = לא להעלות · ירוק = בטוח", bg=BG, fg="#666666",
                 font=("Segoe UI", 9)).pack(side="left", padx=8)

        for n in notes:
            tk.Label(body, text="ℹ " + n, bg="#f0f5fc", fg="#123c66", font=F, anchor="e",
                     padx=10, pady=6, relief="groove", bd=1).pack(fill="x", pady=3)


# ============================ האפליקציה ============================

class App:
    def __init__(self, root, start_mode="home"):
        self.root = root
        root.title("כלי השחרת נתונים" + (" - " + core.CLIENT if core.CLIENT else ""))
        root.geometry("900x680")
        root.configure(bg=BG)
        self.notes = core.ensure_workspace()
        self.current = None
        {"home": self.show_home, "mask": self.show_mask,
         "remask": self.show_remask, "restore": self.show_restore}.get(start_mode, self.show_home)()

    def _swap(self, frame):
        if self.current is not None:
            self.current.destroy()
        self.current = frame
        frame.pack(fill="both", expand=True)

    def show_home(self):
        self._swap(HomeFrame(self, self.notes))

    def show_mask(self):
        self._swap(MaskFrame(self, remask=False))

    def show_remask(self):
        self._swap(MaskFrame(self, remask=True))

    def show_restore(self):
        self._swap(RestoreFrame(self))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="home", choices=["home", "mask", "remask", "restore"])
    ap.add_argument("--in-place", action="store_true", help="(תאימות לאחור) שקול ל---mode remask")
    args = ap.parse_args()
    mode = "remask" if args.in_place else args.mode
    root = tk.Tk()
    try:
        style = ttk.Style(root)
        style.theme_use("vista")
    except Exception:
        pass
    App(root, start_mode=mode)
    root.mainloop()


if __name__ == "__main__":
    main()
