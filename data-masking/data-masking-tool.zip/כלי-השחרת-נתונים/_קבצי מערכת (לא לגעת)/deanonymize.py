# -*- coding: utf-8 -*-
"""
deanonymize.py - שחזור (זיהוי חזרה) של אסימונים לערכים המקוריים.

שימוש:
    python deanonymize.py <תיקיית_קלט> <תיקיית_פלט> [--config config.json] [--mapping <נתיב mapping.enc>]

מקבל קובצי ממצאים/תוצאות (.xlsx) המכילים אסימונים (למשל ACC-000123) וכותב עותקים
שבהם האסימונים הוחלפו חזרה בערכים המקוריים. פועל על תוכן תאים (כולל אסימון בתוך טקסט).
פלט זה מכיל מידע אישי אמיתי -> לשמירה מקומית בלבד, לא להעלאה לתיקיית הפרויקט.
"""
import os
import re
import sys
import glob
import argparse
import getpass

import openpyxl

import core

DEFAULT_MAPPING = core.MAPPING_PATH


def build_token_regex(cfg):
    prefixes = cfg.get("token_prefixes_for_reverse")
    if not prefixes:
        prefixes = sorted({f["prefix"] for f in cfg["fields"] if f.get("prefix")})
    alts = "|".join(re.escape(p) for p in prefixes)
    return re.compile(r"(?:%s)-\d+" % alts)


def restore_cell(value, reverse, token_re):
    if not isinstance(value, str):
        return value, 0
    n = [0]

    def repl(m):
        tok = m.group(0)
        if tok in reverse:
            n[0] += 1
            return reverse[tok]
        return tok

    new = token_re.sub(repl, value)
    return new, n[0]


def process_file(in_path, out_path, reverse, token_re):
    wb = openpyxl.load_workbook(in_path)
    total = 0
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                new, cnt = restore_cell(cell.value, reverse, token_re)
                if cnt:
                    cell.value = new
                    total += cnt
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    wb.save(out_path)
    return total


def main():
    ap = argparse.ArgumentParser(description="שחזור אסימונים לערכים מקוריים.")
    ap.add_argument("input_dir", help="תיקיית קבצים עם אסימונים")
    ap.add_argument("output_dir", help="תיקיית פלט (מזוהה, מקומי בלבד)")
    ap.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "config.json"))
    ap.add_argument("--mapping", default=DEFAULT_MAPPING)
    args = ap.parse_args()

    if os.path.abspath(args.input_dir) == os.path.abspath(args.output_dir):
        print("שגיאה: תיקיית הקלט והפלט חייבות להיות שונות.")
        sys.exit(1)

    cfg = core.load_config(args.config)
    if not os.path.exists(args.mapping):
        print("שגיאה: קובץ המיפוי לא נמצא:", args.mapping)
        sys.exit(1)
    password = getpass.getpass("סיסמת המפתח: ")
    try:
        mapping, _ = core.load_mapping(args.mapping, password)
    except ValueError as e:
        print("שגיאה:", e)
        sys.exit(1)

    reverse = core.build_reverse(mapping)
    token_re = build_token_regex(cfg)

    files = sorted(glob.glob(os.path.join(args.input_dir, "**", "*.xlsx"), recursive=True))
    if not files:
        print("לא נמצאו קובצי .xlsx בתיקיית הקלט.")
        sys.exit(0)

    print("=" * 60)
    grand = 0
    for in_path in files:
        rel = os.path.relpath(in_path, args.input_dir)
        out_path = os.path.join(args.output_dir, rel)
        cnt = process_file(in_path, out_path, reverse, token_re)
        grand += cnt
        print("[שוחזר] %s  (%d אסימונים)" % (rel, cnt))
    print("=" * 60)
    print("סה\"כ אסימונים ששוחזרו:", grand)
    print("תיקיית הפלט המזוהה (מקומי בלבד, לא להעלאה):", os.path.abspath(args.output_dir))


if __name__ == "__main__":
    main()
