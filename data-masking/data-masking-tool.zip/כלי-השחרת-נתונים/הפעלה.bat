@echo off
rem ==================================================================
rem  Data-masking tool launcher (HGJ)
rem
rem  ASCII only on purpose: Hebrew inside a .bat breaks cmd parsing on
rem  some codepages. All Hebrew UI lives in the Python app itself.
rem
rem  No pipes on purpose ("echo | find" can hang in odd environments).
rem  Pure batch string tests are used instead.
rem ==================================================================
setlocal enabledelayedexpansion
set PYTHONUTF8=1
cd /d "%~dp0"
title Data-masking tool

rem ---- locate the system subfolder (its name starts with "_") ----
set "SYS="
for /d %%D in ("%~dp0_*") do set "SYS=%%D"
if not defined SYS goto :no_sys
set "SCRIPT=%SYS%\select_gui.py"
if not exist "!SCRIPT!" goto :no_script

rem ---- pass 1: an interpreter that ALREADY has every package ----
set "PY="
set "PYW="
set "NEED_PKGS=1"
call :scan
if defined PY goto :launch

rem ---- pass 2: any working interpreter (packages get installed into it) ----
set "NEED_PKGS="
call :scan
if not defined PY goto :no_python
goto :setup


:launch
rem Windowed twin comes from the SAME install, so it has the same packages.
if defined PYW (
  start "" "!PYW!" "!SCRIPT!" --mode home
) else (
  start "" "!PY!" "!SCRIPT!" --mode home
)
exit /b 0


rem ======================= interpreter discovery =======================

:scan
call :find py.exe
if not defined PY call :find python.exe
if not defined PY call :find python3.exe
exit /b 0

:find
for /f "delims=" %%I in ('where %~1 2^>nul') do call :try "%%~I"
exit /b 0

:try
if defined PY exit /b 0
set "cand=%~1"
rem skip the Microsoft Store alias stubs, they are not real interpreters
if not "!cand:WindowsApps=!"=="!cand!" exit /b 0
if defined NEED_PKGS (
  set "PROBE=import tkinter, pandas, openpyxl, cryptography"
) else (
  set "PROBE=import sys"
)
"!cand!" -c "!PROBE!" >nul 2>nul
if errorlevel 1 exit /b 0
set "PY=!cand!"
rem derive the windowed twin next to it (pythonw.exe / pyw.exe)
for %%F in ("!cand!") do set "cdir=%%~dpF"
for %%F in ("!cand!") do set "cname=%%~nF"
set "PYW="
if /i "!cname!"=="py"      set "PYW=!cdir!pyw.exe"
if /i "!cname!"=="python"  set "PYW=!cdir!pythonw.exe"
if /i "!cname!"=="python3" set "PYW=!cdir!pythonw.exe"
if defined PYW if not exist "!PYW!" set "PYW="
exit /b 0


rem ======================= one-time setup =======================

:setup
echo.
echo  ==================================================================
echo    Data-masking tool - one-time setup
echo  ==================================================================
echo.
echo    Python was found:
echo      !PY!
echo.
echo    Required packages are missing:
echo      pandas, openpyxl, xlrd, cryptography
echo.
choice /c YN /n /m "   Install them now? [Y=yes / N=no] "
if errorlevel 2 goto :setup_declined
echo.
echo    Installing... this can take a minute.
echo.
"!PY!" -m pip install --disable-pip-version-check pandas openpyxl xlrd cryptography
echo.
"!PY!" -c "import tkinter, pandas, openpyxl, cryptography" >nul 2>nul
if errorlevel 1 goto :setup_failed
echo    Setup complete. Starting the tool...
echo.
goto :launch

:setup_declined
echo.
echo    Setup cancelled. To install manually, run:
echo      "!PY!" -m pip install pandas openpyxl xlrd cryptography
echo.
pause
exit /b 1

:setup_failed
echo.
echo    Installation did not complete. Try this manually:
echo      "!PY!" -m pip install pandas openpyxl xlrd cryptography
echo.
echo    If it fails with a permissions error, add  --user  at the end.
echo.
pause
exit /b 1


rem ======================= errors =======================

:no_python
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms | Out-Null; [System.Windows.Forms.MessageBox]::Show('This tool needs Python 3, which was not found on this computer.' + [char]10 + [char]10 + 'The official download page will open now (python.org).' + [char]10 + 'During install, tick: Add python.exe to PATH.' + [char]10 + [char]10 + 'Then double-click this file again - it finishes the setup by itself.', 'Data-masking tool - Python required', 'OK', 'Warning') | Out-Null"
start "" https://www.python.org/downloads/windows/
exit /b 1

:no_sys
echo.
echo    ERROR: the system folder (the one whose name starts with "_") was
echo    not found next to this file. Extract the whole ZIP keeping its
echo    structure, then run this file from inside the extracted folder.
echo.
pause
exit /b 1

:no_script
echo.
echo    ERROR: select_gui.py was not found in:
echo      !SYS!
echo.
echo    The package looks incomplete. Download it again from the tools site.
echo.
pause
exit /b 1
