@echo off
rem ============================================================
rem   Data-masking tool launcher - HGJ
rem   Double-click me. Requires Python 3 installed on this PC.
rem ============================================================
set PYTHONUTF8=1
setlocal enabledelayedexpansion

rem --- locate the system subfolder (starts with "_") ---
set "SYS="
for /d %%D in ("%~dp0_*") do set "SYS=%%D"
if not defined SYS (
  echo System folder not found next to this file.
  pause
  exit /b 1
)
set "SCRIPT=%SYS%\select_gui.py"

rem --- find a Python runner: windowed first (no console), then console ---
set "RUNNER="
for %%P in (pyw.exe pythonw.exe python.exe py.exe) do (
  if not defined RUNNER (
    where %%P >nul 2>nul && set "RUNNER=%%P"
  )
)

if defined RUNNER (
  start "" "!RUNNER!" "!SCRIPT!" --mode home
  exit /b 0
)

rem --- Python not found: clear message + open the download page ---
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms | Out-Null; [System.Windows.Forms.MessageBox]::Show('This tool requires Python 3, which is not installed on this computer.' + [char]10 + [char]10 + 'The download page will now open. During install, tick the box: Add python.exe to PATH.' + [char]10 + [char]10 + 'After installing, open Command Prompt and run:' + [char]10 + 'pip install pandas openpyxl xlrd cryptography' + [char]10 + [char]10 + 'Then double-click this file again.', 'Data-masking tool - Python required', 'OK', 'Warning') | Out-Null"
start "" https://www.python.org/downloads/
exit /b 1
