@echo off
rem HGJ voice dictation for desktop - launcher (no console window)
set "VENV=%LOCALAPPDATA%\HGJ\dictation-desktop\venv"
if not exist "%VENV%\Scripts\pythonw.exe" (
  echo The tool is not installed yet. Run the setup .bat first.
  pause
  exit /b 1
)
start "" "%VENV%\Scripts\pythonw.exe" "%~dp0dictate.py"
