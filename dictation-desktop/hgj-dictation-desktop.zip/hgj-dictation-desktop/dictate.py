# -*- coding: utf-8 -*-
"""
הכתבה קולית למחשב - HGJ

כפתור מיקרופון מרחף מעל כל החלונות (או מקש F9). לוחצים, מדברים, שקט קצר מסיים
את המשפט, והטקסט מוקלד ישר לשדה הטקסט הממוקד: Claude, Word, Outlook, דפדפן.

התמלול מקומי לחלוטין (מודל Whisper בעברית של ivrit.ai דרך faster-whisper).
האודיו לא יוצא מהמחשב.

הרצה: הפעלה.bat  |  בדיקה בלי ממשק: python dictate.py --test-wav קובץ.wav
"""
import os
import sys
import json
import time
import queue
import logging
import threading
import ctypes

import numpy as np

APP_VERSION = "1.1.1"
if getattr(sys, "frozen", False):
    HERE = os.path.dirname(sys.executable)          # (אריזת PyInstaller ישנה) config.json ליד קובץ ההרצה
else:
    HERE = os.path.dirname(os.path.abspath(__file__))
# הפייתון המוטמע (._pth) רץ במצב מבודד ולא מוסיף את תיקיית הסקריפט לנתיב החיפוש,
# ולכן import download_model נכשל בהפעלה ראשונה. מוסיפים במפורש.
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# אפליקציה מותקנת (מגרסה 1.1.0): פייתון מוטמע רשמי בתיקיית runtime ליד הסקריפט,
# עם Tcl/Tk שהועתקו מהתקנה מלאה. Tk צריך לדעת איפה הספריות שלו.
_tcl_dir = os.path.join(os.path.dirname(sys.executable), "tcl")
if os.path.isdir(_tcl_dir):
    os.environ.setdefault("TCL_LIBRARY", os.path.join(_tcl_dir, "tcl8.6"))
    os.environ.setdefault("TK_LIBRARY", os.path.join(_tcl_dir, "tk8.6"))
APP_DIR = os.path.join(os.environ.get("LOCALAPPDATA", HERE), "HGJ", "dictation-desktop")
STATE_PATH = os.path.join(APP_DIR, "state.json")
LOG_PATH = os.path.join(APP_DIR, "dictate.log")
CONFIG_PATH = os.path.join(HERE, "config.json")
DICT_PATH = os.path.join(HERE, "dictionary.txt")
DICT_TEMPLATE = """# המילון האישי של הכתבה קולית HGJ
#
# שורה לכל מונח. המנוע יעדיף את המילים שרשומות כאן: שמות לקוחות, חברות,
# אנשים, מונחים מקצועיים ופנימיים שהוא נוטה לשבש.
#
# להחלפה קבועה (כשהמנוע כותב משהו באופן עקבי לא נכון):
#   מה_שהמנוע_כותב => מה_שצריך_להיכתב
#
# שורות שמתחילות ב-# הן הערות. הקובץ נקרא מחדש בכל תמלול, אין צורך להפעיל מחדש.
#
# דוגמאות (מחקו והחליפו בשלכם):
# הוגן גינזבורג יודלביץ
# ביקורת פנימית
# דוח רווח והפסד
# רשות המסים
# מס הכנסה => מס הכנסה
"""

SAMPLE_RATE = 16000
BLOCK = 800                     # 50 אלפיות שנייה לבלוק

COLORS = {
    "loading":      ("#8A94A6", "טוען מודל"),
    "idle":         ("#2F55D4", ""),
    "recording":    ("#E03131", "מחכה לדיבור"),
    "speech":       ("#C92A2A", "מקשיב"),
    "transcribing": ("#D97706", "מתמלל"),
    "nospeech":     ("#6B7280", "לא נקלט קול"),
    "error":        ("#6B7280", "שגיאה"),
}

# ----------------------------- Windows -----------------------------
user32 = ctypes.windll.user32
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
GWL_EXSTYLE = -20
WS_EX_NOACTIVATE = 0x08000000   # לחיצה על הכפתור לא גונבת את המיקוד מהחלון שבו כותבים
WS_EX_TOOLWINDOW = 0x00000080   # לא מופיע ב-Alt+Tab


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["model_dir"] = os.path.expandvars(cfg["model_dir"])
    return cfg


def load_state():
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def ensure_dictionary():
    if not os.path.exists(DICT_PATH):
        try:
            with open(DICT_PATH, "w", encoding="utf-8") as f:
                f.write(DICT_TEMPLATE)
        except Exception:
            pass


def load_dictionary():
    """מילון אישי: מונחים שהמנוע יעדיף (hotwords) והחלפות קבועות (מה => למה)."""
    hot, repl = [], []
    try:
        with open(DICT_PATH, "r", encoding="utf-8") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                if "=>" in s:
                    a, b = [x.strip() for x in s.split("=>", 1)]
                    if a and a != b:
                        repl.append((a, b))
                else:
                    hot.append(s)
    except FileNotFoundError:
        pass
    repl.sort(key=lambda p: -len(p[0]))     # החלפות ארוכות קודם, כדי שלא יישברו על ידי קצרות
    return hot, repl


def window_title(hwnd):
    if not hwnd:
        return "(none)"
    buf = ctypes.create_unicode_buffer(256)
    user32.GetWindowTextW(hwnd, buf, 256)
    return buf.value or f"hwnd {hwnd}"


def save_state(st):
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
    except Exception:
        pass


def setup_logging():
    os.makedirs(APP_DIR, exist_ok=True)
    logging.basicConfig(filename=LOG_PATH, level=logging.INFO, encoding="utf-8",
                        format="%(asctime)s %(levelname)s %(message)s")


# ----------------------------- הקלטה וזיהוי שקט -----------------------------
class Recorder:
    """מקליט מהמיקרופון ומסיים לבד אחרי שקט. הלוגיקה בת'רד נפרד, לא בקולבק של האודיו."""

    def __init__(self, cfg, on_segment, on_end, on_state, on_level=None):
        self.cfg = cfg
        self.on_segment = on_segment    # מקטע דיבור שהסתיים בשקט קצר: לתמלול, ההאזנה ממשיכה
        self.on_end = on_end            # ההאזנה הסתיימה (לחיצה, שקט ארוך או תקרת זמן)
        self.on_state = on_state
        self.on_level = on_level        # עוצמת קול רגעית, לחיווי הפסים בחלונית
        self.q = queue.Queue()
        self.running = False
        self.cancel = False
        self.stream = None

    @staticmethod
    def resolve_device(cfg):
        """input_device בהגדרות: null = ברירת המחדל של Windows, מספר = אינדקס, טקסט = חלק משם המכשיר."""
        import sounddevice as sd
        want = cfg.get("input_device")
        if want is None or want == "":
            return None
        if isinstance(want, int):
            return want
        for i, d in enumerate(sd.query_devices()):
            if d["max_input_channels"] > 0 and str(want).lower() in d["name"].lower():
                return i
        logging.warning("input_device %r not found, using default", want)
        return None

    def start(self):
        import sounddevice as sd
        if self.running:
            return
        self.running = True
        self.cancel = False
        self.q = queue.Queue()
        self.stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                                     blocksize=BLOCK, callback=self._callback,
                                     device=self.resolve_device(self.cfg))
        self.stream.start()
        threading.Thread(target=self._worker, daemon=True).start()

    def stop(self, cancel=False):
        if self.running:
            self.cancel = cancel
            self.running = False

    def _callback(self, indata, frames, t, status):
        if self.running:
            self.q.put(indata[:, 0].copy())

    def _worker(self):
        """מאזין ברצף. שקט קצר סוגר מקטע ושולח אותו לתמלול בלי לעצור את ההאזנה;
        שקט ארוך, לחיצה או תקרת הזמן מסיימים את ההאזנה."""
        cfg = self.cfg
        seg_gap = cfg.get("segment_silence_seconds", cfg.get("silence_seconds", 1.2))
        end_gap = cfg.get("end_silence_seconds", 15)
        preroll_blocks = int(0.5 * SAMPLE_RATE / BLOCK)
        noise = []
        seg_frames = []
        seg_started = False
        any_speech = False
        last_voice = None
        session_last_voice = None
        t0 = time.time()
        peak = 0.0
        threshold = cfg["min_energy_threshold"]
        loud_streak = 0
        segments_sent = 0

        def flush():
            nonlocal seg_frames, seg_started, segments_sent
            if seg_started and seg_frames:
                audio = np.concatenate(seg_frames).astype(np.float32)
                if len(audio) >= 0.4 * SAMPLE_RATE:
                    segments_sent += 1
                    self.on_segment(audio)
            seg_frames = []
            seg_started = False

        while self.running:
            try:
                block = self.q.get(timeout=0.1)
            except queue.Empty:
                continue
            now = time.time()
            # רבע השנייה הראשונה מכילה טרנזיינט של פתיחת המכשיר (נמדד: פי 70 מרצפת הרעש).
            # לא לכיול ולא לזיהוי.
            if now - t0 < 0.25:
                continue
            seg_frames.append(block)
            rms = float(np.sqrt(np.mean(block * block)))
            peak = max(peak, rms)
            noise.append(rms)
            if self.on_level and len(noise) % 2 == 0:      # 10 עדכונים בשנייה מספיקים לפסים
                self.on_level(rms)
            if len(noise) < 4:
                continue
            # רצפת הרעש = האחוזון ה-20 של כל מה שנקלט עד כה. גם בזמן דיבור רציף יש
            # הפסקות בין מילים, ולכן הערך נשאר נמוך. תקרה מונעת סף בלתי אפשרי.
            floor = float(np.percentile(noise, 20))
            threshold = min(max(cfg["min_energy_threshold"], floor * cfg["noise_multiplier"]),
                            cfg.get("max_energy_threshold", 0.04))
            if rms > threshold:
                loud_streak += 1
                if loud_streak >= 2:                 # 100 אלפיות שנייה רצופות, לא קליק
                    if not seg_started:
                        self.on_state("speech")
                    seg_started = True
                    any_speech = True
                    last_voice = now
                    session_last_voice = now
            else:
                loud_streak = 0
                if seg_started and now - last_voice > seg_gap:
                    flush()                          # המשפט הסתיים: לתמלול, וממשיכים להקשיב
                    self.on_state("recording")
                elif not seg_started and len(seg_frames) > 4 * preroll_blocks:
                    seg_frames = seg_frames[-preroll_blocks:]   # לא לצבור שקט, לשמור חצי שנייה לפני הדיבור
            if any_speech and now - session_last_voice > end_gap:
                break
            if not any_speech and now - t0 > cfg["no_speech_timeout_seconds"]:
                self.cancel = True
                break
            if now - t0 > cfg["max_recording_seconds"]:
                break
        self.running = False
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass
        while not self.q.empty():
            seg_frames.append(self.q.get_nowait())
        flush()
        logging.info("session ended: speech=%s segments=%d peak_rms=%.5f threshold=%.5f noise_floor=%.5f seconds=%.1f",
                     any_speech, segments_sent, peak, threshold,
                     float(np.percentile(noise, 20)) if noise else -1, time.time() - t0)
        self.on_end(any_speech)


# ----------------------------- תמלול -----------------------------
class Transcriber:
    def __init__(self, cfg):
        self.cfg = cfg
        self.model = None

    def load(self):
        from faster_whisper import WhisperModel
        if not os.path.exists(os.path.join(self.cfg["model_dir"], "model.bin")):
            raise FileNotFoundError("המודל לא נמצא. הרץ את התקנה.bat פעם אחת.\n" + self.cfg["model_dir"])
        threads = self.cfg.get("cpu_threads") or max(1, (os.cpu_count() or 4) // 2)
        self.model = WhisperModel(self.cfg["model_dir"], device="cpu",
                                  compute_type=self.cfg.get("compute_type", "int8"),
                                  cpu_threads=threads)

    def transcribe(self, audio):
        hot, repl = load_dictionary()
        segments, _info = self.model.transcribe(
            audio,
            language=self.cfg.get("language", "he"),
            beam_size=self.cfg.get("beam_size", 1),
            vad_filter=True,
            without_timestamps=True,
            condition_on_previous_text=False,
            initial_prompt=self.cfg.get("initial_prompt") or None,
            hotwords=" ".join(hot) if hot else None,     # המילון האישי: המנוע מוטה למילים האלה
        )
        text = " ".join(s.text.strip() for s in segments)
        text = " ".join(text.split())
        for wrong, right in repl:                        # החלפות קבועות מהמילון
            text = text.replace(wrong, right)
        return text

    def transcribe_file(self, path, progress=None):
        """תמלול קובץ הקלטה שלם (פגישה, שיחה). מחזיר רשימת (שנייה_התחלה, טקסט) ואת האורך."""
        hot, repl = load_dictionary()
        segments, info = self.model.transcribe(
            path,
            language=self.cfg.get("language", "he"),
            beam_size=self.cfg.get("file_beam_size", 3),
            vad_filter=True,
            condition_on_previous_text=False,
            initial_prompt=self.cfg.get("initial_prompt") or None,
            hotwords=" ".join(hot) if hot else None,
        )
        total = float(info.duration or 0)
        lines = []
        for s in segments:
            text = " ".join(s.text.split())
            for wrong, right in repl:
                text = text.replace(wrong, right)
            if text:
                lines.append((float(s.start), text))
            if progress and total:
                progress(min(99, int(s.end * 100 / total)))
        return lines, total


def fmt_ts(sec):
    sec = int(sec)
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def write_transcript(src_path, lines, total):
    """כותב קובץ טקסט לצד ההקלטה, עם חותמות זמן, ומחזיר את הנתיב."""
    out = os.path.splitext(src_path)[0] + " - תמלול.txt"
    header = [
        f"תמלול הקלטה: {os.path.basename(src_path)}",
        f"נוצר: {time.strftime('%d.%m.%Y %H:%M')} · אורך: {fmt_ts(total)} · "
        f"מנוע: ivrit-ai/whisper-large-v3-turbo, מקומי · הכתבה קולית HGJ {APP_VERSION}",
        "הערה: תמלול אוטומטי. יש לאמת ציטוטים מול ההקלטה לפני שימוש.",
        "",
    ]
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(header))
        for start, text in lines:
            f.write(f"[{fmt_ts(start)}] {text}\n")
    return out


# ----------------------------- הקלדה לשדה הממוקד -----------------------------
class Typer:
    """מדביק את הטקסט לחלון שבו המשתמש עובד, דרך הלוח ו-Ctrl+V (הדרך היחידה שאמינה לעברית)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.my_hwnd = None
        self.last_fg = None
        self.target = None       # החלון שבו עמד הסמן כשההאזנה התחילה

    def track(self):
        fg = user32.GetForegroundWindow()
        if fg and fg != self.my_hwnd:
            self.last_fg = fg

    def lock_target(self):
        """נקרא בתחילת ההאזנה: הטקסט יוקלד לחלון הזה גם אם המשתמש עבר חלון בינתיים."""
        fg = user32.GetForegroundWindow()
        self.target = fg if (fg and fg != self.my_hwnd) else self.last_fg
        logging.info("target window: %s", window_title(self.target))

    def type_text(self, text):
        import keyboard
        import pyperclip
        if self.cfg.get("append_space", True):
            text += " "
        fg = user32.GetForegroundWindow()
        want = self.target if (self.cfg.get("lock_target", True) and self.target
                               and user32.IsWindow(self.target)) else None
        if want and fg != want:
            # SwitchToThisWindow עובד גם מתהליך שאינו בחזית, בשונה מ-SetForegroundWindow
            user32.SwitchToThisWindow(want, True)
            time.sleep(0.2)
        elif (not fg or fg == self.my_hwnd) and self.last_fg:
            user32.SetForegroundWindow(self.last_fg)
            time.sleep(0.15)
        old = None
        if self.cfg.get("restore_clipboard"):
            try:
                old = pyperclip.paste()
            except Exception:
                old = None
        pyperclip.copy(text)
        time.sleep(0.05)
        keyboard.send("ctrl+v")
        if old is not None:
            time.sleep(0.6)
            pyperclip.copy(old)


# ----------------------------- הכפתור המרחף -----------------------------
class Widget:
    TRANSPARENT = "#010203"

    def __init__(self, cfg, on_toggle, on_quit, on_settings, on_dictionary=None, on_file=None):
        import tkinter as tk
        self.cfg = cfg
        self.on_toggle = on_toggle
        self.size = int(cfg.get("widget_size", 64))
        self.h = self.size + 18
        self.state = "loading"
        self.pulse = False
        self.hwnd = None

        # חדות במסכים עם קנה מידה (125%/150%): להצהיר על מודעות DPI לפני יצירת החלון
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass
        try:
            dpi_scale = user32.GetDpiForSystem() / 96.0
        except Exception:
            dpi_scale = 1.0
        self.size = int(round(self.size * dpi_scale))
        self.h = self.size + int(round(18 * dpi_scale))
        self.scale = dpi_scale
        self._tk = tk
        self._ov = None            # חלונית הסטטוס (יעד, פסי קול, טיימר)
        self._ov_visible = False

        self.root = tk.Tk()
        self.root.title("הכתבה קולית - HGJ")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", self.TRANSPARENT)
        self.root.configure(bg=self.TRANSPARENT)
        self.canvas = tk.Canvas(self.root, width=self.size, height=self.h,
                                bg=self.TRANSPARENT, highlightthickness=0, cursor="hand2")
        self.canvas.pack()

        st = load_state()
        pos = cfg.get("widget_position") or st.get("pos")
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        if not pos:
            pos = [sw - self.size - 36, sh - self.h - 120]
        x = min(max(0, int(pos[0])), sw - self.size)
        y = min(max(0, int(pos[1])), sh - self.h)
        self.root.geometry(f"{self.size}x{self.h}+{x}+{y}")

        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="הקלטה / עצירה  (" + cfg.get("hotkey", "f9").upper() + ")", command=on_toggle)
        self.menu.add_command(label="פתיחת קובץ ההגדרות", command=on_settings)
        if on_dictionary:
            self.menu.add_command(label="המילון האישי (שמות ומונחים)", command=on_dictionary)
        if on_file:
            self.menu.add_separator()
            self.menu.add_command(label="תמלול קובץ הקלטה (פגישה, שיחה)...", command=on_file)
        self.menu.add_separator()
        self.menu.add_command(label="יציאה", command=on_quit)

        self._press_xy = None
        self._moved = False
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<Button-3>", lambda e: self.menu.tk_popup(e.x_root, e.y_root))

        self.draw()
        self.root.after(80, self._apply_window_styles)
        self.root.after(450, self._animate)

    @staticmethod
    def _no_activate(widget):
        child = widget.winfo_id()
        parent = user32.GetParent(child)
        for h in {child, parent or child}:
            ex = user32.GetWindowLongW(h, GWL_EXSTYLE)
            want = ex | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            if want != ex:
                user32.SetWindowLongW(h, GWL_EXSTYLE, want)
        return parent or child

    def _apply_window_styles(self):
        # Tk כותב מחדש את הסגנונות המורחבים בכל עדכון שלו (שקיפות, topmost),
        # לכן הפונקציה נקראת גם מכל פעימת אנימציה ומחזירה את הדגל אם נעלם.
        self.hwnd = self._no_activate(self.root)
        if self._ov is not None:
            self._no_activate(self._ov)

    # --- חלונית סטטוס: לאן נכתב, פסי קול חיים, טיימר ---
    def _ensure_overlay(self):
        if self._ov is not None:
            return
        tk = self._tk
        s = self.scale
        self._ov_w, self._ov_h = int(300 * s), int(70 * s)
        ov = tk.Toplevel(self.root)
        ov.overrideredirect(True)
        ov.attributes("-topmost", True)
        ov.attributes("-transparentcolor", self.TRANSPARENT)
        ov.configure(bg=self.TRANSPARENT)
        self._ovc = tk.Canvas(ov, width=self._ov_w, height=self._ov_h,
                              bg=self.TRANSPARENT, highlightthickness=0)
        self._ovc.pack()
        ov.withdraw()
        self._ov = ov
        self._levels = [0.0] * 11
        self._ov_start = time.time()
        self._ov_target = ""
        self._ov_mode = "wait"

    def overlay_show(self, target_title, mode):
        """mode: wait (מחכה לדיבור), speech (מקשיב), transcribing (מסיים)."""
        self._ensure_overlay()
        self._ov_target = target_title or ""
        self._ov_mode = mode
        if not self._ov_visible:
            self._ov_start = time.time()
            self._levels = [0.0] * len(self._levels)
            # מעל הכפתור, ממורכז אליו, ובתוך המסך
            sw = self.root.winfo_screenwidth()
            bx, by = self.root.winfo_x(), self.root.winfo_y()
            x = min(max(4, bx + self.size // 2 - self._ov_w // 2), sw - self._ov_w - 4)
            y = by - self._ov_h - int(8 * self.scale)
            if y < 4:
                y = by + self.h + int(8 * self.scale)
            self._ov.geometry(f"{self._ov_w}x{self._ov_h}+{x}+{y}")
            self._ov.deiconify()
            self._ov.lift()
            self._ov_visible = True
            self._ov.after(60, lambda: self._no_activate(self._ov))
        self._draw_overlay()

    def overlay_hide(self):
        if self._ov is not None and self._ov_visible:
            self._ov.withdraw()
            self._ov_visible = False

    def overlay_level(self, rms):
        if self._ov_visible:
            self._levels = self._levels[1:] + [float(rms)]
            self._draw_overlay()

    def _draw_overlay(self):
        if not self._ov_visible:
            return
        c, w, h, s = self._ovc, self._ov_w, self._ov_h, self.scale
        c.delete("all")
        bg, ink, soft, bar = "#1B2440", "#F1F4FA", "#9AA6C2", "#4FD1C5"
        r = h // 2
        c.create_oval(0, 0, h, h, fill=bg, outline="")
        c.create_oval(w - h, 0, w, h, fill=bg, outline="")
        c.create_rectangle(r, 0, w - r, h, fill=bg, outline="")
        # שורה עליונה: היעד (מימין, בעברית) ושם החלון
        top = int(20 * s)
        label = "מתמלל…" if self._ov_mode == "transcribing" else "מקליד אל"
        c.create_text(w - int(22 * s), top, text=label, fill=soft, anchor="e",
                      font=("Segoe UI", max(8, int(8.5 * s)), "bold"))
        if self._ov_mode != "transcribing" and self._ov_target:
            t = self._ov_target
            t = t if len(t) <= 30 else t[:14] + "…" + t[-14:]
            bbox = c.bbox(c.find_all()[-1])
            c.create_text(bbox[0] - int(8 * s), top, text=t, fill=ink, anchor="e",
                          font=("Segoe UI", max(8, int(9 * s))))
        # שורה תחתונה: נקודה, פסים, טיימר
        bot = int(47 * s)
        dot = "#E03131" if self._ov_mode == "speech" else ("#D97706" if self._ov_mode == "transcribing" else "#7F8CA8")
        if self._ov_mode != "speech" or int(time.time() * 2) % 2 == 0:
            c.create_oval(w - int(34 * s), bot - int(7 * s), w - int(20 * s), bot + int(7 * s), fill=dot, outline="")
        n = len(self._levels)
        ref = max(0.02, max(self._levels) * 1.15)
        bw, gap = int(5 * s), int(4 * s)
        x = w - int(48 * s)
        for i in range(n):
            v = self._levels[i] / ref if self._ov_mode != "transcribing" else 0.35 + 0.35 * ((i + int(time.time() * 6)) % 3 == 0)
            bh = max(int(4 * s), int(v * 26 * s))
            c.create_rectangle(x - bw, bot - bh // 2, x, bot + bh // 2, fill=bar if v > 0.15 else soft, outline="")
            x -= bw + gap
        secs = int(time.time() - self._ov_start)
        c.create_text(int(22 * s), bot, text=f"{secs // 60}:{secs % 60:02d}", fill=ink, anchor="w",
                      font=("Segoe UI", max(9, int(10 * s)), "bold"))

    # --- גרירה מול לחיצה ---
    def _press(self, e):
        self._press_xy = (e.x_root, e.y_root, self.root.winfo_x(), self.root.winfo_y())
        self._moved = False

    def _drag(self, e):
        if not self._press_xy:
            return
        x0, y0, wx, wy = self._press_xy
        dx, dy = e.x_root - x0, e.y_root - y0
        if abs(dx) > 3 or abs(dy) > 3:
            self._moved = True
            self.root.geometry(f"+{wx + dx}+{wy + dy}")

    def _release(self, e):
        if self._moved:
            st = load_state()
            st["pos"] = [self.root.winfo_x(), self.root.winfo_y()]
            save_state(st)
        else:
            self.on_toggle()
        self._press_xy = None

    # --- חלון התקדמות להורדת המודל בהפעלה הראשונה ---
    def show_progress(self, pct, text):
        import tkinter as tk
        from tkinter import ttk
        if not getattr(self, "_prog", None):
            w = tk.Toplevel(self.root)
            w.title("הכתבה קולית HGJ - הפעלה ראשונה")
            w.attributes("-topmost", True)
            w.resizable(False, False)
            sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
            w.geometry(f"460x130+{sw // 2 - 230}+{sh // 2 - 65}")
            w.protocol("WM_DELETE_WINDOW", lambda: None)
            self._prog_label = tk.Label(w, text="", font=("Segoe UI", 10), justify="right",
                                        anchor="e", wraplength=430)
            self._prog_label.pack(fill="x", padx=14, pady=(16, 8))
            self._prog_bar = ttk.Progressbar(w, maximum=100, length=430)
            self._prog_bar.pack(padx=14, pady=(0, 16))
            self._prog = w
        self._prog_label.config(text=text)
        self._prog_bar["value"] = pct

    def hide_progress(self):
        if getattr(self, "_prog", None):
            self._prog.destroy()
            self._prog = None

    # --- ציור ---
    def set_state(self, state):
        self.state = state
        self.draw()

    def draw(self):
        c, s = self.canvas, self.size
        c.delete("all")
        color, label = COLORS.get(self.state, COLORS["idle"])
        pad = 4
        if self.state in ("recording", "speech") and self.pulse:
            c.create_oval(1, 1, s - 1, s - 1, outline=color, width=2)
        c.create_oval(pad, pad, s - pad, s - pad, fill=color, outline="")
        # גליף מיקרופון בלבן
        cx = s / 2
        u = s / 64.0
        w = max(2, int(3 * u))
        c.create_oval(cx - 7 * u, 14 * u, cx + 7 * u, 34 * u, fill="white", outline="")
        c.create_arc(cx - 13 * u, 18 * u, cx + 13 * u, 43 * u, start=180, extent=180,
                     style="arc", outline="white", width=w)
        c.create_line(cx, 43 * u, cx, 50 * u, fill="white", width=w)
        c.create_line(cx - 6 * u, 50 * u, cx + 6 * u, 50 * u, fill="white", width=w)
        if label:
            c.create_text(cx, s + int(8 * u), text=label, fill=color, font=("Segoe UI", 8, "bold"))

    def _animate(self):
        if self.state in ("recording", "speech", "transcribing"):
            self.pulse = not self.pulse
            self.draw()
            self._draw_overlay()          # מעדכן טיימר ואנימציה גם בלי אודיו
        if self.hwnd:
            self._apply_window_styles()
        self.root.after(450, self._animate)


# ----------------------------- האפליקציה -----------------------------
class App:
    def __init__(self):
        setup_logging()
        self.cfg = load_config()
        self.ui = queue.Queue()
        self.state = "loading"

        # מופע יחיד
        self._mutex = kernel32.CreateMutexW(None, False, "HGJ-Dictation-Desktop-Mutex")
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            import tkinter.messagebox as mb
            mb.showinfo("הכתבה קולית", "הכלי כבר פועל. חפשו את כפתור המיקרופון על המסך.")
            sys.exit(0)

        ensure_dictionary()
        self.widget = Widget(self.cfg, self.toggle, self.quit, self.open_settings,
                             self.open_dictionary, self.transcribe_file_dialog)
        self.typer = Typer(self.cfg)
        self.model_lock = threading.Lock()   # תמלול מיקרופון ותמלול קובץ לא רצים על המודל בו-זמנית
        self.recorder = Recorder(self.cfg, self._on_segment, self._on_end,
                                 lambda s: self.ui.put(("state", s)),
                                 on_level=lambda v: self.ui.put(("level", v)))
        self.transcriber = Transcriber(self.cfg)
        # תור תמלול: מקטעים מתומללים ומודבקים לפי הסדר, בזמן שההאזנה ממשיכה
        self.jobs = queue.Queue()
        self.pending = 0
        self.pending_lock = threading.Lock()
        threading.Thread(target=self._transcribe_worker, daemon=True).start()

        threading.Thread(target=self._load_model, daemon=True).start()
        try:
            import keyboard
            keyboard.add_hotkey(self.cfg.get("hotkey", "f9"), lambda: self.ui.put(("toggle", None)))
        except Exception as e:
            logging.error("hotkey failed: %s", e)
        self.widget.root.after(100, self._poll)
        logging.info("started")

    def run(self):
        self.widget.root.mainloop()

    def demo(self):
        """הדגמת המצבים בלי מיקרופון (לבדיקת ממשק): מחכה לדיבור, מקשיב עם פסים, מתמלל, חזרה."""
        import random
        root = self.widget.root
        self.typer.target = user32.GetForegroundWindow()

        def at(ms, kind, payload):
            root.after(ms, lambda: self.ui.put((kind, payload)))
        at(500, "state", "recording")
        for i in range(30):
            at(1500 + i * 100, "level", random.uniform(0.02, 0.25) if i % 7 else 0.004)
        at(1500, "state", "speech")
        at(4600, "state", "recording")
        at(6000, "state", "transcribing")
        at(9000, "state", "idle")
        root.after(11000, self.quit)
        root.mainloop()

    def _poll(self):
        self.typer.my_hwnd = self.widget.hwnd
        self.typer.track()
        while True:
            try:
                kind, payload = self.ui.get_nowait()
            except queue.Empty:
                break
            if kind == "state":
                self.state = payload
                self.widget.set_state(payload)
                self._sync_overlay()
            elif kind == "state_if":
                if self.state == payload[0]:
                    self.state = payload[1]
                    self.widget.set_state(payload[1])
                    self._sync_overlay()
            elif kind == "level":
                self.widget.overlay_level(payload)
            elif kind == "progress":
                if payload is None:
                    self.widget.hide_progress()
                else:
                    self.widget.show_progress(payload[0], payload[1])
            elif kind == "open":
                try:
                    os.startfile(payload)
                except Exception as e:
                    logging.error("open failed: %s", e)
            elif kind == "error_msg":
                import tkinter.messagebox as mb
                mb.showerror("הכתבה קולית", payload)
            elif kind == "toggle":
                self.toggle()
            elif kind == "type":
                try:
                    self.typer.type_text(payload)
                except Exception as e:
                    logging.error("type failed: %s", e)
            elif kind == "fatal":
                import tkinter.messagebox as mb
                mb.showerror("הכתבה קולית", payload)
                self.quit()
                return
        self.widget.root.after(100, self._poll)

    def _sync_overlay(self):
        """חלונית הסטטוס מוצגת רק בזמן האזנה ותמלול, ומראה לאן הטקסט ייכתב."""
        if self.state in ("recording", "speech"):
            self.widget.overlay_show(window_title(self.typer.target),
                                     "speech" if self.state == "speech" else "wait")
        elif self.state == "transcribing":
            self.widget.overlay_show(window_title(self.typer.target), "transcribing")
        else:
            self.widget.overlay_hide()

    def _load_model(self):
        try:
            if not os.path.exists(os.path.join(self.cfg["model_dir"], "model.bin")):
                # הפעלה ראשונה: הורדת מודל השפה (כ-1.6GB) עם חלון התקדמות
                import download_model
                logging.info("model missing, downloading to %s", self.cfg["model_dir"])
                self.ui.put(("progress", (0, "מוריד את מודל השפה בעברית (1.6GB). פעם אחת בלבד, לפי מהירות הרשת.")))
                download_model.download(
                    lambda pct, name: self.ui.put(("progress", (pct, f"מוריד {name}: {pct}%"))),
                    dest=self.cfg["model_dir"])
                self.ui.put(("progress", None))
            t = time.time()
            self.transcriber.load()
            logging.info("model loaded in %.1fs", time.time() - t)
            self.ui.put(("state", "idle"))
        except Exception as e:
            logging.exception("model load failed")
            self.ui.put(("progress", None))
            self.ui.put(("fatal", "לא ניתן לטעון את מודל השפה.\n" + str(e)))

    def toggle(self):
        if self.state == "loading":
            return
        if self.recorder.running:
            self.recorder.stop()
        else:
            self.typer.lock_target()
            self.recorder.start()
            self.ui.put(("state", "recording"))

    def _on_segment(self, audio):
        with self.pending_lock:
            self.pending += 1
        self.jobs.put(audio)

    def _on_end(self, had_speech):
        if not had_speech:
            self.ui.put(("state", "nospeech"))
            threading.Timer(2.0, lambda: self.ui.put(("state_if", ("nospeech", "idle")))).start()
            return
        with self.pending_lock:
            busy = self.pending > 0
        self.ui.put(("state", "transcribing" if busy else "idle"))

    def _transcribe_worker(self):
        while True:
            audio = self.jobs.get()
            try:
                t = time.time()
                with self.model_lock:
                    text = self.transcriber.transcribe(audio)
                logging.info("transcribed %.1fs of audio in %.2fs: %d chars",
                             len(audio) / SAMPLE_RATE, time.time() - t, len(text))
                if text:
                    self.ui.put(("type", text))
            except Exception:
                logging.exception("transcribe failed")
            with self.pending_lock:
                self.pending -= 1
                done = self.pending <= 0
            if done and not self.recorder.running:
                self.ui.put(("state_if", ("transcribing", "idle")))

    def open_settings(self):
        os.startfile(CONFIG_PATH)

    def open_dictionary(self):
        ensure_dictionary()
        os.startfile(DICT_PATH)

    # --- תמלול קובץ הקלטה: מקליטים בטלפון, מתמללים במחשב, שום דבר לא עוזב אותו ---
    def transcribe_file_dialog(self):
        from tkinter import filedialog
        if self.state == "loading":
            self.ui.put(("error_msg", "המודל עדיין נטען. נסו שוב בעוד כמה שניות."))
            return
        path = filedialog.askopenfilename(
            parent=self.widget.root, title="בחירת קובץ הקלטה לתמלול",
            filetypes=[("הקלטות", "*.m4a *.mp3 *.wav *.ogg *.opus *.aac *.flac *.wma *.mp4 *.amr *.3gp"),
                       ("כל הקבצים", "*.*")])
        if path:
            threading.Thread(target=self._transcribe_file_job, args=(path,), daemon=True).start()

    def _transcribe_file_job(self, path):
        name = os.path.basename(path)
        self.ui.put(("state", "transcribing"))
        self.ui.put(("progress", (0, f"מתמלל את {name}. אפשר להמשיך לעבוד, זה רץ ברקע.")))
        try:
            t = time.time()
            with self.model_lock:
                lines, total = self.transcriber.transcribe_file(
                    path, lambda pct: self.ui.put(("progress", (pct, f"מתמלל את {name}: {pct}%"))))
            out = write_transcript(path, lines, total)
            logging.info("file transcribed: %.0fs of audio in %.0fs, %d segments -> %s",
                         total, time.time() - t, len(lines), out)
            self.ui.put(("progress", None))
            self.ui.put(("open", out))
        except Exception as e:
            logging.exception("file transcription failed")
            self.ui.put(("progress", None))
            self.ui.put(("error_msg", f"תמלול הקובץ נכשל.\n{e}"))
        self.ui.put(("state_if", ("transcribing", "idle")))

    def quit(self):
        try:
            import keyboard
            keyboard.unhook_all()
        except Exception:
            pass
        self.widget.root.destroy()


# ----------------------------- מצבי בדיקה בלי ממשק -----------------------------
def test_wav(path):
    import wave
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    with wave.open(path, "rb") as w:
        assert w.getframerate() == SAMPLE_RATE and w.getnchannels() == 1, "נדרש WAV מונו 16kHz"
        audio = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    tr = Transcriber(cfg)
    t = time.time(); tr.load(); t_load = time.time() - t
    t = time.time(); text = tr.transcribe(audio); t_tr = time.time() - t
    print(f"model load: {t_load:.1f}s | audio: {len(audio)/SAMPLE_RATE:.1f}s | transcribe: {t_tr:.2f}s")
    print("TEXT:", text)


def test_mic(seconds=6):
    """מדפיס את רשימת המיקרופונים ומודד את עוצמת הקול הנקלטת, כדי לכוונן רגישות."""
    import sounddevice as sd
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    dev = Recorder.resolve_device(cfg)
    print("input_device in config:", cfg.get("input_device"), "-> resolved:", dev if dev is not None else "Windows default")
    try:
        print("default input:", sd.query_devices(kind="input")["name"])
    except Exception as e:
        print("default input: (none)", e)
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] > 0:
            print(f"  [{i}] {d['name']}  (api: {sd.query_hostapis(d['hostapi'])['name']})")
    print(f"recording {seconds}s... speak normally")
    x = sd.rec(int(seconds * SAMPLE_RATE), samplerate=SAMPLE_RATE, channels=1, dtype="float32", device=dev)
    sd.wait()
    blocks = x[:, 0][: (len(x) // BLOCK) * BLOCK].reshape(-1, BLOCK)
    rms = np.sqrt((blocks ** 2).mean(axis=1))
    n = (len(rms) // 10) * 10
    per_half_second = rms[:n].reshape(-1, 10).mean(axis=1) if n >= 10 else rms
    print("rms per 0.5s:", " ".join(f"{v:.4f}" for v in per_half_second))
    floor = float(np.percentile(rms, 20))
    thr = max(cfg["min_energy_threshold"], floor * cfg["noise_multiplier"])
    print(f"noise floor ~{floor:.5f} | peak {rms.max():.5f} | current threshold {thr:.5f}")
    if rms.max() < 0.002:
        print("VERDICT: almost no signal. Wrong device or muted microphone.")
    elif rms.max() < thr:
        print("VERDICT: speech is below the detection threshold. Lower min_energy_threshold in config.json.")
    else:
        print("VERDICT: level OK for detection.")


def transcribe_file_cli(path):
    """תמלול קובץ מהשורה: python dictate.py --transcribe-file הקלטה.m4a"""
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    tr = Transcriber(cfg)
    t = time.time(); tr.load(); print(f"model loaded in {time.time() - t:.1f}s")
    t = time.time()
    lines, total = tr.transcribe_file(path, lambda pct: print(f"\r  {pct:3d}%", end="", flush=True))
    out = write_transcript(path, lines, total)
    print(f"\n{fmt_ts(total)} of audio transcribed in {time.time() - t:.0f}s, {len(lines)} segments")
    print("TRANSCRIPT:", out)


def check_install():
    """בדיקה עצמית של ההתקנה, בלי מיקרופון ובלי מודל: נתיבים, מודולים, Tk. לתמיכה ולבנייה."""
    sys.stdout.reconfigure(encoding="utf-8")
    ok = True
    print("version:", APP_VERSION)
    print("python:", sys.executable)
    print("app dir:", HERE)
    cfg = load_config()
    print("config:", "OK")
    print("model dir:", cfg["model_dir"], "| model.bin present:", os.path.exists(os.path.join(cfg["model_dir"], "model.bin")))
    for mod in ("download_model", "tkinter", "faster_whisper", "ctranslate2", "sounddevice", "keyboard", "pyperclip", "numpy"):
        try:
            __import__(mod)
            print(f"import {mod}: OK")
        except Exception as e:
            ok = False
            print(f"import {mod}: FAILED ({e})")
    try:
        import tkinter
        r = tkinter.Tk(); r.withdraw(); r.destroy()
        print("tk window: OK")
    except Exception as e:
        ok = False
        print("tk window: FAILED", e)
    print("CHECK", "PASSED" if ok else "FAILED")
    sys.exit(0 if ok else 1)


def test_paste(text):
    """מדביק טקסט לחלון הממוקד אחרי 2 שניות, לבדיקת מסלול ההקלדה."""
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    time.sleep(2)
    Typer(cfg).type_text(text)
    print("pasted")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--test-wav":
        test_wav(sys.argv[2])
    elif len(sys.argv) >= 3 and sys.argv[1] == "--test-paste":
        test_paste(sys.argv[2])
    elif len(sys.argv) >= 2 and sys.argv[1] == "--test-mic":
        test_mic(int(sys.argv[2]) if len(sys.argv) >= 3 else 6)
    elif len(sys.argv) >= 3 and sys.argv[1] == "--transcribe-file":
        transcribe_file_cli(sys.argv[2])
    elif len(sys.argv) >= 2 and sys.argv[1] == "--demo":
        App().demo()
    elif len(sys.argv) >= 2 and sys.argv[1] == "--check":
        check_install()
    else:
        App().run()
