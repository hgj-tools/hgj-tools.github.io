# -*- coding: utf-8 -*-
"""
הכתבה קולית למחשב - HGJ

כפתור מיקרופון מרחף מעל כל החלונות (או מקש F9). לוחצים, מדברים, שקט קצר מסיים
את המשפט, והטקסט מוקלד ישר לשדה הטקסט הממוקד: Claude, Word, Outlook, דפדפן.

התמלול מקומי לחלוטין (מודל Whisper בעברית של ivrit.ai דרך faster-whisper).
האודיו לא יוצא מהמחשב.

הרצה: הפעלה.bat  |  בדיקה בלי ממשק: python dictate.py --test-wav קובץ.wav
"""
import os
import sys
import json
import time
import queue
import logging
import threading
import ctypes

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(os.environ.get("LOCALAPPDATA", HERE), "HGJ", "dictation-desktop")
STATE_PATH = os.path.join(APP_DIR, "state.json")
LOG_PATH = os.path.join(APP_DIR, "dictate.log")
CONFIG_PATH = os.path.join(HERE, "config.json")

SAMPLE_RATE = 16000
BLOCK = 800                     # 50 אלפיות שנייה לבלוק

COLORS = {
    "loading":      ("#8A94A6", "טוען מודל"),
    "idle":         ("#2F55D4", ""),
    "recording":    ("#E03131", "מחכה לדיבור"),
    "speech":       ("#C92A2A", "מקשיב"),
    "transcribing": ("#D97706", "מתמלל"),
    "nospeech":     ("#6B7280", "לא נקלט קול"),
    "error":        ("#6B7280", "שגיאה"),
}

# ----------------------------- Windows -----------------------------
user32 = ctypes.windll.user32
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
GWL_EXSTYLE = -20
WS_EX_NOACTIVATE = 0x08000000   # לחיצה על הכפתור לא גונבת את המיקוד מהחלון שבו כותבים
WS_EX_TOOLWINDOW = 0x00000080   # לא מופיע ב-Alt+Tab


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["model_dir"] = os.path.expandvars(cfg["model_dir"])
    return cfg


def load_state():
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
    except Exception:
        pass


def setup_logging():
    os.makedirs(APP_DIR, exist_ok=True)
    logging.basicConfig(filename=LOG_PATH, level=logging.INFO, encoding="utf-8",
                        format="%(asctime)s %(levelname)s %(message)s")


# ----------------------------- הקלטה וזיהוי שקט -----------------------------
class Recorder:
    """מקליט מהמיקרופון ומסיים לבד אחרי שקט. הלוגיקה בת'רד נפרד, לא בקולבק של האודיו."""

    def __init__(self, cfg, on_audio, on_state):
        self.cfg = cfg
        self.on_audio = on_audio
        self.on_state = on_state
        self.q = queue.Queue()
        self.running = False
        self.cancel = False
        self.stream = None

    @staticmethod
    def resolve_device(cfg):
        """input_device בהגדרות: null = ברירת המחדל של Windows, מספר = אינדקס, טקסט = חלק משם המכשיר."""
        import sounddevice as sd
        want = cfg.get("input_device")
        if want is None or want == "":
            return None
        if isinstance(want, int):
            return want
        for i, d in enumerate(sd.query_devices()):
            if d["max_input_channels"] > 0 and str(want).lower() in d["name"].lower():
                return i
        logging.warning("input_device %r not found, using default", want)
        return None

    def start(self):
        import sounddevice as sd
        if self.running:
            return
        self.running = True
        self.cancel = False
        self.q = queue.Queue()
        self.stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="float32",
                                     blocksize=BLOCK, callback=self._callback,
                                     device=self.resolve_device(self.cfg))
        self.stream.start()
        threading.Thread(target=self._worker, daemon=True).start()

    def stop(self, cancel=False):
        if self.running:
            self.cancel = cancel
            self.running = False

    def _callback(self, indata, frames, t, status):
        if self.running:
            self.q.put(indata[:, 0].copy())

    def _worker(self):
        cfg = self.cfg
        frames, noise = [], []
        started = False
        last_voice = None
        t0 = time.time()
        speech_reported = False
        peak = 0.0
        threshold = cfg["min_energy_threshold"]
        loud_streak = 0
        while self.running:
            try:
                block = self.q.get(timeout=0.1)
            except queue.Empty:
                continue
            frames.append(block)
            rms = float(np.sqrt(np.mean(block * block)))
            now = time.time()
            # רבע השנייה הראשונה מכילה טרנזיינט של פתיחת המכשיר (נמדד: פי 70 מרצפת הרעש).
            # לא לכיול ולא לזיהוי.
            if now - t0 < 0.25:
                continue
            peak = max(peak, rms)
            noise.append(rms)
            if len(noise) < 4:
                continue
            # רצפת הרעש = האחוזון ה-20 של כל מה שנקלט עד כה. גם בזמן דיבור רציף יש
            # הפסקות בין מילים, ולכן הערך נשאר נמוך. תקרה מונעת סף בלתי אפשרי.
            floor = float(np.percentile(noise, 20))
            threshold = min(max(cfg["min_energy_threshold"], floor * cfg["noise_multiplier"]),
                            cfg.get("max_energy_threshold", 0.04))
            if rms > threshold:
                loud_streak += 1
                if loud_streak >= 2:                 # 100 אלפיות שנייה רצופות, לא קליק
                    started = True
                    last_voice = now
                    if not speech_reported:
                        speech_reported = True
                        self.on_state("speech")
            else:
                loud_streak = 0
                if started and now - last_voice > cfg["silence_seconds"]:
                    break
            if now - t0 > cfg["max_recording_seconds"]:
                break
            if not started and now - t0 > cfg["no_speech_timeout_seconds"]:
                self.cancel = True
                break
        self.running = False
        try:
            self.stream.stop()
            self.stream.close()
        except Exception:
            pass
        while not self.q.empty():
            frames.append(self.q.get_nowait())
        if self.cancel or not started or not frames:
            logging.info("no speech detected: peak_rms=%.5f threshold=%.5f noise_floor=%.5f seconds=%.1f",
                         peak, threshold, float(np.median(noise)) if noise else -1, time.time() - t0)
            self.on_audio(None)
            return
        logging.info("speech captured: peak_rms=%.5f threshold=%.5f seconds=%.1f", peak, threshold, time.time() - t0)
        self.on_audio(np.concatenate(frames).astype(np.float32))


# ----------------------------- תמלול -----------------------------
class Transcriber:
    def __init__(self, cfg):
        self.cfg = cfg
        self.model = None

    def load(self):
        from faster_whisper import WhisperModel
        if not os.path.exists(os.path.join(self.cfg["model_dir"], "model.bin")):
            raise FileNotFoundError("המודל לא נמצא. הרץ את התקנה.bat פעם אחת.\n" + self.cfg["model_dir"])
        threads = self.cfg.get("cpu_threads") or max(1, (os.cpu_count() or 4) // 2)
        self.model = WhisperModel(self.cfg["model_dir"], device="cpu",
                                  compute_type=self.cfg.get("compute_type", "int8"),
                                  cpu_threads=threads)

    def transcribe(self, audio):
        segments, _info = self.model.transcribe(
            audio,
            language=self.cfg.get("language", "he"),
            beam_size=self.cfg.get("beam_size", 1),
            vad_filter=True,
            without_timestamps=True,
            condition_on_previous_text=False,
            initial_prompt=self.cfg.get("initial_prompt") or None,
        )
        text = " ".join(s.text.strip() for s in segments)
        return " ".join(text.split())


# ----------------------------- הקלדה לשדה הממוקד -----------------------------
class Typer:
    """מדביק את הטקסט לחלון שבו המשתמש עובד, דרך הלוח ו-Ctrl+V (הדרך היחידה שאמינה לעברית)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.my_hwnd = None
        self.last_fg = None

    def track(self):
        fg = user32.GetForegroundWindow()
        if fg and fg != self.my_hwnd:
            self.last_fg = fg

    def type_text(self, text):
        import keyboard
        import pyperclip
        if self.cfg.get("append_space", True):
            text += " "
        fg = user32.GetForegroundWindow()
        if (not fg or fg == self.my_hwnd) and self.last_fg:
            user32.SetForegroundWindow(self.last_fg)
            time.sleep(0.15)
        old = None
        if self.cfg.get("restore_clipboard"):
            try:
                old = pyperclip.paste()
            except Exception:
                old = None
        pyperclip.copy(text)
        time.sleep(0.05)
        keyboard.send("ctrl+v")
        if old is not None:
            time.sleep(0.6)
            pyperclip.copy(old)


# ----------------------------- הכפתור המרחף -----------------------------
class Widget:
    TRANSPARENT = "#010203"

    def __init__(self, cfg, on_toggle, on_quit, on_settings):
        import tkinter as tk
        self.cfg = cfg
        self.on_toggle = on_toggle
        self.size = int(cfg.get("widget_size", 64))
        self.h = self.size + 18
        self.state = "loading"
        self.pulse = False
        self.hwnd = None

        # חדות במסכים עם קנה מידה (125%/150%): להצהיר על מודעות DPI לפני יצירת החלון
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass
        try:
            dpi_scale = user32.GetDpiForSystem() / 96.0
        except Exception:
            dpi_scale = 1.0
        self.size = int(round(self.size * dpi_scale))
        self.h = self.size + int(round(18 * dpi_scale))

        self.root = tk.Tk()
        self.root.title("הכתבה קולית - HGJ")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", self.TRANSPARENT)
        self.root.configure(bg=self.TRANSPARENT)
        self.canvas = tk.Canvas(self.root, width=self.size, height=self.h,
                                bg=self.TRANSPARENT, highlightthickness=0, cursor="hand2")
        self.canvas.pack()

        st = load_state()
        pos = cfg.get("widget_position") or st.get("pos")
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        if not pos:
            pos = [sw - self.size - 36, sh - self.h - 120]
        x = min(max(0, int(pos[0])), sw - self.size)
        y = min(max(0, int(pos[1])), sh - self.h)
        self.root.geometry(f"{self.size}x{self.h}+{x}+{y}")

        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="הקלטה / עצירה  (" + cfg.get("hotkey", "f9").upper() + ")", command=on_toggle)
        self.menu.add_command(label="פתיחת קובץ ההגדרות", command=on_settings)
        self.menu.add_separator()
        self.menu.add_command(label="יציאה", command=on_quit)

        self._press_xy = None
        self._moved = False
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<Button-3>", lambda e: self.menu.tk_popup(e.x_root, e.y_root))

        self.draw()
        self.root.after(80, self._apply_window_styles)
        self.root.after(450, self._animate)

    def _apply_window_styles(self):
        child = self.root.winfo_id()
        parent = user32.GetParent(child)
        self.hwnd = parent or child
        # Tk כותב מחדש את הסגנונות המורחבים בכל עדכון שלו (שקיפות, topmost),
        # לכן הפונקציה נקראת גם מכל פעימת אנימציה ומחזירה את הדגל אם נעלם.
        for h in {child, self.hwnd}:
            ex = user32.GetWindowLongW(h, GWL_EXSTYLE)
            want = ex | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            if want != ex:
                user32.SetWindowLongW(h, GWL_EXSTYLE, want)

    # --- גרירה מול לחיצה ---
    def _press(self, e):
        self._press_xy = (e.x_root, e.y_root, self.root.winfo_x(), self.root.winfo_y())
        self._moved = False

    def _drag(self, e):
        if not self._press_xy:
            return
        x0, y0, wx, wy = self._press_xy
        dx, dy = e.x_root - x0, e.y_root - y0
        if abs(dx) > 3 or abs(dy) > 3:
            self._moved = True
            self.root.geometry(f"+{wx + dx}+{wy + dy}")

    def _release(self, e):
        if self._moved:
            st = load_state()
            st["pos"] = [self.root.winfo_x(), self.root.winfo_y()]
            save_state(st)
        else:
            self.on_toggle()
        self._press_xy = None

    # --- ציור ---
    def set_state(self, state):
        self.state = state
        self.draw()

    def draw(self):
        c, s = self.canvas, self.size
        c.delete("all")
        color, label = COLORS.get(self.state, COLORS["idle"])
        pad = 4
        if self.state in ("recording", "speech") and self.pulse:
            c.create_oval(1, 1, s - 1, s - 1, outline=color, width=2)
        c.create_oval(pad, pad, s - pad, s - pad, fill=color, outline="")
        # גליף מיקרופון בלבן
        cx = s / 2
        u = s / 64.0
        w = max(2, int(3 * u))
        c.create_oval(cx - 7 * u, 14 * u, cx + 7 * u, 34 * u, fill="white", outline="")
        c.create_arc(cx - 13 * u, 18 * u, cx + 13 * u, 43 * u, start=180, extent=180,
                     style="arc", outline="white", width=w)
        c.create_line(cx, 43 * u, cx, 50 * u, fill="white", width=w)
        c.create_line(cx - 6 * u, 50 * u, cx + 6 * u, 50 * u, fill="white", width=w)
        if label:
            c.create_text(cx, s + int(8 * u), text=label, fill=color, font=("Segoe UI", 8, "bold"))

    def _animate(self):
        if self.state in ("recording", "speech", "transcribing"):
            self.pulse = not self.pulse
            self.draw()
        if self.hwnd:
            self._apply_window_styles()
        self.root.after(450, self._animate)


# ----------------------------- האפליקציה -----------------------------
class App:
    def __init__(self):
        setup_logging()
        self.cfg = load_config()
        self.ui = queue.Queue()
        self.state = "loading"

        # מופע יחיד
        self._mutex = kernel32.CreateMutexW(None, False, "HGJ-Dictation-Desktop-Mutex")
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            import tkinter.messagebox as mb
            mb.showinfo("הכתבה קולית", "הכלי כבר פועל. חפשו את כפתור המיקרופון על המסך.")
            sys.exit(0)

        self.widget = Widget(self.cfg, self.toggle, self.quit, self.open_settings)
        self.typer = Typer(self.cfg)
        self.recorder = Recorder(self.cfg, self._on_audio, lambda s: self.ui.put(("state", s)))
        self.transcriber = Transcriber(self.cfg)

        threading.Thread(target=self._load_model, daemon=True).start()
        try:
            import keyboard
            keyboard.add_hotkey(self.cfg.get("hotkey", "f9"), lambda: self.ui.put(("toggle", None)))
        except Exception as e:
            logging.error("hotkey failed: %s", e)
        self.widget.root.after(100, self._poll)
        logging.info("started")

    def run(self):
        self.widget.root.mainloop()

    def _poll(self):
        self.typer.my_hwnd = self.widget.hwnd
        self.typer.track()
        while True:
            try:
                kind, payload = self.ui.get_nowait()
            except queue.Empty:
                break
            if kind == "state":
                self.state = payload
                self.widget.set_state(payload)
            elif kind == "state_if":
                if self.state == payload[0]:
                    self.state = payload[1]
                    self.widget.set_state(payload[1])
            elif kind == "toggle":
                self.toggle()
            elif kind == "type":
                try:
                    self.typer.type_text(payload)
                except Exception as e:
                    logging.error("type failed: %s", e)
            elif kind == "fatal":
                import tkinter.messagebox as mb
                mb.showerror("הכתבה קולית", payload)
                self.quit()
                return
        self.widget.root.after(100, self._poll)

    def _load_model(self):
        try:
            t = time.time()
            self.transcriber.load()
            logging.info("model loaded in %.1fs", time.time() - t)
            self.ui.put(("state", "idle"))
        except Exception as e:
            logging.exception("model load failed")
            self.ui.put(("fatal", str(e)))

    def toggle(self):
        if self.state in ("loading", "transcribing"):
            return
        if self.recorder.running:
            self.recorder.stop()
        else:
            self.recorder.start()
            self.ui.put(("state", "recording"))

    def _on_audio(self, audio):
        if audio is None or len(audio) < 0.4 * SAMPLE_RATE:
            self.ui.put(("state", "nospeech"))
            threading.Timer(2.0, lambda: self.ui.put(("state_if", ("nospeech", "idle")))).start()
            return
        self.ui.put(("state", "transcribing"))
        threading.Thread(target=self._transcribe, args=(audio,), daemon=True).start()

    def _transcribe(self, audio):
        try:
            t = time.time()
            text = self.transcriber.transcribe(audio)
            logging.info("transcribed %.1fs of audio in %.2fs: %d chars",
                         len(audio) / SAMPLE_RATE, time.time() - t, len(text))
            if text:
                self.ui.put(("type", text))
        except Exception:
            logging.exception("transcribe failed")
        self.ui.put(("state", "idle"))

    def open_settings(self):
        os.startfile(CONFIG_PATH)

    def quit(self):
        try:
            import keyboard
            keyboard.unhook_all()
        except Exception:
            pass
        self.widget.root.destroy()


# ----------------------------- מצבי בדיקה בלי ממשק -----------------------------
def test_wav(path):
    import wave
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    with wave.open(path, "rb") as w:
        assert w.getframerate() == SAMPLE_RATE and w.getnchannels() == 1, "נדרש WAV מונו 16kHz"
        audio = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    tr = Transcriber(cfg)
    t = time.time(); tr.load(); t_load = time.time() - t
    t = time.time(); text = tr.transcribe(audio); t_tr = time.time() - t
    print(f"model load: {t_load:.1f}s | audio: {len(audio)/SAMPLE_RATE:.1f}s | transcribe: {t_tr:.2f}s")
    print("TEXT:", text)


def test_mic(seconds=6):
    """מדפיס את רשימת המיקרופונים ומודד את עוצמת הקול הנקלטת, כדי לכוונן רגישות."""
    import sounddevice as sd
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    dev = Recorder.resolve_device(cfg)
    print("input_device in config:", cfg.get("input_device"), "-> resolved:", dev if dev is not None else "Windows default")
    try:
        print("default input:", sd.query_devices(kind="input")["name"])
    except Exception as e:
        print("default input: (none)", e)
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] > 0:
            print(f"  [{i}] {d['name']}  (api: {sd.query_hostapis(d['hostapi'])['name']})")
    print(f"recording {seconds}s... speak normally")
    x = sd.rec(int(seconds * SAMPLE_RATE), samplerate=SAMPLE_RATE, channels=1, dtype="float32", device=dev)
    sd.wait()
    blocks = x[:, 0][: (len(x) // BLOCK) * BLOCK].reshape(-1, BLOCK)
    rms = np.sqrt((blocks ** 2).mean(axis=1))
    n = (len(rms) // 10) * 10
    per_half_second = rms[:n].reshape(-1, 10).mean(axis=1) if n >= 10 else rms
    print("rms per 0.5s:", " ".join(f"{v:.4f}" for v in per_half_second))
    floor = float(np.percentile(rms, 20))
    thr = max(cfg["min_energy_threshold"], floor * cfg["noise_multiplier"])
    print(f"noise floor ~{floor:.5f} | peak {rms.max():.5f} | current threshold {thr:.5f}")
    if rms.max() < 0.002:
        print("VERDICT: almost no signal. Wrong device or muted microphone.")
    elif rms.max() < thr:
        print("VERDICT: speech is below the detection threshold. Lower min_energy_threshold in config.json.")
    else:
        print("VERDICT: level OK for detection.")


def test_paste(text):
    """מדביק טקסט לחלון הממוקד אחרי 2 שניות, לבדיקת מסלול ההקלדה."""
    sys.stdout.reconfigure(encoding="utf-8")
    cfg = load_config()
    time.sleep(2)
    Typer(cfg).type_text(text)
    print("pasted")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--test-wav":
        test_wav(sys.argv[2])
    elif len(sys.argv) >= 3 and sys.argv[1] == "--test-paste":
        test_paste(sys.argv[2])
    elif len(sys.argv) >= 2 and sys.argv[1] == "--test-mic":
        test_mic(int(sys.argv[2]) if len(sys.argv) >= 3 else 6)
    else:
        App().run()
