@echo off
rem ============================================================
rem   HGJ voice dictation for desktop - one-time setup
rem   1) creates an isolated Python environment
rem   2) installs the verified, hash-locked packages
rem   3) downloads the Hebrew speech model (about 1.6 GB)
rem ============================================================
setlocal
set "APP=%LOCALAPPDATA%\HGJ\dictation-desktop"
set "VENV=%APP%\venv"
where python >nul 2>&1
if errorlevel 1 (
  echo Python 3.10 or newer is required. Install it from python.org, then run this file again.
  pause
  exit /b 1
)
if not exist "%APP%" mkdir "%APP%"
if not exist "%VENV%\Scripts\python.exe" (
  echo Creating isolated environment...
  python -m venv "%VENV%" || (echo Failed to create the environment. & pause & exit /b 1)
)
echo Installing packages (hash-verified)...
"%VENV%\Scripts\python.exe" -m pip install --quiet --require-hashes -r "%~dp0requirements.lock"
if errorlevel 1 (echo Package installation failed. & pause & exit /b 1)
echo Downloading the Hebrew speech model...
"%VENV%\Scripts\python.exe" "%~dp0download_model.py"
if errorlevel 1 (echo Model download failed. & pause & exit /b 1)
echo.
echo Setup complete. Start the tool with the launcher (the other .bat file).
pause
endlocal
