#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
zoom.py - Render a narrow region of one PDF page at high DPI, so a suspected
spelling error can be read letter by letter before it is reported.

This is the verification gate of the proofreader. Hebrew PDF text extraction
drops and swaps letters; a rendered full page can also be too small to tell
similar letters apart (ד/ר, ה/ח, ו/ז, ב/כ). A zoomed crop settles it.

Usage:
    python zoom.py <input.pdf> <page> --box X0 Y0 X1 Y1 [--dpi 400] [--out DIR]

  page     1-based page number
  --box    region as FRACTIONS of page width/height (0..1), e.g. 0.45 0.30 0.95 0.36
  --dpi    render DPI (default 400)
  --out    output dir (default <pdf_dir>/_pages_tmp/zoom)

Prints a JSON line: {"file": "...", "page": 9, "box": [...], "dpi": 400}
Exit codes: 0 ok, 2 bad input, 4 missing dependency.
"""
import sys
import json
import argparse
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

try:
    import fitz  # PyMuPDF
except ImportError:
    sys.stderr.write("[שגיאה] חסרה הספרייה PyMuPDF. pip install pymupdf\n")
    sys.exit(4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("page", type=int)
    ap.add_argument("--box", type=float, nargs=4, required=True, metavar=("X0", "Y0", "X1", "Y1"))
    ap.add_argument("--dpi", type=int, default=400)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    pdf = Path(a.pdf)
    if not pdf.exists():
        sys.stderr.write(f"[שגיאה] הקובץ לא נמצא: {pdf}\n")
        sys.exit(2)
    x0, y0, x1, y1 = a.box
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        sys.stderr.write("[שגיאה] --box חייב להיות בשברים 0..1 עם x0<x1 ו-y0<y1\n")
        sys.exit(2)

    doc = fitz.open(str(pdf))
    if not 1 <= a.page <= doc.page_count:
        sys.stderr.write(f"[שגיאה] עמוד {a.page} מחוץ לטווח 1..{doc.page_count}\n")
        sys.exit(2)
    page = doc.load_page(a.page - 1)
    r = page.rect
    clip = fitz.Rect(r.x0 + x0 * r.width, r.y0 + y0 * r.height,
                     r.x0 + x1 * r.width, r.y0 + y1 * r.height)
    zoom = a.dpi / 72.0
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), clip=clip)

    out_dir = Path(a.out) if a.out else pdf.parent / "_pages_tmp" / "zoom"
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"z-p{a.page:02d}-{int(x0*1000):03d}-{int(y0*1000):03d}-{int(x1*1000):03d}-{int(y1*1000):03d}.png"
    target = out_dir / name
    pix.save(str(target))
    doc.close()
    print(json.dumps({"file": str(target), "page": a.page, "box": a.box, "dpi": a.dpi}, ensure_ascii=False))


if __name__ == "__main__":
    main()
