---
name: financial-statement-proofreader
description: >-
  Proofread Hebrew financial statements (הגהת דוחות כספיים) before they are sent to
  a client, and produce the standard 3-sheet RTL Excel findings report. Use when the
  user says הגהה, הגהת דוח כספי, בדיקת דוחות כספיים, "תעבור על הדוח", proofread a
  financial statement, or points at a client PDF of דוחות כספיים. The skill reads every
  page VISUALLY (Hebrew PDF text extraction is unreliable, the letter נ' silently drops
  and ד/ר, ה/ח get confused), independently re-derives every balance-sheet, profit and
  loss, and equity subtotal, then writes הגהה_<לקוח>_<שנה>.xlsx. It is client-agnostic:
  no client data is stored in the skill. Do NOT trust extracted Hebrew text for spelling
  findings; use extracted text only for numbers and structure.
---

# הגהת דוחות כספיים (Financial Statement Proofreader)

כלי לבדיקת תקינות דוח כספי לפני שליחתו ללקוח: שגיאות כתיב, דקדוק, טרמינולוגיה, מבנה, גילויים נדרשים, ואימות מספרי מלא. הפלט הוא קובץ Excel סטנדרטי עם שלושה גיליונות בעברית RTL.

## הכלל הקשיח (חובה, לפני כל דבר אחר)

> **כל ממצא טקסטואלי חייב להיות מאומת ויזואלית מתמונת העמוד המרונדרת. לעולם אין לסמן שגיאת כתיב או דקדוק על סמך טקסט שחולץ מה-PDF.**

הסיבה: קובצי PDF עבריים רבים נוצרים עם קידוד גופן לא-תקני. אותיות נשמטות משכבת הטקסט אף שנראות תקין ויזואלית (במיוחד האות **נ'**, וכן בלבולי **ד/ר**, **ה/ח**, **ו/ז**, **ב/כ**, וגרשיים). ראה `references/hebrew-error-catalog.md`.

מה כן אמין בחילוץ טקסט: **מספרים וסכומים** (הם LTR ונקראים אמין), ו**מבנה הדוח** (סדר ביאורים, סעיפים). השתמש בחילוץ טקסט אך ורק לאלה.

## מתי להשתמש

כשהמשתמש מבקש הגהה או בדיקת תקינות של דוח כספי, או מפנה ל-PDF של דוחות כספיים. הכלי גנרי לחלוטין. לעולם אל תמציא נתוני לקוח, שמות או מספרים. כל הנתונים מגיעים מה-PDF שמסופק בזמן ריצה.

## רצף הריצה

1. **איתור קלט וזיהוי לקוח/שנה.** אתר את ה-PDF. בדוק את שתי המוסכמות: `<לקוח>/<שנה>/*.pdf` וגם `<לקוח>/*.pdf` ישירות (המוסכמה אינה עקבית). `output_dir` = התיקייה שבה נמצא ה-PDF. את שם הלקוח המלא ואת השנה קרא **ויזואלית מעמוד השער**, לא משם הקובץ.

2. **רינדור לתמונות.**
   ```
   python scripts/render_pdf.py "<נתיב ה-PDF>"
   ```
   נוצרות תמונות `_pages_tmp/p-01.png ...`. קרא את סיכום ה-JSON מ-stdout לרשימת העמודים.

3. **קריאה ויזואלית של כל עמוד.** פתח כל PNG בכלי Read. זו שכבת האמת לכל טקסט. יישם את `references/methodology.md` ואת `references/hebrew-error-catalog.md`. סווג כל ממצא לקטגוריה, קבע חומרה, ונסח תיקון מוצע. **אל תרשום ממצא כתיב/טרמינולוגיה שאינך רואה בתמונה.**

4. **אימות מספרי.** רק כאן מותר להיעזר במספרים מחולצים. גזור מחדש כל זהות ב-`references/numeric-checks.md` (מאזן, רווח והפסד, הון עצמי, כל ביאור, התאמה לצרכי מס), לשתי השנים. כל בדיקה הופכת לשורה ב-`numeric_checks`.

5. **בניית קובץ הממצאים.** כתוב JSON תואם ל-`scripts/findings.schema.json` אל תיקיית ה-scratchpad (למשל `findings_<לקוח>_<שנה>.json`). דוגמה מלאה: `references/findings.example.json`. רק ממצאים מאומתים ויזואלית. **אין מקף ארוך (—) או מקף בינוני (–) בשום טקסט. השתמש במקף רגיל (-), פסיק, נקודה או נקודתיים.**

6. **יצירת הדוח.**
   ```
   python scripts/build_report.py "<scratchpad>/findings_<לקוח>_<שנה>.json"
   ```
   נכתב `הגהה_<לקוח>_<שנה>.xlsx` אל `output_dir`. דווח למשתמש את הנתיב ואת ספירת הממצאים, **מסומן כטיוטה לבדיקת אדם לפני שליחה ללקוח**.

## כללי בית

- שפה: עברית, RTL. פונט Arial 10. רגיסטר מקצועי.
- **אין מקף ארוך (—) ואין מקף בינוני (–) בשום פלט.** מקף רגיל, פסיק, נקודה או נקודתיים בלבד.
- הכלי נטול לקוח. אין להטמיע שמות, מספרים או דוגמאות אמיתיות בקבצי הסקיל.
- **סודיות (קריטי):** קובץ ה-`הגהה_*.xlsx` ותיקיית `_pages_tmp/` הם תוצרי לקוח ונשארים בתיקיית הלקוח בלבד. אין לפרסם אותם, אין להעלות אותם לריפו ציבורי או לשירות חיצוני, ואין לפרסם את הסקיל עצמו יחד עם קובץ ממצאים אמיתי. שימוש פנימי בלבד, כפוף לסודיות מקצועית.
- ניתן למחוק את `_pages_tmp/` לאחר סיום, או להשאירו לריצות חוזרות.

## אינדקס references

- `references/methodology.md` - המתודולוגיה המלאה: מה בודקים בכל קטגוריה, סולם החומרה.
- `references/hebrew-error-catalog.md` - מלכודות חילוץ טקסט עברי ושגיאות שכיחות בדוחות.
- `references/numeric-checks.md` - רשימת כל הזהויות המספריות לאימות.
- `references/template-spec.md` - המפרט המדויק של פורמט ה-Excel (צבעים, פונטים, רוחבים).
- `references/findings.example.json` - דוגמה ממולאת (נתונים בדויים) של קובץ הממצאים.
