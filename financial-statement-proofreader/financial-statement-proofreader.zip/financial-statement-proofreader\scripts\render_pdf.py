#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_pdf.py - Rasterize a PDF financial statement to one PNG per page.

This is the "read visually" enabler. Hebrew PDF text extraction is unreliable
(the letter נ' silently drops, ד/ר and ה/ח get confused), so the proofreading
model must read RENDERED IMAGES, not the text layer. This script only produces
those images. It contains no proofreading logic.

Output PNGs are named p-01.png, p-02.png, ... (zero-padded to the page count),
matching the existing _pages_tmp convention.

Usage:
    python render_pdf.py <input.pdf> [--out DIR] [--dpi 200] [--prefix p] [--force]

On success it prints a JSON summary to stdout so the caller knows which images
to open, e.g. {"out_dir": "...", "page_count": 12, "pages": ["p-01.png", ...], "dpi": 200}

Exit codes: 0 ok, 2 input locked/unreadable, 4 missing dependency.
"""
import sys
import json
import argparse
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


def die(msg_he, msg_en, code):
    sys.stderr.write(f"\n[שגיאה] {msg_he}\n[error] {msg_en}\n")
    sys.exit(code)


try:
    import fitz  # PyMuPDF
except ImportError:
    die("חסרה הספרייה PyMuPDF. התקן עם: pip install pymupdf",
        "Missing dependency PyMuPDF. Install with: pip install pymupdf", 4)


def main():
    ap = argparse.ArgumentParser(description="Rasterize a PDF to per-page PNGs.")
    ap.add_argument("pdf")
    ap.add_argument("--out", default=None, help="output dir (default <pdf_dir>/_pages_tmp)")
    ap.add_argument("--dpi", type=int, default=200, help="render DPI (default 200)")
    ap.add_argument("--prefix", default="p", help="filename prefix (default 'p')")
    ap.add_argument("--force", action="store_true", help="re-render even if PNGs exist")
    args = ap.parse_args()

    pdf = Path(args.pdf)
    if not pdf.exists():
        die(f"קובץ ה-PDF לא נמצא: {pdf}", f"PDF not found: {pdf}", 2)

    # warn about a stale LibreOffice/Excel lock sibling but do not touch it
    for sib in pdf.parent.glob(".~lock.*#"):
        sys.stderr.write(f"[הערה] נמצא קובץ נעילה: {sib.name} (קובץ פתוח בתוכנה אחרת)\n")

    out_dir = Path(args.out) if args.out else (pdf.parent / "_pages_tmp")
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        doc = fitz.open(str(pdf))
    except Exception as e:
        die(f"לא ניתן לפתוח את ה-PDF (נעול או פגום?): {e}",
            f"cannot open PDF (locked or corrupt?): {e}", 2)

    n = doc.page_count
    width = max(2, len(str(n)))
    zoom = args.dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)

    pages = []
    for i in range(n):
        name = f"{args.prefix}-{str(i + 1).zfill(width)}.png"
        target = out_dir / name
        pages.append(name)
        if target.exists() and not args.force:
            continue
        pix = doc.load_page(i).get_pixmap(matrix=mat)
        pix.save(str(target))
    doc.close()

    summary = {
        "out_dir": str(out_dir),
        "page_count": n,
        "pages": pages,
        "dpi": args.dpi,
    }
    print(json.dumps(summary, ensure_ascii=False))
    sys.stderr.write(f"\n[הושלם] רונדרו {n} עמודים אל: {out_dir}\n")


if __name__ == "__main__":
    main()
