# התקנה ושימוש

כלי הגהת דוחות כספיים. סקיל של קלוד שקורא PDF של דוח כספי ומפיק דוח הגהה בפורמט Excel.

## דרישות מקדימות

- **Python 3.9+** מותקן וזמין ב-PATH.
- שתי ספריות Python:
  ```bash
  pip install pymupdf openpyxl
  ```
- קלוד עם יכולת ראייה (Claude Code או Claude Desktop). הליבה החכמה של הכלי, קריאת העמודים, מתבצעת על ידי קלוד. **אין הפעלה מקומית ללא קלוד**: סקריפט לבדו אינו יכול לבצע את הקריאה הוויזואלית ואת השיפוט החשבונאי.

## מסלול א: Claude Code

העתק את תיקיית הסקיל אל תיקיית הסקילים האישית:

```
~/.claude/skills/financial-statement-proofreader/
```

(ב-Windows: `C:\Users\<שם>\.claude\skills\financial-statement-proofreader\`)

הסקיל ייטען אוטומטית. הפעלה: פתח שיחה בתיקייה שבה נמצא ה-PDF וכתוב למשל "תעבור הגהה על הדוח" או `/financial-statement-proofreader`.

## מסלול ב: Claude Desktop

1. ארוז את תיקיית הסקיל כ-zip (ראה "אריזה" למטה), או השתמש ב-zip המצורף.
2. ב-Claude Desktop: הגדרות (Settings) > Capabilities / Skills > הוסף Skill והעלה את ה-zip.
3. ודא ש-Python והספריות מותקנים במחשב, שכן הסקריפטים רצים מקומית.

> הערה: מיקום ההעלאה המדויק בממשק Claude Desktop עשוי להשתנות בין גרסאות. אם אינך מוצא את מסך ה-Skills, בדוק תחת Settings > Capabilities.

## אריזה (ליצירת zip לחלוקה)

מתוך התיקייה שמעל תיקיית הסקיל:

```bash
cd ~/.claude/skills
zip -r financial-statement-proofreader.zip financial-statement-proofreader -x "*/__pycache__/*"
```

ה-zip מכיל רק את הכלי הגנרי: הנחיות, סקריפטים, ודוגמה בדויה. **אין בו שום נתוני לקוח.**

## מבנה התיקייה

```
financial-statement-proofreader/
├── SKILL.md                     # נקודת הכניסה, תזמור התהליך
├── INSTALL.md                   # קובץ זה
├── scripts/
│   ├── render_pdf.py            # PDF -> תמונות PNG לעמוד
│   ├── build_report.py          # JSON ממצאים -> xlsx 3 גיליונות RTL
│   └── findings.schema.json     # סכמת קובץ הממצאים
└── references/
    ├── methodology.md
    ├── hebrew-error-catalog.md
    ├── numeric-checks.md
    ├── template-spec.md
    └── findings.example.json    # דוגמה עם נתונים בדויים בלבד
```

## שימוש ידני בסקריפטים (ללא קלוד, לחלקים המכניים בלבד)

רינדור PDF לתמונות:
```bash
python scripts/render_pdf.py "נתיב/לדוח.pdf"
```

יצירת דוח מקובץ ממצאים קיים:
```bash
python scripts/build_report.py "נתיב/findings.json"
```

## סודיות

- הכלי גנרי לחלוטין ואינו מכיל נתוני לקוח. מותר לחלוק אותו.
- **תוצרי הריצה** (`הגהה_*.xlsx` ו-`_pages_tmp/`) הם מידע לקוח. הם נשארים בתיקיית הלקוח. אין להעלותם לריפו ציבורי, לשירות חיצוני, או לצרפם ל-zip של הכלי. שימוש פנימי בלבד, כפוף לסודיות מקצועית.
