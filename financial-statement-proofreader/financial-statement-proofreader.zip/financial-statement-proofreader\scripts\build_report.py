#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_report.py - Generate the standard 3-sheet RTL Excel proofreading report
for Hebrew financial statements.

Reads a FINDINGS JSON (see findings.schema.json) and writes
    הגהה_<client_short>_<year>.xlsx
with three RTL sheets: סיכום, פירוט ממצאים, אימות נתונים מספריים.

This script is PURE MECHANICS. It contains no proofreading judgement.
All client-specific content arrives at runtime via the JSON. Nothing
client-specific is stored here. Only dependency: openpyxl.

Usage:
    python build_report.py <findings.json> [--out PATH] [--force]

Exit codes: 0 ok, 2 output locked, 3 schema invalid, 4 missing dependency.
"""
import sys
import os
import json
import argparse
import datetime
from pathlib import Path

# Windows console is often cp1255; force UTF-8 so Hebrew output does not crash.
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


def die(msg_he, msg_en, code):
    sys.stderr.write(f"\n[שגיאה] {msg_he}\n[error] {msg_en}\n")
    sys.exit(code)


try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
except ImportError:
    die("חסרה הספרייה openpyxl. התקן עם: pip install openpyxl",
        "Missing dependency openpyxl. Install with: pip install openpyxl", 4)

# ----------------------------------------------------------------------------
# Palette (ARGB hex, no leading #) - reverse-engineered from the house template.
# ----------------------------------------------------------------------------
NAVY = "1F4E79"      # main title band, white bold text
BLUE = "2E75B6"      # sub-title, header rows, numeric block titles
HDR = "D9E1F2"       # table header row (numeric) + summary total row
WARN = "FFF3CD"      # warning note band
WARN_INK = "7F0000"  # warning text
INK = "1F2937"       # body text
WHITE = "FFFFFF"

SEV_FILL = {"גבוהה": "FFCCCC", "בינונית": "FFE5CC", "נמוכה": "FFFACC", "תקין": "CCFFCC"}
SEV_ICON = {"גבוהה": "🔴", "בינונית": "🟠", "נמוכה": "🟡", "תקין": "🟢"}
SEV_RANK = {"גבוהה": 3, "בינונית": 2, "נמוכה": 1}
SEV_ORDER = ["גבוהה", "בינונית", "נמוכה"]

DET_ZEBRA = ("FFFFFF", "F7FBFF")   # detail sheet zebra (blue tint)
NUM_ZEBRA = ("F7FFF7", "EEFCEE")   # numeric sheet zebra (green tint)
FAIL_FILL = "FFCCCC"
NUMFMT = '#,##0;(#,##0);"-"'

# Canonical categories (fixed order of the summary matrix rows).
CATS = ["מבני", "טרמינולוגיה חשבונאית", "כתיב/בחירת מילה", "תוכני-גילויים חסרים", "בדיקה מספרית"]
CAT_LABEL = {
    "מבני": "מבני - סעיפים חסרים",
    "טרמינולוגיה חשבונאית": "טרמינולוגיה חשבונאית",
    "כתיב/בחירת מילה": "כתיב / בחירת מילה",
    "תוכני-גילויים חסרים": "תוכני - גילויים חסרים",
    "בדיקה מספרית": "בדיקה מספרית",
}
LEGEND_DESC = {
    "גבוהה": "גילוי חסר או שגיאה מהותית הפוגעת במקצועיות הדוח",
    "בינונית": "שגיאה בטרמינולוגיה או בניסוח שיש לתקן",
    "נמוכה": "הצעת שיפור לשוני או עיצובי",
    "תקין": "נבדק ואומת, ללא ממצא",
}


def norm_cat(raw):
    """Map a free-text category to one of the 5 canonical buckets."""
    s = (raw or "").strip()
    if s in CATS:
        return s
    if "מבנ" in s or "סעיף" in s or "חתימ" in s or "כותרת" in s:
        return "מבני"
    if "טרמינולוג" in s or "מונח" in s:
        return "טרמינולוגיה חשבונאית"
    if "מספר" in s or "אריתמט" in s or "סכום" in s or "חישוב" in s:
        return "בדיקה מספרית"
    if "תוכנ" in s or "גילוי" in s or "גילויים" in s or "עסק חי" in s or "מדיניות" in s:
        return "תוכני-גילויים חסרים"
    if "כתיב" in s or "מיל" in s or "דקדוק" in s or "לשון" in s or "ניסוח" in s or "פורמט" in s or "פיסוק" in s:
        return "כתיב/בחירת מילה"
    sys.stderr.write(f"[אזהרה] קטגוריה לא מזוהה: {s!r}, מוקצה ל'כתיב/בחירת מילה'\n")
    return "כתיב/בחירת מילה"


# ----------------------------------------------------------------------------
# Styling helpers
# ----------------------------------------------------------------------------
def apply_rtl(ws):
    ws.sheet_view.rightToLeft = True


def set_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def cell(ws, row, col, value, fill=None, size=10, bold=False, color=INK,
         halign="center", wrap=True, numfmt=None):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(name="Arial", size=size, bold=bold, color=color)
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    c.alignment = Alignment(horizontal=halign, vertical="center", wrap_text=wrap)
    if numfmt:
        c.number_format = numfmt
    return c


def band(ws, row, ncol, text, fill, size, bold, color, halign="center"):
    """A merged banner row A{row}:{last}{row}."""
    last = get_column_letter(ncol)
    ws.merge_cells(f"A{row}:{last}{row}")
    cell(ws, row, 1, text, fill=fill, size=size, bold=bold, color=color, halign=halign)
    # style the merged tail cells so the fill covers the whole band
    for col in range(2, ncol + 1):
        cc = ws.cell(row=row, column=col)
        if fill:
            cc.fill = PatternFill("solid", fgColor=fill)


def disp_count(n):
    return n if n else "-"


# ----------------------------------------------------------------------------
# Sheet builders
# ----------------------------------------------------------------------------
def build_summary(ws, meta, findings, num_fail, num_ran):
    NCOL = 6
    apply_rtl(ws)
    set_widths(ws, [32, 12, 12, 12, 10, 16])

    title = f'{meta["client"]} - דוחות כספיים {meta["year"]}'
    band(ws, 1, NCOL, title, NAVY, 14, True, WHITE)
    band(ws, 2, NCOL, meta.get("subtitle", "דוח הגהה ובדיקת תקינות"), BLUE, 11, True, WHITE)

    note = meta.get("note")
    if note:
        band(ws, 4, NCOL, note, WARN, 9, False, WARN_INK, halign="right")
        hdr = 6
    else:
        hdr = 4

    headers = ["קטגוריה", "גבוהה", "בינונית", "נמוכה", 'סה"כ', "סטטוס"]
    for i, h in enumerate(headers, 1):
        cell(ws, hdr, i, h, fill=BLUE, size=10, bold=True, color=WHITE)

    # tally findings into the canonical buckets
    counts = {c: {"גבוהה": 0, "בינונית": 0, "נמוכה": 0} for c in CATS}
    for f in findings:
        sev = f.get("severity", "")
        if sev in SEV_ORDER:
            counts[norm_cat(f.get("category"))][sev] += 1
    # numeric failures surface in the מספרית row as high-severity items
    counts["בדיקה מספרית"]["גבוהה"] += num_fail

    grand = {"גבוהה": 0, "בינונית": 0, "נמוכה": 0}
    r = hdr + 1
    for cat in CATS:
        cc = counts[cat]
        present = [s for s in SEV_ORDER if cc[s] > 0]
        if present:
            top = max(present, key=lambda s: SEV_RANK[s])
            fill = SEV_FILL[top]
            status = "דחוף" if "גבוהה" in present else "לבדיקה"
        else:
            fill = SEV_FILL["תקין"]
            status = "ללא ממצא ✓"
        rowtot = sum(cc.values())
        cell(ws, r, 1, CAT_LABEL[cat], fill=fill, halign="right")
        cell(ws, r, 2, disp_count(cc["גבוהה"]), fill=fill)
        cell(ws, r, 3, disp_count(cc["בינונית"]), fill=fill)
        cell(ws, r, 4, disp_count(cc["נמוכה"]), fill=fill)
        cell(ws, r, 5, disp_count(rowtot), fill=fill)
        cell(ws, r, 6, status, fill=fill)
        for s in SEV_ORDER:
            grand[s] += cc[s]
        r += 1

    # totals row
    cell(ws, r, 1, 'סה"כ ממצאים', fill=HDR, bold=True, halign="right")
    cell(ws, r, 2, grand["גבוהה"], fill=HDR, bold=True)
    cell(ws, r, 3, grand["בינונית"], fill=HDR, bold=True)
    cell(ws, r, 4, grand["נמוכה"], fill=HDR, bold=True)
    cell(ws, r, 5, sum(grand.values()), fill=HDR, bold=True)
    cell(ws, r, 6, "", fill=HDR, bold=True)

    # legend
    r += 2
    cell(ws, r, 1, "מקרא חומרה:", size=10, bold=True, halign="right")
    r += 1
    for sev in ["גבוהה", "בינונית", "נמוכה", "תקין"]:
        f = SEV_FILL[sev]
        cell(ws, r, 1, f"{SEV_ICON[sev]} {sev}", fill=f, bold=True, halign="right")
        last = get_column_letter(NCOL)
        ws.merge_cells(f"B{r}:{last}{r}")
        cell(ws, r, 2, LEGEND_DESC[sev], fill=f, halign="right")
        for col in range(3, NCOL + 1):
            ws.cell(row=r, column=col).fill = PatternFill("solid", fgColor=f)
        r += 1


def build_details(ws, findings):
    NCOL = 9
    apply_rtl(ws)
    set_widths(ws, [5, 8, 22, 18, 10, 35, 35, 38, 12])

    band(ws, 1, NCOL, "פירוט ממצאי הגהה", NAVY, 13, True, WHITE)
    headers = ["מס'", "עמוד", "מיקום / סעיף", "קטגוריה", "חומרה",
               "שגיאה שנמצאה", "תיקון מוצע", "הערות", "סטטוס"]
    for i, h in enumerate(headers, 1):
        cell(ws, 2, i, h, fill=BLUE, size=10, bold=True, color=WHITE)
    ws.freeze_panes = "A3"

    if not findings:
        band(ws, 3, NCOL, "לא נמצאו ממצאים טעוני תיקון. הדוח נבדק ואומת.",
             SEV_FILL["תקין"], 10, True, INK)
        return

    r = 3
    for idx, f in enumerate(findings, 1):
        z = DET_ZEBRA[(idx - 1) % 2]
        sev = f.get("severity", "")
        sev_fill = SEV_FILL.get(sev, z)
        rowvals = [
            f.get("id", idx),
            str(f.get("page", "")),
            f.get("location", ""),
            f.get("category", ""),
            sev,
            f.get("error", ""),
            f.get("fix", ""),
            f.get("notes", ""),
            f.get("status", "לתיקון"),
        ]
        for i, v in enumerate(rowvals, 1):
            if i == 5:  # severity cell gets the severity colour + bold
                cell(ws, r, i, v, fill=sev_fill, size=9, bold=True, halign="right")
            else:
                cell(ws, r, i, v, fill=z, size=9, halign="right")
        r += 1


def build_numeric(ws, numeric, meta, num_fail, num_ran):
    NCOL = 5
    apply_rtl(ws)
    set_widths(ws, [30, 50, 16, 16, 10])

    short = meta.get("client_short") or meta["client"]
    band(ws, 1, NCOL, f"אימות נתונים מספריים - {short} {meta['year']}", NAVY, 13, True, WHITE)

    if not num_ran:
        band(ws, 2, NCOL, "⚠️  לא בוצע אימות מספרי בקובץ זה",
             WARN, 11, True, WARN_INK, halign="right")
    elif num_fail == 0:
        band(ws, 2, NCOL, "✅  כל הסכומים נבדקו ואומתו, לא נמצאו ממצאים מספריים",
             SEV_FILL["תקין"], 11, True, INK)
    else:
        band(ws, 2, NCOL,
             f"⚠️  נמצאו {num_fail} אי-התאמות מספריות, ראה שורות מסומנות",
             FAIL_FILL, 11, True, WARN_INK)

    r = 4
    blocks = (numeric or {}).get("blocks", [])
    for block in blocks:
        band(ws, r, NCOL, block.get("title", ""), BLUE, 10, True, WHITE)
        r += 1
        for i, h in enumerate(["פריט", "נוסחת בדיקה", "ערך בדוח", "ערך מחושב", "תוצאה"], 1):
            cell(ws, r, i, h, fill=HDR, size=10, bold=True)
        r += 1
        rows = block.get("rows", [])
        for j, row in enumerate(rows):
            z = NUM_ZEBRA[j % 2]
            reported = row.get("reported")
            computed = row.get("computed")
            tol = row.get("tol", 0)
            ok = (reported is not None and computed is not None
                  and abs(reported - computed) <= tol)
            cell(ws, r, 1, row.get("item", ""), fill=z, halign="right")
            cell(ws, r, 2, row.get("formula", ""), fill=z, halign="right")
            cell(ws, r, 3, reported, fill=z, numfmt=NUMFMT)
            cell(ws, r, 4, computed, fill=z, numfmt=NUMFMT)
            cell(ws, r, 5, "✅" if ok else "❌", fill=(z if ok else FAIL_FILL), bold=True)
            r += 1
        r += 1  # blank spacer between blocks


# ----------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------
def validate(data):
    errs = []
    meta = data.get("meta")
    if not isinstance(meta, dict):
        errs.append("שדה 'meta' חסר או אינו אובייקט / missing 'meta' object")
        return errs
    for k in ("client", "year"):
        if not meta.get(k):
            errs.append(f"meta.{k} חסר / missing")
    findings = data.get("findings", [])
    if not isinstance(findings, list):
        errs.append("שדה 'findings' חייב להיות רשימה / must be a list")
        findings = []
    for i, f in enumerate(findings):
        if not isinstance(f, dict):
            errs.append(f"findings[{i}] אינו אובייקט / not an object")
            continue
        sev = f.get("severity", "")
        if sev and sev not in SEV_FILL:
            errs.append(f"findings[{i}].severity={sev!r} לא חוקי (גבוהה/בינונית/נמוכה/תקין)")
    numeric = data.get("numeric_checks")
    if numeric is not None:
        if not isinstance(numeric, dict):
            errs.append("numeric_checks חייב להיות אובייקט / must be an object")
        else:
            for bi, block in enumerate(numeric.get("blocks", []) or []):
                for ri, row in enumerate(block.get("rows", []) or []):
                    for k in ("reported", "computed"):
                        v = row.get(k)
                        if v is not None and not isinstance(v, (int, float)):
                            errs.append(
                                f"numeric_checks.blocks[{bi}].rows[{ri}].{k} חייב להיות מספר / must be a number")
    return errs


def count_numeric(numeric):
    """Return (failures, ran) across all numeric blocks."""
    if not numeric:
        return 0, False
    blocks = numeric.get("blocks", []) or []
    fail = 0
    total = 0
    for block in blocks:
        for row in block.get("rows", []) or []:
            reported = row.get("reported")
            computed = row.get("computed")
            tol = row.get("tol", 0)
            total += 1
            if not (reported is not None and computed is not None
                    and abs(reported - computed) <= tol):
                fail += 1
    return fail, total > 0


def safe_name(s):
    bad = '\\/:*?"<>|'
    return "".join("_" if ch in bad else ch for ch in str(s)).strip()


def main():
    ap = argparse.ArgumentParser(description="Build the 3-sheet RTL proofreading report.")
    ap.add_argument("findings_json")
    ap.add_argument("--out", default=None, help="output .xlsx path")
    ap.add_argument("--force", action="store_true", help="overwrite existing output")
    args = ap.parse_args()

    src = Path(args.findings_json)
    if not src.exists():
        die(f"קובץ הממצאים לא נמצא: {src}", f"findings JSON not found: {src}", 3)
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except Exception as e:
        die(f"קובץ JSON לא תקין: {e}", f"invalid JSON: {e}", 3)

    errs = validate(data)
    if errs:
        sys.stderr.write("\n[שגיאת סכמה / schema errors]\n")
        for e in errs:
            sys.stderr.write("  - " + e + "\n")
        sys.exit(3)

    meta = data["meta"]
    meta["year"] = str(meta["year"])
    findings = data.get("findings", [])
    numeric = data.get("numeric_checks")
    num_fail, num_ran = count_numeric(numeric)

    # resolve output path
    if args.out:
        out = Path(args.out)
    else:
        short = safe_name(meta.get("client_short") or meta["client"])
        fname = f"הגהה_{short}_{safe_name(meta['year'])}.xlsx"
        outdir = meta.get("output_dir")
        if not outdir:
            die("חסר meta.output_dir וגם לא סופק --out",
                "meta.output_dir missing and no --out provided", 3)
        out = Path(outdir) / fname

    if out.exists() and not args.force:
        die(f"קובץ הפלט כבר קיים: {out}. השתמש ב---force לדריסה",
            f"output already exists: {out}. use --force to overwrite", 2)

    wb = openpyxl.Workbook()
    build_summary(wb.active, meta, findings, num_fail, num_ran)
    wb.active.title = "סיכום"
    build_details(wb.create_sheet("פירוט ממצאים"), findings)
    build_numeric(wb.create_sheet("אימות נתונים מספריים"), numeric, meta, num_fail, num_ran)

    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(out))
        final = out
    except PermissionError:
        # target is open in Excel/LibreOffice; save an alternate so nothing is lost
        stamp = datetime.datetime.now().strftime("%H%M%S")
        alt = out.with_name(f"{out.stem}__{stamp}{out.suffix}")
        try:
            wb.save(str(alt))
        except Exception as e:
            die(f"קובץ הפלט נעול ולא ניתן לשמור: {e}",
                f"output locked and alternate save failed: {e}", 2)
        sys.stderr.write(
            f"\n[אזהרה] קובץ היעד נעול (פתוח בתוכנה אחרת). נשמר עותק חלופי:\n  {alt}\n"
            f"[warning] target locked; saved alternate copy instead.\n")
        final = alt

    total_findings = len(findings)
    result = {
        "output": str(final),
        "findings": total_findings,
        "numeric_failures": num_fail,
        "numeric_ran": num_ran,
    }
    print(json.dumps(result, ensure_ascii=False))
    sys.stderr.write(
        f"\n[הושלם] נוצר דוח הגהה: {final}\n"
        f"  ממצאים: {total_findings} | אי-התאמות מספריות: {num_fail}\n"
        f"  זו טיוטה. יש לבצע בדיקת אדם לפני שליחה ללקוח.\n")


if __name__ == "__main__":
    main()
