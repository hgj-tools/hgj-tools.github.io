﻿<#
    verify-rtl.ps1  —  בודק אם מסמך Word הוא RTL אמיתי ברמת ה-OOXML.

    למה זה קיים: מסמך יכול להיראות RTL מושלם ולא להיות RTL. ניתן "לזייף" מראה
    RTL על ידי אחסון העמודות בסדר הפוך בלי אף bidiVisual — זה נראה נכון בהדפסה,
    אבל הטבלה אינה RTL מבחינת Word (הוספת עמודה, Tab, וקוראי מסך נשברים).

    הסקריפט הוא קורא-בלבד. הוא לא משנה את הקובץ.

    שימוש:
        powershell -NoProfile -ExecutionPolicy Bypass -File verify-rtl.ps1 -Path "C:\...\נייר.docx"

    קוד יציאה: 0 = תקין · 1 = נמצאו בעיות · 2 = שגיאה בהרצה
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Path
)

$ErrorActionPreference = 'Stop'

function Write-Result {
    param([string]$Label, [bool]$Ok, [string]$Detail)
    $mark = if ($Ok) { '[ תקין ]' } else { '[ בעיה ]' }
    $color = if ($Ok) { 'Green' } else { 'Red' }
    Write-Host ("{0,-9} {1,-34} {2}" -f $mark, $Label, $Detail) -ForegroundColor $color
}

try {
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host "לא נמצא קובץ: $Path" -ForegroundColor Red
        exit 2
    }
    $full = (Resolve-Path -LiteralPath $Path).Path
    if ([System.IO.Path]::GetExtension($full).ToLower() -ne '.docx') {
        Write-Host "הקובץ אינו .docx — הבדיקה חלה על docx בלבד." -ForegroundColor Red
        exit 2
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem

    $zip = [System.IO.Compression.ZipFile]::OpenRead($full)
    try {
        function Read-Entry {
            param($Zip, [string]$Name)
            $e = $Zip.Entries | Where-Object { $_.FullName -eq $Name }
            if (-not $e) { return $null }
            $sr = New-Object System.IO.StreamReader($e.Open(), [System.Text.Encoding]::UTF8)
            try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
        }

        $docXml    = Read-Entry -Zip $zip -Name 'word/document.xml'
        $stylesXml = Read-Entry -Zip $zip -Name 'word/styles.xml'

        if (-not $docXml) {
            Write-Host "word/document.xml לא נמצא — הקובץ פגום או אינו docx תקני." -ForegroundColor Red
            exit 2
        }
    }
    finally { $zip.Dispose() }

    Write-Host ""
    Write-Host "בדיקת RTL: $([System.IO.Path]::GetFileName($full))" -ForegroundColor Cyan
    Write-Host ("-" * 74)

    $problems = 0

    # ---------- 1. טבלאות ----------
    $tblPrMatches = [regex]::Matches($docXml, '<w:tblPr\b.*?</w:tblPr>|<w:tblPr\b[^>]*/>')
    $tableCount   = ([regex]::Matches($docXml, '<w:tbl>')).Count
    $withBidi     = 0
    foreach ($m in $tblPrMatches) {
        if ($m.Value -match '<w:bidiVisual\b') { $withBidi++ }
    }

    if ($tableCount -eq 0) {
        Write-Result -Label 'טבלאות' -Ok $true -Detail 'אין טבלאות במסמך'
    }
    elseif ($withBidi -eq $tableCount) {
        Write-Result -Label 'bidiVisual בטבלאות' -Ok $true -Detail "$withBidi מתוך $tableCount"
    }
    else {
        Write-Result -Label 'bidiVisual בטבלאות' -Ok $false -Detail "$withBidi מתוך $tableCount — חסרות $($tableCount - $withBidi)"
        $problems++
    }

    # ---------- 2. sectPr ----------
    $sectOk = $false
    foreach ($m in [regex]::Matches($docXml, '<w:sectPr\b.*?</w:sectPr>')) {
        if ($m.Value -match '<w:bidi\s*/>') { $sectOk = $true; break }
    }
    Write-Result -Label 'bidi ברמת המקטע (sectPr)' -Ok $sectOk -Detail $(if ($sectOk) { 'מוגדר' } else { 'חסר <w:bidi/> ב-sectPr' })
    if (-not $sectOk) { $problems++ }

    # ---------- 3. פסקאות ----------
    $paraBidi = ([regex]::Matches($docXml, '<w:bidi\s*/>')).Count
    $styleBidi = $false
    if ($stylesXml) {
        $m = [regex]::Match($stylesXml, '<w:style [^>]*w:default="1"[^>]*w:styleId="[^"]*"\s*>.*?</w:style>')
        if ($m.Success -and $m.Value -match '<w:bidi\s*/>') { $styleBidi = $true }
        if (-not $styleBidi -and $stylesXml -match '<w:docDefaults>.*?<w:bidi\s*/>.*?</w:docDefaults>') { $styleBidi = $true }
    }
    $paraOk = ($paraBidi -gt 0) -or $styleBidi
    $paraDetail = if ($styleBidi) { "בירושה מסגנון Normal" } else { "$paraBidi סימוני bidi מפורשים" }
    Write-Result -Label 'bidi ברמת הפסקה' -Ok $paraOk -Detail $paraDetail
    if (-not $paraOk) { $problems++ }

    # ---------- 4. ריצות עבריות ----------
    $rtlRuns = ([regex]::Matches($docXml, '<w:rtl\s*/>')).Count
    Write-Result -Label 'w:rtl ברמת ה-run' -Ok ($rtlRuns -gt 0) -Detail "$rtlRuns ריצות"
    if ($rtlRuns -eq 0) { $problems++ }

    Write-Host ("-" * 74)

    # ---------- אזהרת סדר עמודות ----------
    if ($tableCount -gt 0 -and $withBidi -lt $tableCount) {
        Write-Host ""
        Write-Host "⚠  אזהרה לפני תיקון:" -ForegroundColor Yellow
        Write-Host "   טבלה ללא bidiVisual עשויה להיות בנויה עם סדר עמודות הפוך בכוונה" -ForegroundColor Yellow
        Write-Host "   (כדי 'לזייף' מראה RTL). הוספת bidiVisual לבדה תהפוך אותה ותשבור" -ForegroundColor Yellow
        Write-Host "   את התצוגה. בדוק את סדר העמודות בפועל לפני שאתה מוסיף את הדגל." -ForegroundColor Yellow
    }

    Write-Host ""
    if ($problems -eq 0) {
        Write-Host "התוצאה: RTL אמיתי — המסמך תקין." -ForegroundColor Green
        exit 0
    }
    else {
        Write-Host "התוצאה: נמצאו $problems ממצאים. המסמך אינו RTL אמיתי גם אם הוא נראה תקין." -ForegroundColor Red
        exit 1
    }
}
catch {
    Write-Host "שגיאה: $($_.Exception.Message)" -ForegroundColor Red
    exit 2
}
